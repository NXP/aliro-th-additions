#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#
import argparse
import collections
import datetime
import importlib
import inspect
import os
import re
import sys
import shutil
import time
from copy import deepcopy
from pathlib import Path
from typing import TypeVar

import pkg_resources

header = """
\"\"\"
!!! WARNING!!! DO NOT MODIFY THIS FILE
This file is auto generated from the def file - project/uci_def_<ver>.yaml.
If any modifications needed, please modify the def file.
\"\"\"
"""
_copyright = """#
# Copyright 2024 NXP
# SPDX-License-Identifier: Apache-2.0
#
"""
generated = '# Generated on: {}\n'.format(datetime.datetime.today())

imports = """
from ctypes import c_uint32, c_uint16, c_uint8, c_uint64
from copy import deepcopy
from typing import TypeVar
"""
indent = '    '

UCI_VER = ''
# BASE_DIR = os.path.dirname(re.search('Summary:(.*)', get_distribution('uciTool').get_metadata('PKG-INFO'), re.M).group(1).strip())
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE_UCI = os.path.join(BASE_DIR, 'ucitool', 'base_uci')
UCI_DEFS = os.path.join(BASE_UCI, 'defs')
UCI_HELPERS = os.path.join(BASE_UCI, 'helpers')
uci_gen_file = os.path.join(BASE_UCI, 'cmds.py')
UCI_YAML = os.path.join(UCI_DEFS, 'uci_def.yaml')
TEST_DIR = os.path.join(BASE_DIR, 'sample_tests')
CONFIG_YAML = os.path.join(TEST_DIR, 'test_config.yaml')

UCI_DEF = {}


def calculate_time(func):
    """Decorate any func with this to know func's exact runtime"""

    def run(*args, **kwargs):
        t1 = time.time()
        ret = func(*args, **kwargs)
        print('Time taken to execute {} is {} secs'.format(func.__name__, time.time() - t1))
        return ret

    return run


def set_uci_ver(ver=UCI_VER):
    global UCI_YAML, UCI_VER, UCI_DEF
    UCI_DEF = {}
    UCI_VER = ver
    UCI_YAML = os.path.join(UCI_DEFS, 'uci_def{}.yaml'.format('_{}'.format(ver) if ver else ''))
    if not os.path.exists(UCI_YAML):
        print('Error: Unsupported UCI VER-{}, This version is not added in def'.format(ver))
        sys.exit()
    load_uci()
    # gen()
    return UCI_DEF


def get_uci_helpers():
    helper = 'ucitool.base_uci.helpers.uci_helper'.format(re.sub(r'\.', '_', UCI_VER))
    return importlib.import_module(helper).__dict__


def get_supported_versions():
    return sorted(map(lambda x: x[0], re.findall(r'(\d+.\d+(.\d)*(.h2)*)', ' '.join(os.listdir(UCI_DEFS)))), key=len)


# @calculate_time
def load_uci():
    """
    static function
    call this only once
    """
    global UCI_DEF
    if not UCI_DEF:
        UCI_DEF = read_yaml(UCI_YAML)
    return UCI_DEF


def read_yaml(yml):
    # let this import be here. we import this file before we finish setup, so yaml package may be missing
    import yaml  # This file is imported in setup.py which shouldn't have do, but added for ver switching.
    _mapping_tag = yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG  # noqa

    def dict_constructor(loader, node):  # this is to preserve the order while reading yaml to dict
        return collections.OrderedDict(loader.construct_pairs(node))  # read into a orderedDict

    yaml.add_constructor(_mapping_tag, dict_constructor, Loader=yaml.SafeLoader)

    def dict_representer(dumper, data):
        return dumper.represent_dict(data.items())

    yaml.add_representer(collections.OrderedDict, dict_representer)  # while writing preserve the order
    try:
        if isinstance(yml, str):  # if filepath open and read
            with open(yml, 'r') as stream:
                return yaml.load(stream, Loader=yaml.SafeLoader)
        else:  # if file pointer, just read it
            return yaml.load(yml.read(), Loader=yaml.SafeLoader)
    except yaml.YAMLError as e:
        print('Error loading uci defs'.format(yml))
        print(e)


def get_uci_def():
    if not UCI_DEF:
        load_uci()
    return UCI_DEF


def get_uci_ver():
    return UCI_VER


def get_installed_ver():
    try:
        return pkg_resources.get_distribution("ucitool").version
    except pkg_resources.DistributionNotFound:
        return 'Not Installed'


def generate_uci_cmds():
    code = ''
    code += '\n\nclass Cmds:\n\n'
    for uci, fields in UCI_DEF['DEF'].items():
        code += '\n{}class {}:\n'.format(indent, uci)
        code += '{0}{0}__GID = {1}\n{0}{0}__OID = {2}\n'.format(indent, fields['GID'], fields['OID'])
        if 'CMD' in fields:
            for field, f_type in fields['CMD'].items():
                code += '{}{}{} = {}\n'.format(indent, indent, field, f_type)
    return code


def generate_tlv_cls(tlv_cls, tlv_dict):
    code = ''
    if not tlv_dict:
        return '\nclass {}:\n{}\n'.format(tlv_cls, indent + 'undefined = None')
    for tag_id, val in tlv_dict.items():
        if 'TAG' in val:
            code += indent + re.sub(indent, indent + indent, print_cls(val['TAG'], {'TAG_ID': [tag_id], **val}))
        else:
            for subid, tlv in val.items():
                code += indent + re.sub(indent, indent + indent,
                                        print_cls(tlv['TAG'], {'TAG_ID': [tag_id, subid], **tlv}))
    return 'class {}:\n{}'.format(tlv_cls, code)


def print_cls(name, val_dict):
    code = ''
    code += 'class {}:\n'.format(name)
    for k, v in val_dict.items():
        if isinstance(v, collections.OrderedDict):
            continue
        if k in ['TAG', 'LEN', 'TAG_ID', 'N']:  # reverse key
            code += '{}{} = {}\n'.format(indent, k, v if isinstance(v, (int, list)) else '\'{}\''.format(v))
        else:
            code += '{}{} = {}\n'.format(indent, v, k if isinstance(k, (int, str)) else '\'{}\''.format(k))
    return code


Cls = TypeVar('Cls')


def get_uci(cls: Cls) -> Cls:
    """
    parameters and return annotaions- dirty lie to make autocomplete and static
    analyzers give more useful results.
    :param cls:
    :return: copy of a class
    """
    copy_cls = type(f'_{cls.__name__}', cls.__bases__, dict(cls.__dict__))
    for name, attr in cls.__dict__.items():
        try:
            hash(attr)
        except TypeError:
            # Assume lack of __hash__ implies mutability. This is NOT
            # a bullet proof assumption but good in our case.
            setattr(copy_cls, name, deepcopy(attr))

    return copy_cls


def get_attr(attr):
    try:
        return UCI_DEF['STATUS'][attr]
    except KeyError:
        return None


# @calculate_time
def gen():
    print('Generating UCI Commands...')
    load_uci()
    with open(uci_gen_file, 'w') as fd:
        fd.write(_copyright)
        fd.write(header)
        fd.write(imports)
        fd.write('Cls = TypeVar(\'Cls\')\n\n')
        fd.write(inspect.getsource(get_uci) + '\n\n')
        fd.write(generate_tlv_cls('APP_CFG', get_attr('APP_TLV')) + '\n\n')
        fd.write(generate_tlv_cls('DEVICE_CFG', get_attr('DEVICE_TLV')) + '\n\n')
        fd.write(generate_tlv_cls('TEST_CFG', get_attr('TEST_TLV')) + '\n\n')
        fd.write(print_cls('PLATFORM', get_attr('PLATFORM_ID')) + '\n\n')
        fd.write(print_cls('BOARD_VARIANT', get_attr('VARIANT_ID')) + '\n\n')
        fd.write(print_cls('SESSION_TYPE', get_attr('SESSION_TYPE')) + '\n\n')
        fd.write(print_cls('CALIB_TYPE', get_attr('CALIB_PARAM')) + '\n\n')
        fd.write(generate_tlv_cls('VENDOR_APP_CFG', get_attr('VENDOR_TLV')) + '\n\n')
        fd.write(generate_uci_cmds())


def gen_sample_tests():
    # keep only rel ext test file
    config = read_yaml(CONFIG_YAML)

    rel_tests = set(config['RELEASE_EXT']['TESTS'])
    for tc in os.listdir(TEST_DIR):
        try:  # rm all files except mentioned in test_config.yaml(exception- __init__.py, yaml files)
            if tc not in rel_tests and not tc.endswith('yaml') and '__' not in tc:
                os.remove(os.path.join(TEST_DIR, tc))
            else:
                print('Sample Test added- {}'.format(tc))
        except PermissionError:  # skip if there is any file rm exception
            pass


def gen_external_pkg(kw_exclusions):
    ptrn_list = [re.compile(r".*#\s+{}\s*$".format(excl_str)) for excl_str in kw_exclusions]
    for def_f in os.listdir(UCI_DEFS):
        import yaml
        if def_f.endswith('.yaml'):
            deff = os.path.join(UCI_DEFS, def_f)
            try:
                if not re.search(r'\d.\d.\d*', def_f):
                    internal_def = re.search(r'uci_def_(\w*)', def_f).group(1)
                    if internal_def:
                        helper = os.path.join(UCI_HELPERS, 'uci_helper_{}.py'.format(internal_def))
                        print('Remove Internal uci def- {}'.format(deff))
                        print('Remove Internal helper- {}'.format(helper))
                        os.remove(deff)
                        os.remove(helper)
                        continue
            except: pass  # noqa
            rmv_int_strs(deff, ptrn_list)
            with open(deff, 'r+') as stream:
                try:
                    yml_data = read_yaml(stream)
                    stream.seek(0)
                    for line in stream:
                        if [True for ptrn in ptrn_list if ptrn.search(line)] and line.strip().startswith('0'):
                            uci = line.split()[1]
                            try:
                                gid, oid = yml_data['DEF'][uci]['GID'], yml_data['DEF'][uci]['OID']
                            except KeyError:
                                continue
                            del yml_data['DEF'][uci]
                            del yml_data['OID'][gid][oid]
                            if not len(yml_data['OID'][gid]):
                                del yml_data['OID'][gid]
                    stream.seek(0)
                    stream.truncate()
                    stream.write(_copyright + '\n')
                    stream.write(generated + '\n')
                    stream.write(yaml.dump(yml_data))
                    stream.truncate()
                except yaml.YAMLError:
                    print('Error loading uci defs'.format(def_f))
            print('Generated Ext Def Version: {}'.format(deff))

    gen_sample_tests()


def rmv_int_strs(fpath, ptrn_list):
    spc_ptrn = re.compile(r"(\s*)\S.*")
    with open(fpath, 'r') as fd:
        op_line_list, cur_prime_hdr, ign_nest_level = [], '', None
        for line in fd:
            if not line.strip().startswith('#') and line.strip():
                cur_nest_level = spc_ptrn.match(line).groups()[0]
                if not cur_nest_level:
                    cur_prime_hdr = line.strip()
                else:
                    if [True for ptrn in ptrn_list if ptrn.search(line)] and not cur_prime_hdr.startswith('OID:'):
                        if ign_nest_level is None or not cur_nest_level.startswith(ign_nest_level):
                            ign_nest_level = cur_nest_level
                        continue
                    elif ign_nest_level is not None and cur_nest_level.startswith(ign_nest_level):
                        if cur_nest_level == ign_nest_level:
                            ign_nest_level = None
                        else:
                            continue
            op_line_list.append(line)

    with open(fpath, 'w') as fd:
        fd.writelines(op_line_list)


def make_mac_style_line_ending():
    print('Making mac style line endings...')
    windows_line_ending, mac_line_ending = b'\r\n', b'\n'
    print('Making mac style line endings for Files under (' + BASE_DIR + '):')
    for file_path in Path(BASE_DIR).rglob("*"):
        if file_path.suffix in {".bat", ".csv", ".md", ".py", ".txt", ".yaml"}:
            content = file_path.open('rb').read()
            with open(file_path, 'wb') as open_file:
                print('\t' + str(file_path))
                open_file.write(content.replace(windows_line_ending, mac_line_ending))


def set_version(ver):
    def_file = os.path.join(BASE_UCI, 'defs', 'uci_def.yaml'.format(ver))
    new_def_file = os.path.join(BASE_UCI, 'defs', 'uci_def_{}.yaml'.format(ver))
    helper = os.path.join(BASE_UCI, 'helpers', 'uci_helper.py'.format(ver))
    new_helper_file = os.path.join(BASE_UCI, 'helpers', 'uci_helper_{}.py'.format(re.sub(r'\.', '_', ver)))

    if not os.path.exists(new_def_file) or not os.path.exists(new_helper_file):
        print('This version is unsupported')
        print(new_def_file, new_helper_file)
        sys.exit()
    shutil.copy(new_def_file, def_file)
    shutil.copy(new_helper_file, helper)


if __name__ == '__main__':
    all_uci_ver = get_supported_versions()
    parser = argparse.ArgumentParser(description="Uwb Command Interface")
    parser.add_argument('-e',      '--external',      required=False, help="generate def for external release",               action="store_true")
    parser.add_argument('-ex_rdr', '--exclude_radar', required=False, help="generate def without radar for external release", action="store_true")
    parser.add_argument('-v',      '--ver',           required=False, help="make the corresponding uci def as default",       choices=all_uci_ver)
    my_args = parser.parse_args()
    if my_args.ver:
        set_version(my_args.ver)
    if my_args.external:
        exclusions = ['INTERNAL']
        if my_args.exclude_radar:
            exclusions.append('EXTERNAL_WO_RADAR')
        gen_external_pkg(exclusions)
    gen()
    if my_args.external:
        make_mac_style_line_ending()
