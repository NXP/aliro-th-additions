#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#
import logging
import logging as log
import time

from ucitool.base_uci.hbci import Hbci
from ucitool.uwb_devices.fira_vcom import FiraVcom

SOFTWARE_VERSION_TLV_LEN = 4
BOARD_ID_TLV_LEN = 18
logger = logging.getLogger()


class Rhodes(FiraVcom):
    def __init__(self):
        super().__init__()

    def initialize(self, dev_config):
        super().initialize(dev_config)
        self.hbci = Hbci(self.write, self.read_hbci, self.id, self.dev_type)
        self.uci_ready_mode = False

    def fw_download(self, filename, print_log=False, skip_powerup=False):
        not self.uci_ready_mode and self.uci_handler.fw_download(filename, print_log, skip_powerup)

    def read_hbci(self, rlen=1, timeout=5):
        # handling the exception in the main caller, that is uci_handler (uci_read) so that function
        # prototype is not changed
        with self._mutex:
            packet = self.ser.read(rlen + 1)
            if packet:
                return packet[1:]
            return None

    def powerup(self):
        write_buf = bytearray()
        write_buf.extend([0xFF])
        write_buf.extend([0x04, 0x00, 0x00])
        read_rsp = bytearray()
        read_rsp.extend([0xFF, 0x01, 0x02, 0x03, 0x04])
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            print('PowerUp TX:' + str(write_buf.hex()))
            self.ser.write(write_buf)
            time.sleep(0.1)
            rx = self.ser.read(4 + 1)
            rx and print('PowerUp RX1:' + str(rx.hex()))
            t1 = time.time()
            while rx != read_rsp and time.time() - t1 < 2:
                time.sleep(0.3)
                rx = self.ser.read(4 + 1)
                rx and print('PowerUp RX2:' + str(rx.hex()))
            if rx != read_rsp:
                log.error("Error power up rhodes")
                assert False, "Rhodes PowerUp Failed"

    def reset(self):
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            log.debug('Issue Rhodes MCU Reset')
            self.ser.write([0x09, 0x00, 0x01, 0x95])
            # let the device unload
            time.sleep(1)
        # close outside of _mutex, otherwise it can/will create a deadlock with uci_handler (run function)
        self.close()

    def get_software_version(self):
        write_buf = bytearray()
        write_buf.extend([0xFF])
        write_buf.extend([0x06, 0x00, 0x00])
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            log.debug('softwareVersion Tlv:' + str(write_buf.hex()))
            self.ser.write(write_buf)
            time.sleep(0.05)
            rx = self.ser.read(SOFTWARE_VERSION_TLV_LEN + 1)
            if rx:
                rx = rx[1:]
            if rx and len(rx) > 2:
                rx = rx[2:].hex()  # strip off header
                log.debug('softwareVersion:' + str(rx))
            return rx

    def get_board_id(self):
        write_buf = bytearray()
        write_buf.extend([0xFF])
        write_buf.extend([0x07, 0x00, 0x00])
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            log.debug('boardID Tlv:' + str(write_buf.hex()))
            self.ser.write(write_buf)
            time.sleep(0.05)
            rx = self.ser.read(BOARD_ID_TLV_LEN + 1)
            if rx:
                rx = rx[1:]
            if rx and len(rx) > 2:
                rx = rx[2:].hex()  # strip off header
                log.debug('boardID:' + str(rx))
            return rx

    def write(self, data, uci_pkt=True, hbci_pkt=False, hbci_qry_pkt=False, hbci_custom_pkt=False, length=0):
        with self._mutex:
            try:
                if self.uci_ready_mode:
                    return self.ser.write(data)
                write_buf = bytearray()
                write_buf.extend([0xFF])
                if uci_pkt:
                    write_buf.extend([0x01])
                elif hbci_pkt:
                    write_buf.extend([0x02])
                elif hbci_qry_pkt:
                    write_buf.extend([0x03])
                if hbci_custom_pkt:
                    write_buf.extend([0x05])
                    write_buf.extend((len(data) + 1).to_bytes(2, 'big'))
                    write_buf.extend([length])
                else:
                    write_buf.extend(len(data).to_bytes(2, 'big'))
                write_buf.extend(data)
                # print("Write > ", list(write_buf)[:4])
                self.ser.write(write_buf)
            except:
                log.error('Write Failed')

    def flash_write(self, offset, data):
        """
        Rhodes API to write flash area. offset=0 is first offset of last sector.
        Last sector in MCU is reserved for users.
        @offset: offset to read from
        @data:data to be written.
        """
        cmd = bytearray([0xFF, 0x07])  # cmd + len(offset+ nwords)
        cmd.extend((len(data) + 2).to_bytes(2, byteorder='big'))
        cmd.extend(offset.to_bytes(2, byteorder='little'))
        cmd.extend(data)
        log.info('Flash write- offset-{} len-{} data-{}'.format(offset, len(data), data))
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            # temp fix
            log.info('[' + self.id + ']' + 'Flash write:' + str(cmd.hex()))
            self.ser.write(cmd)
            # time.sleep(0.1)
            out = self.ser.read(10 + 1)
            if out:
                out = out[1:]
            if out:
                return int.from_bytes(out, byteorder='big') == 0
        log.error('Error writing flash')

    def flash_read(self, offset=0, nwords=1):
        """
        Rhodes API to read flash area. offset=0 is first offset of last sector.
        Last sector in MCU is reserved for users.
        @offset: offset to read from
        @nwords: number of 32bit words to read
        """
        cmd = bytearray([0xFF, 0x06, 0x0, 0x04])  # cmd + len(offset+ nwords)
        cmd.extend(offset.to_bytes(2, byteorder='little'))
        cmd.extend(nwords.to_bytes(2, byteorder='little'))
        read_len = 4 * (nwords + 1)  # 32bit addressable + status byte(4 bytes)
        log.info('Flash read- offset-{} nwords-{}'.format(offset, nwords))
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            # temp fix
            log.info('[' + self.id + ']' + 'Flash read:' + str(cmd.hex()))
            self.ser.write(cmd)
            # time.sleep(0.1)
            out = self.ser.read(read_len + 1)
            if out:
                out = out[1:]
            if out and int.from_bytes(bytes=out[0:4], byteorder='little') != 0x0:
                log.error('Flash read failed')
                return
            if len(out) < read_len:
                log.error('Error read, not enough data is read')
                return

            out = out[4:]
            logger.info([out[i:i + 4].hex() for i in range(0, len(out), 4)])
            return [out[i:i + 4] for i in range(0, len(out), 4)]

    def usb_loopback_test(self, data: list) -> list:
        write_buf = bytearray([0xFF, 0x8])
        data = bytearray([data]) if isinstance(data, int) else data
        write_buf.extend(len(data).to_bytes(2, 'big'))
        write_buf.extend(data)
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            log.debug('send:' + str(write_buf.hex()))
            self.ser.write(write_buf)
            echo_len = len(data) + 3
            rx = self.ser.read(echo_len)
            if rx:
                rx = rx[1:]
            if len(rx) != echo_len:
                log.error('Err in echo back, sent-{} read-{}'.format(echo_len, len(rx)))
            return list(rx[3:])

    def read_chipid(self):
        self.powerup()
        return self.hbci.get_chip_id()

    def write_and_read_raw(self, cmd, len_to_read, delay = 0):
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            self.ser.write(cmd)
            time.sleep(delay)
            return self.ser.read(len_to_read)
        
    def write_raw(self, cmd):
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            self.ser.write(cmd)

    def read_raw(self, len):
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            return self.ser.read(len)
