#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import logging
import re
import subprocess
import sys
import threading
from queue import Queue

from ucitool.base_uci.uci import Uci
from ucitool.uwb_devices.uwbdevice import UwbDevice

ADB_DEBUG = True
log = logging.getLogger()


class AsyncReader(threading.Thread):
    """
    Helper class to implement asynchronous reading of a file
    in a separate thread. Pushes read lines on a queue to
    be consumed in another thread.
    """

    def __init__(self, fd, queue):
        assert isinstance(queue, Queue)
        assert callable(fd.readline)
        threading.Thread.__init__(self)
        self._fd = fd
        self._queue = queue
        self.daemon = True

    def run(self):
        """The body of the thread: read lines and put them on the queue."""
        for line in iter(self._fd.readline, ''):
            self._queue.put(line)

    def eof(self):
        """Check whether there is no more content to expect."""
        return not self.is_alive() and self._queue.empty()


class Android(UwbDevice):
    def __init__(self, serial_no=1):
        super().__init__()
        self.__name = None
        self.id = None
        self.logcat_process = None
        self.adb_log_fname = None
        self.serial_no = serial_no  # default to first connected device
        self.logcat_p = None
        self.logcat_q = Queue()
        self.logcat_f = None
        self.logcat_r = None

    def initialize(self, dev_config, uci_handler=None):
        self.devcfg = dev_config
        log.info(sys._getframe().f_code.co_name)
        self.interface_type = dev_config.interface_config.type
        self.port = dev_config.interface_config.port
        self.id = dev_config.id
        self.serial_no = dev_config.interface_config.serial_no
        self.uci_supported = dev_config.uci_support
        self.variant = dev_config.variant
        self.get_adb()

    def open(self):
        pass

    def close(self):
        pass

    def read(self, len, timeout=2):
        pass

    def write(self, data):
        pass

    def adb_pull(self, remote, local='.'):
        self.adb('pull {} {}'.format(remote, local))

    def adb_push(self, remote, local):
        self.adb('push {} {}'.format(local, remote))

    def adb(self, cmd):

        adb_cmd = 'adb -s {} {}'.format(self.serial_no, cmd)
        try:
            log.debug('\t[ADB]\t\t{}'.format(adb_cmd))
            rsp = subprocess.check_output(adb_cmd.split()).strip()
            if rsp:
                return rsp.decode()
        except subprocess.CalledProcessError as e:
            log.error('\t[ADB][ERROR]\t\tADB command Not executed- {}\n{}'.format(adb_cmd, e))

    def shell(self, cmd):
        return self.adb('shell {}'.format(cmd)).decode()

    def get_adb(self):
        devices = subprocess.check_output(['adb', 'devices'], shell=True).decode()

        devdict = {}
        try:
            for dev in devices.split('\r\n')[1:]:
                if dev:
                    devdict[(dev.split('\t')[0])] = dev.split('\t')[1]
            if len(str(self.serial_no)) == 1:
                self.serial_no = list(devdict.keys())[int(self.serial_no) - 1]
            if self.serial_no not in devdict.keys():
                log.error("\t[ADB][ERROR]\t\tAdb device {} not connected".format(self.serial_no))
            if devdict[self.serial_no] == 'device':
                self.adb('root')
                self.adb('remount')
                return self.serial_no
            log.error("\t[ADB][ERROR]\t\tReconnect/Authorise device and try again!")
        except IndexError:
            log.error("\t[ADB][ERROR]\t\tNo adb devices connected")
        return False

    def clear_logcat(self):
        self.shell('logcat -c')

    def start_logcat(self):
        self.clear_logcat()  # clearing existing logs to get fresh sniff
        self.logcat_p = subprocess.Popen(['adb', '-s', self.serial_no, 'logcat', '-v', 'threadtime'],
                                         stdout=subprocess.PIPE)
        self.logcat_r = AsyncReader(self.logcat_p.stdout, self.logcat_q)
        self.logcat_r.start()

    def get_logcat_lines(self, number_of_lines=1):
        log = []
        for _ in range(0, number_of_lines):
            l = self.logcat_q.get()
            log.append(l.strip())
            # self.save_logs(l)
        return log

    def save_logs(self, line):
        self.logcat_f = '{}_logcat_uci_sniff.log'.format(self.serial_no)
        with open(self.logcat_f, 'ab') as f:
            f.write(line)


# def sniff_live():
#     # Check the queues if we received some output (until there is nothing more to get).
#     try:
#         self.start_logcat()
#         while a.logcat_r.eof():
#             while self.sniff_on and not self.hud.logcat_q.empty():
#                 try:
#                     match = re.search('NxpUci.*len.*=.*>(.*)', self.hud.get_logcat_lines()[0].decode())
#                     if match:
#                         self.parse_uci_hex_str(match.group(1).strip())
#                 except UnicodeDecodeError:
#                     pass
#     except KeyboardInterrupt:
#         self.sniff_on = False
#         self.hud.logcat_p.kill()
#         raise
#     finally:
#         self.hud.logcat_p.kill()

if __name__ == '__main__':
    a = Android()
    a.get_adb()
    a.start_logcat()
    while a.logcat_r.eof():
        while not a.logcat_q.empty():
            try:
                match = re.search('NxpUci.*len.*=.*>(.*)', a.get_logcat_lines()[0].decode())
                if match:
                    Uci(uci_hex_str=match.group(1).strip())
            except UnicodeDecodeError:
                pass
