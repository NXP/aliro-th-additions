# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#
"""
uci class.
    uciHost - > uwb device host class
    UwbDeviceCfg - > uwb device config
    ConfigGetBuilder - > helper class to build getconfig uci
    ConfigSetBuilder - > helper class to build setconfig uci
"""
import datetime
import logging
import math
import os
import re
import threading
from collections import OrderedDict
import time
from ctypes import sizeof
from enum import Enum
from functools import lru_cache

import yaml
from serial.tools import list_ports

from ucitool.UciGenerator import get_uci_def, BASE_UCI
from ucitool.base_uci.cmds import Cmds
from ucitool.base_uci.uci_handler import UciHandler
from ucitool.uwb_devices.device_factory import DeviceFactory

MAX_FIELD_PRINT_SZ = 512  # screen buffer causes delay and if someone prints CIR unknowingly it will affect performance
ts = datetime.datetime.now
uci_def = {}
logging.basicConfig(format='%(message)s', level=logging.INFO)
log = logging.getLogger()


class UciException(Exception):
    """One place to handle all exceptions happening at runtime"""

    def __init__(self, value):
        self.value = value

    def __str__(self):
        log.error(self.value)
        return self.value


class UciFieldTypes(Enum):
    c_uint32 = 4  # unsigned int
    c_uint16 = 2  # unsigned short
    c_uint8 = 1  # unsigned char
    bytearray = None

    @classmethod
    def has_field(cls, value):
        return value in cls.__members__


def uci2dict(o, di):
    dic = o if isinstance(o, dict) else vars(o)
    for k, v in dic.items():
        if type(v) == 'collections.OrderedDict': continue
        if isinstance(v, (str, int, float, bool, list, tuple, set)) or v in (None, {}):
            di[k] = v
        elif isinstance(v, (bytearray, bytes)):
            di[k] = v.hex()
        elif v:
            di[k] = {}
            uci2dict(v, di[k])  # recurse inside
    return di


class KeyVal(object):

    def __init__(self, k=None, v=None, id=None, k_id=None, pos_idx=None, attr=None):
        self.name = k
        self.raw_val = v
        self.val = self.analyze_val(attr, v)
        self.id = id
        self.key_id = k_id
        self.pos = pos_idx

    def analyze_val(self, key, val):
        if key is None:
            return val
        if key in {'AoA_Azi', 'AoA_Ele', 'AoADest_Azi', 'AoADest_Ele', 'PDOA1', 'PDOA2', 'AoA_PHASE',
                   'PDOA_OFFSET'}:  # signed Q9.7
            return self.convertQFormatToFloat(self.twos_complement(val, 16), 9, 7)
        elif key in {'RSSI', 'RSSI_RX1', 'RSSI_RX2', 'SNR_AVERAGE_RX1', 'SNR_AVERAGE_RX2'}:
            return self.convertQFormatToFloat(self.twos_complement(val, 16), 8, 8)  # signed Q8.8
        elif key in {'FIRST_PATH_INDEX', 'MAIN_PATH_INDEX'}:
            return self.convertQFormatToFloat(val, 10, 6, roundof=0)  # do not round off
        elif key in {'SNR_TOTAL'}:
            return self.convertQFormatToFloat(val, 8, 8)
        elif key in {'DEVICE_NAME'}:  # hex to ascii
            return bytes.fromhex(val.hex()).decode('utf-8').strip('\0')
        elif key in {'TIMESTAMP', 'TX_TIMESTAMP', 'RX_TIMESTAMP'}:
            return int.from_bytes(val, byteorder='little', signed=False)
        elif key in {'FW_VERSION', 'FIRA_UCI_GEN_VERSION', 'FIRA_UCI_TEST_VERSION'}:
            return '.'.join(re.findall(r'\d\d', val.to_bytes(3, 'little').hex()))
        return val

    def twos_complement(self, value, bits):
        value = int(value, 16) if isinstance(value, str) else value
        if value & (1 << (bits - 1)):
            value -= 1 << bits
        return value

    def convertQFormatToFloat(self, qIn, nInts, nFracs, roundof=2):
        intPart = (qIn >> nFracs)
        fracPart = qIn & ((1 << nFracs) - 1)
        fracPart = math.pow(2, -nFracs) * fracPart
        return round(intPart + fracPart, roundof) if roundof else intPart + fracPart


class ConfigGetBuilder:
    def __init__(self):
        self.data = []
        self.nparams = 0

    def add_attr(self, *attrs):
        for attr in attrs:
            if not hasattr(attr, 'TAG_ID'):
                raise UciException(
                    'TAG_ID not found, This attribute {} is not added in def properly'.format(attr.__name__))
            self.data.extend(attr.TAG_ID)
            self.nparams += 1
        return self  # for chaining of methods

    def get(self):
        return self.data


class ConfigSetBuilder:
    def __init__(self):
        self.data = []
        self.nparams = 0

    def add_attr(self, tag, val, len_of_l=1):

        if isinstance(val, int):
            p_len = max((val.bit_length() + 7) // 8, 1)  # this much bytes
            if hasattr(tag, 'LEN') and isinstance(tag.LEN, int):
                if p_len > tag.LEN:
                    raise UciException(
                        'Length mismatch error, passed val-{},As per uci def allowed length-{}'.format(p_len, tag.LEN))
                else:
                    p_len = tag.LEN
            val = list(val.to_bytes(p_len, 'little'))  # to support extend
        elif isinstance(val, (list, bytearray)):
            p_len = len(val)
        elif isinstance(val, str):
            val = [*bytes.fromhex(val)]
            p_len = len(val)
        else:
            raise UciException(
                'Value mismatch err! For tag - {}, int or array expected, Recv -{} '.format(val, tag.TAG))

        self.nparams += 1
        len_of_l = list(p_len.to_bytes(len_of_l, 'little'))
        self.data.extend(tag.TAG_ID + len_of_l + val)
        return self  # for chaining of methods

    def get(self):
        return self.data

    def __len__(self):
        return self.nparams


@lru_cache(maxsize=None)  # cache uci def for future to avoid yaml reload
def load_uci(ver=''):
    uci_yaml = os.path.join(BASE_UCI, 'defs', 'uci_def{}.yaml'.format('_{}'.format(ver) if ver else ''))
    if not os.path.exists(uci_yaml):
        log.error('Error: Unsupported UCI VER-{}, This version is not added in def'.format(ver))
        return False
    with open(uci_yaml, 'r') as stream:
        try:
            return yaml.safe_load(stream)
        except yaml.YAMLError as e:
            log.error('Error loading uci defs {} {}'.format(uci_yaml, e))
    return None


class Uci(object):
    def __init__(self, uci=None, payload=(), uci_bytedata=None, device=None, uci_hex_str=None, of=None,
                 disable_ntf_print=False, disable_uci_prints=False, uci_ver=None, print_mode=None):
        self.uci = uci
        self.mt = KeyVal('CMD', 0x1)  # default to cmd
        self.pbf = 0  # default
        self.header = None
        self.gid = KeyVal()
        self.oid = KeyVal()
        self.of = of
        self.payloadLen = 0
        self.disable_uci_prints = disable_uci_prints
        if not payload:
            self.payload = []
        self.extraPayLoad = None
        self.partialPayload = []
        self.sniff_mode = False
        self.uci_hex_str = uci_hex_str
        self.uci_raw_data = uci_bytedata
        self.uci_def = load_uci(uci_ver) if uci_ver else get_uci_def()
        self.oid_def = self.uci_def['OID']
        self.attr_def = self.uci_def['STATUS']
        self.uci_struct = None
        self.rsp_str = ''
        self.fields = {}
        self.sub_fields = {}
        self.uci_str = None
        self.uci_proto = None
        self.vs_data = None
        self.dep_offset = 0  # this offset wil applied to field if field depends on other fields
        if device:
            if not isinstance(device, UwbDeviceCfg):
                device = device.devcfg
            self.device = '{}{} '.format('{}@'.format(device.interface_config.id) if device.interface_config.id else '',
                                         device.interface_config.com_port)
        else:
            self.device = ''
        self.uci_print_str = []
        self.disable_ntf_print = disable_ntf_print
        try:
            if uci_hex_str:
                uci_hex_str = re.sub(r'[:\s]', '', uci_hex_str)
                self.uci_raw_data = bytearray(bytes.fromhex(uci_hex_str))
                if ':' not in uci_hex_str:
                    self.uci_hex_str = ':'.join(uci_hex_str[i:i + 2] for i in range(0, len(uci_hex_str), 2))
            if uci_bytedata:
                self.uci_hex_str = uci_bytedata.hex()
                self.uci_raw_data = uci_bytedata
            self.generate_uci()
        except (KeyError, ValueError, IndexError) as er:
            log.error('Error parsing uci- {}, {} {}'.format(self.uci_hex_str, self.uci if self.uci else 'Not proper UCI:',
                                                        str(er)))

    def generate_uci(self):
        if self.uci:  # construct uci bytearray : check uci struct in yaml and generate fields and payload
            self.uci_str = self.uci.__name__[1:] if not isinstance(self.uci, str) else self.uci

            self.uci_proto = getattr(Cmds, self.uci_str)
            if self.uci_str not in self.uci_def['DEF']:
                raise UciException('Undefined UCI cmd {}'.format(self.uci))  # validating UC
            if hasattr(Cmds, 'DATA_PKT') and self.uci_str == Cmds.DATA_PKT.__name__:
                self.mt = KeyVal('DAT', 0)
            uci_struct = {**self.uci_def['DEF'][self.uci_str]}  # shallow copy ?
            self.gid.val = uci_struct['GID']
            self.gid.name = self.mt.val and self.uci_def['GID'][self.gid.val]
            if hasattr(Cmds, 'DATA_MSG_SND') and self.uci_str == Cmds.DATA_MSG_SND.__name__:
                self.mt = KeyVal('DAT', 0)
                self.gid.name = self.attr_def['DPF'][self.gid.val]
            self.oid.val = uci_struct['OID']
            self.oid.name = self.mt.val and self.uci_def['OID'][self.gid.val][self.oid.val]
            self.fields = dict(GID=self.gid, OID=self.oid, MT=self.mt)
            self.pack_payload(uci_struct)
            self.payloadLen = len(self.payload)
            o0 = (self.mt.val << 5) + (self.pbf << 4) + self.gid.val  # octet 1
            o1 = self.oid.val  # octet 2
            o2o3 = self.payloadLen.to_bytes(2, 'big')
            if self.gid.name == 'DATA_MSG_SND':
                o2o3 = self.payloadLen.to_bytes(2, 'little')
            elif self.payloadLen > 0xFF:
                o1 |= 0x80
                o2o3 = self.payloadLen.to_bytes(2, 'little')
            self.header = bytearray([o0, o1]) + o2o3
            self.uci_raw_data = self.header + bytearray(self.payload)
            self.uci_hex_str = self.uci_raw_data.hex()
        elif self.uci_raw_data:  # Parse UCI: unwrapping uci bytearray in to fields
            o0 = self.uci_raw_data[0]  # octet0
            o1 = self.uci_raw_data[1]
            o2o3 = self.uci_raw_data[2:4]
            self.epl = o1 >> 7  # extended payload length
            self.payloadLen = self.get_int_from_bytes(o2o3, [1, 0][self.epl], 2, byteorder='little')
            self.mt.val = self.get_bit_field_from_octet(o0, 5, 8)
            self.mt.name = self.uci_def['MT'][self.mt.val]
            self.pbf = self.get_bit_field_from_octet(o0, 4, 5)
            self.gid.val = self.get_bit_field_from_octet(o0, 0, 4)
            self.gid.name = self.mt.val and self.uci_def['GID'][self.gid.val]  # for self.mt.val - 0 for data,
            if not self.mt.val and self.gid.val:  # new data packet format
                self.gid.name = self.attr_def['DPF'][self.gid.val]
                self.payloadLen = self.get_int_from_bytes(o2o3, 0, 2, byteorder='little')
            self.oid.val = self.get_bit_field_from_octet(o1, 0, 6)
            self.oid.name = self.mt.val and self.uci_def['OID'][self.gid.val][self.oid.val]
            self.fields = dict(GID=self.gid, OID=self.oid, MT=self.mt)
            self.payload = self.uci_raw_data[4:]
            try:
                self.uci_str = self.mt.val and self.oid_def[self.gid.val][self.oid.val] or 'DATA_PKT'
                if not self.mt.val and self.gid.val:  # new data packet format
                    self.uci_str = self.attr_def['DPF'][self.gid.val]
                self.uci_struct = {**self.uci_def['DEF'][self.uci_str]}
                self.unpack_payload()
            except KeyError:
                self.uprint('Unknown UCI cmd {}:{}, Not added in def'.format(self.uci_str, self.uci_raw_data.hex()))

        self.print_uci()

    def pack_payload(self, uci_struct):
        pack_type = 'CMD'  # if self.uci.__name__ == Cmds.DATA_PKT else 'DAT'
        if pack_type in uci_struct:
            for field, length in uci_struct[pack_type].items():
                if not hasattr(self.uci, field):
                    raise UciException('UciPackError: Field {} missing in UCI {}'.format(field, self.uci.__name__))
                f_type = getattr(self.uci_proto, field)
                f_value = getattr(self.uci, field)
                r_value = None

                try:
                    if field.upper().endswith('_TLV'):
                        self.resolve_tlv(f_value, field)
                    elif field.upper().endswith('_PARAMS'):
                        self.resolve_tags(f_value, field)
                    elif field in self.attr_def.keys() and f_value in self.attr_def[field]:
                        r_value = self.attr_def[field][f_value]
                except:
                    log.error('Error decode CMD')

                if isinstance(f_value, int):
                    f_len = max((f_value.bit_length() + 7) // 8, 1)  # this much bytes
                    f_value = bytearray(f_type(f_value))
                elif isinstance(f_value, (list, bytearray)):
                    f_len = len(f_value)
                else:  # uci field must be of int, list, bytearray
                    raise UciException(
                        'UciPackError: No data given for field {}, expected {} data'.format(field, f_type))
                if f_type != bytearray and (f_len > sizeof(f_type)):
                    raise UciException(
                        'Length mismatch for field, Given {} len= {}, Allowed- {} '.format(f_value, f_len,
                                                                                           sizeof(f_type)))
                if not (field.upper().endswith('_TLV') or field.upper().endswith('_PARAMS')):
                    self.fields[field] = KeyVal(f_value, r_value, pos_idx=[len(self.payload), len(f_value)], attr=field)
                self.payload.extend(f_value)

        if self.payload and self.extraPayLoad and len(self.extraPayLoad) + len(self.payload) > 252:
            self.pbf = 1

    def resolve_tags(self, payload, tag_val_field, start=0, end=0, pos_offset=0):
        resolve_status = True if '_FAIL_' in tag_val_field else False
        tag_val_field = '{}_TLV'.format(tag_val_field.split('_')[0])
        tv_def = self.attr_def[tag_val_field]
        idx = 0
        while payload:  # todo what if full payload are not tags, here payload is fully consumed
            start = 1

            sub_tag = None
            t = payload[0]
            name = t
            if t >= 0xE0:  # extended app config tag is of length 2
                sub_tag = payload[1]
                start += 1
            r_tag = None
            if t in tv_def:
                if sub_tag is not None:
                    tag = tv_def[t][sub_tag]['TAG'] if sub_tag in tv_def[t] else 'UNKNOWN_TAG'
                    name = '{}{}'.format(sub_tag, t)
                else:
                    tag = tv_def[t]['TAG']
                    name = t
            else:
                self.uprint('Undefined parameter id received {}'.format(t))
                tag = 'UNKNOWN_PARAM'
            if resolve_status:
                start += 1
                status = payload[1] if sub_tag is None else payload[2]
                r_tag = self.attr_def['UCI_STATUS'][status]

            self.fields[tag] = KeyVal(r_tag, name, pos_idx=[idx + pos_offset, start - 1], attr=tag)
            idx += start
            payload = payload[start:]
        return payload

    def get_field_boundary(self, attr, field):
        start, end, fname = 0, 0, attr

        if '-' in field:
            field = field.split('-')
            start = field[0]
            end = field[1]
            if '|' in end:
                end = end.split('|')
                if '_DEPEND_' in attr:
                    attr = attr.split('_DEPEND_')
                    fname = attr[0]
                    attr = attr[1].split('_VAL_')
                    dependent = attr[0]
                    if dependent in self.fields:
                        end = end[attr[1].split('_').index(str(self.fields[dependent].val))]
                        self.dep_offset = int(end) - int(start)
                    elif dependent.startswith('EVAL_'):
                        end = end[attr[1].split('_').index(str(eval(dependent.replace('EVAL_', ''))))]
                        self.dep_offset = int(end) - int(start)

        return int(start), int(end), fname

    def resolve_tlv(self, payload, tlv_field, start=0, end=0, pos_offset=0):
        start, end, idx = 0, 0, 0
        tlv_def = self.attr_def[tlv_field]
        while payload:
            start, end, sub_tag = 0, 0, None  #
            t, ln = payload[0], payload[1]  # ln-length, len shadows builtin
            start = 2
            if t >= 0xE0:  # extended app config tag is of length 2
                sub_tag = payload[1]
                if sub_tag == 0x24:
                    ln = self.get_int_from_bytes(payload, 2, 4)  # WAR for PSDU DATA
                    start = 4
                else:
                    ln = payload[2]
                    start = 3
            end = start + ln
            v = self.get_int_from_bytes(payload, start, end)  # if len is zero it wil get handled here
            r_tag = None
            if t in tlv_def:
                if sub_tag is not None:
                    tag = tlv_def[t][sub_tag]['TAG'] if sub_tag in tlv_def[t] else 'UNKNOWN_TAG'
                    if isinstance(v, int):
                        r_tag = tlv_def[t][sub_tag][v] if (sub_tag in tlv_def[t] and v in tlv_def[t][sub_tag]) else None
                else:
                    tag = tlv_def[t]['TAG']
                    if isinstance(v, int):
                        r_tag = tlv_def[t][v] if v in tlv_def[t] else None
                    if not r_tag and tag.endswith('STATUS') and tag in self.attr_def:
                        r_tag = self.attr_def[tag].get(v, None)

            else:
                self.uprint('Undefined parameter id received {}'.format(t))
                tag = 'UNKNOWN_PARAM'

            self.fields[tag] = KeyVal(r_tag, v, '0x{:x}{:x}'.format(sub_tag, t) if sub_tag else hex(t),
                                      pos_idx=[idx + pos_offset, end], attr=tag)
            if sub_tag is not None:
                if t in tlv_def and tag in tlv_def[t][sub_tag]:
                    self.parse_by_index(payload[start:end], tlv_def[t][sub_tag][tag])
            else:
                if t in tlv_def and tag in tlv_def[t]:
                    self.parse_by_index(v, tlv_def[t][tag])
            idx += end
            payload = payload[(start + ln):]
        return payload

    def parse_list(self, payload, parse_struct, num_list=1):
        fields = {}
        tot = len(payload)
        i = 1
        while i <= num_list and payload:
            for field, attr in parse_struct.items():
                if '-' in str(field):
                    start, end = [int(x) if x.isnumeric() else x for x in field.split('-', maxsplit=1)]
                    if isinstance(end, int):
                        end += 1
                    elif end == 'n':
                        end = len(payload)
                    elif '|' in end:
                        start, end, attr = self.get_field_boundary(attr, field)
                        end += 1
                else:
                    start, end = field, field + 1
                f_value = self.get_int_from_bytes(payload, 0, end - start)
                r_value = None  # resolved field value
                if attr in self.attr_def.keys() and f_value in self.attr_def[attr]:
                    r_value = self.attr_def[attr][f_value]
                fields['{}{}'.format(attr, i)] = KeyVal(r_value, f_value,
                                                        pos_idx=[start, end - start],
                                                        attr=attr)  # value and resolved attribute
                payload = payload[(end - start):]
            i += 1
        return fields, tot - len(payload)

    def resolve_subfields(self, payload, no_of_subfields=float('inf'), subf_struct=None, pos_offset=0):

        i, pos_idx, depend_offset = 0, 0, 0
        tot = len(payload)
        self.sub_fields['BRIEF'] = ''

        while no_of_subfields and payload:
            if i not in self.sub_fields: self.sub_fields[i] = {}
            no_of_subfields -= 1
            for field, attr in subf_struct.items():
                start, end = 0, 1
                if field == 'BRIEF':
                    self.sub_fields['BRIEF'] = attr
                    continue
                if '-' in str(field):
                    field = field.split('-')
                    if '|' in field[1]:  # worst! some field's len dep on other fields.
                        field[0], field[1], attr = self.get_field_boundary(attr, '-'.join(field))
                        if field[0] >= field[1]:
                            continue
                    elif '_LEN_DEP_' in attr:
                        multiplier = 1
                        size_field = attr.split('_LEN_DEP_')[1]
                        if size_field.startswith('EVAL_'):
                            ln = eval(size_field.replace('EVAL_', ''))
                            size_field = 'EVALEXPR'
                        if '_' in size_field and size_field.split('_')[0].isdigit():
                            multiplier = int(size_field.split('_')[0])
                            size_field = '_'.join(size_field.split('_')[1:])

                        if size_field in self.sub_fields[i]:
                            ln = int(self.sub_fields[i][size_field].val)
                        elif size_field in self.fields:
                            ln = int(self.fields[size_field].val)
                        field[1] = int(field[0]) + ln * multiplier - 1
                        attr = attr.split('_LEN_DEP_')[0]
                    elif field[1] == 'n':
                        field[1] = len(payload)
                    end = int(field[1]) - int(field[0]) + 1
                if end - start <= 0: continue  # if payload size zero continue
                if attr.endswith('_LIST'):
                    p_struct_name = attr.split('_M_')[0]
                    if p_struct_name in self.uci_struct:
                        p_struct = self.uci_struct[p_struct_name]
                    else:
                        p_struct = self.uci_struct['VENDOR_SPECIFIC_DATA'][p_struct_name]
                    num_p_name = attr.split('_M_')[1].split('_LIST')[0]
                    num_p = self.sub_fields[i][num_p_name].val
                    parsed_list, end = self.parse_list(payload, p_struct, num_p)
                    self.sub_fields[i].update(parsed_list)
                else:
                    f_value = self.get_int_from_bytes(payload, start, end)
                    r_value = None  # resolved fiel
                    if attr in self.attr_def.keys() and f_value in self.attr_def[attr]:
                        r_value = self.attr_def[attr][f_value]

                    self.sub_fields[i][attr] = KeyVal(r_value, f_value,
                                                      pos_idx=[start + pos_idx + pos_offset,
                                                               end - start], attr=attr)  # value and resolved attribute
                pos_idx += end
                payload = payload[(end - start):]
            i += 1
        return tot - len(payload)

    def parse_by_index(self, payload, parse_def):
        for field, attr in parse_def.items():
            if '-' in str(field):
                field = field.split('-')
                start = field[0] = int(field[0], 16) if field[0].startswith('0x') else int(field[0])
                field[1] = int(field[1], 16) if field[1].startswith('0x') else int(field[1])
                end = len(payload) if field[1] == 'n' else field[1] + 1
            else:
                start, end = field, field + 1

            f_value = self.get_int_from_bytes(payload, start, end)
            r_value = None
            if attr in self.attr_def.keys() and f_value in self.attr_def[attr]:
                r_value = self.attr_def[attr][f_value]
            self.fields[attr] = KeyVal(r_value, f_value,
                                       pos_idx=[start, end - start],
                                       attr=attr)  # value and resolved attribute
            # payload = payload[(end - start):]

    def parse_fields(self, uci_struct, working_payload):
        offset = 0
        for field, attr in uci_struct.items():
            if not isinstance(attr, (str, int)): break
            if '-' in str(field):
                start, end = [int(x) if x.isnumeric() else x for x in field.split('-', maxsplit=1)]
                if isinstance(end, int):
                    end += 1
                elif end == 'n':
                    start, end = 0, len(working_payload)
                elif '|' in end:
                    start, end, attr = self.get_field_boundary(attr, field)
                    end += 1
            else:
                start, end = field, field + 1
            start, end = start + offset, end + offset
            if (end - start) > len(working_payload):
                self.partialPayload.append(attr)
            elif (end - 0) < 0:
                continue
            if '_LEN_DEP_' in attr:
                attr, size_field = attr.split('_LEN_DEP_')
                end = int(start) + int(self.fields[size_field].val)
            if attr.endswith('_LIST'):
                p_struct_name = attr.split('_M_')[0]
                if p_struct_name in self.uci_struct:
                    p_struct = self.uci_struct[p_struct_name]
                else:
                    p_struct = self.uci_struct['VENDOR_SPECIFIC_DATA'][p_struct_name]
                num_p_name = attr.split('_M_')[1].split('_LIST')[0]
                num_p = self.fields[num_p_name].val
                parsed_list, end = self.parse_list(working_payload, p_struct, num_p)
                end += start
                self.fields.update(parsed_list)
            elif attr.upper().endswith('_TLV'):
                working_payload = self.resolve_tlv(working_payload, attr)  # ret rem payload for further processing
                continue
            elif attr.upper().endswith('FAIL_STATUS'):
                working_payload = self.resolve_tags(working_payload, attr, pos_offset=start)
                continue
            elif attr == 'VENDOR_SPECIFIC_DATA':
                self.vs_data = working_payload
                return b''
            else:
                f_value = self.get_int_from_bytes(working_payload, 0, end - start)
                r_value = None  # resolved field value
                if attr.upper().endswith('_SUBFIELD'):
                    sub_attr = attr.split('_M_')[0]
                    sub_attr_num_attr = attr.split('_M_')[1].split('SUBFIELD')[0][:-1]
                    m_subfields = float('inf')

                    subf_struct = uci_struct[sub_attr]
                    if sub_attr_num_attr and sub_attr_num_attr in self.fields:
                        m_subfields = self.fields[sub_attr_num_attr].val
                    if sub_attr in self.fields and self.fields[sub_attr].val in uci_struct[sub_attr]:
                        subf_struct = uci_struct[sub_attr][self.fields[sub_attr].val]

                    if m_subfields:
                        offset = self.resolve_subfields(working_payload, m_subfields, subf_struct,
                                                        pos_offset=start)
                        end = start + offset
                    else:
                        end = start
                else:
                    if attr in self.attr_def.keys() and f_value in self.attr_def[attr]:
                        r_value = self.attr_def[attr][f_value]
                    self.fields[attr] = KeyVal(r_value, f_value,
                                               pos_idx=[start, end - start],
                                               attr=attr)  # value and resolved attribute
            working_payload = working_payload[(end - start):]
        return working_payload

    def unpack_payload(self):
        uci_struct = self.uci_struct
        offset = 0
        working_payload = self.payload
        fields = {}
        if self.mt.name == 'CMD':
            idx = 0  # to track index
            if 'CMD' in uci_struct:  # NO payload UCIs exist
                for attr, f_type in uci_struct['CMD'].items():
                    if attr.upper().endswith('_TLV'):
                        working_payload = self.resolve_tlv(working_payload, attr, pos_offset=idx)
                        continue  # TODO what if any field after TLV? to be handled
                    if attr.upper().endswith('_PARAMS'):
                        working_payload = self.resolve_tags(working_payload, attr, pos_offset=idx)
                        continue
                    f_type = UciFieldTypes[f_type].value
                    f_value = self.get_int_from_bytes(working_payload, 0, f_type)
                    r_value = None  # resolved field value
                    if attr in self.attr_def.keys() and f_value in self.attr_def[attr]:
                        r_value = self.attr_def[attr][f_value]
                    if isinstance(f_value, bytearray):
                        f_value = ':'.join([hex(x)[2:] for x in f_value])
                    self.fields[attr] = KeyVal(r_value, f_value, pos_idx=[idx, f_type],
                                               attr=attr)  # value and resolved attribute
                    if f_type:
                        idx += f_type
                    else:
                        idx += len(working_payload)
                    working_payload = working_payload[f_type:] if f_type else []
        else:
            working_payload = self.parse_fields(uci_struct[self.mt.name], working_payload)
        if self.vs_data:
            working_payload += self.parse_fields(uci_struct['VENDOR_SPECIFIC_DATA'], self.vs_data)
        if working_payload:
            self.extraPayLoad = working_payload  # need to track extra payload which is undefined

    def print_uci(self):
        subf_pkt, subf_val, p = [], '', []

        def stringify(fields, aslist=None):
            uci_pkt, uci_val = ([], []) if aslist else ('', '')
            for k, v in fields.items():
                name, v, id = v.name, v.val, v.id
                v = v.hex() if isinstance(v, (bytes, bytearray)) else hex(v) if isinstance(v, int) else v
                name = name.hex() if isinstance(name, (bytes, bytearray)) else hex(name) if isinstance(name,
                                                                                                       int) else name
                if isinstance(v, (str, bytearray, list)): v = v[:MAX_FIELD_PRINT_SZ]

                v = '{}{}{}'.format('' if v is None else '{}'.format(v),
                                    '' if v is None or name is None else ':',
                                    '' if name is None else '{}'.format(name))[:MAX_FIELD_PRINT_SZ]

                k = '{}{}'.format('{}:'.format(id) if id else '', k)[:MAX_FIELD_PRINT_SZ]
                pad = max(len(str(k).strip()), len(str(v).rstrip('\x00'))) + 1
                if aslist:
                    uci_pkt.append(k)
                    uci_val.append(v)
                else:
                    uci_pkt += '|{message: <{fill}}'.format(message=k, fill=pad)
                    uci_val += '|{message: <{fill}}'.format(message=v, fill=pad)
            return uci_pkt, uci_val

        p.append('\n{}UCI_{}: {}'.format(self.device, self.mt.name, self.uci_str))
        p.append('RAW: {}'.format(self.uci_hex_str)[:MAX_FIELD_PRINT_SZ])
        p.extend(stringify(self.fields))  # stringify fields

        subf_table = []
        for sl_no, v in self.sub_fields.items():  # each subfeild item has to be stringified
            if isinstance(sl_no, int):
                pkt_str = stringify(v, aslist=True)
                subf_table += pkt_str if not sl_no else [pkt_str[1]]
        if subf_table:  # find longest string in each col to align elements in col
            longest_cols = [len(max(r, key=len)) + 1 for r in zip(*subf_table)]
            row_format = "|".join(["{:<" + str(longest_col) + "}" for longest_col in longest_cols])
            p.append(self.sub_fields['BRIEF'])
            for row in subf_table:
                p.append('|' + row_format.format(*row))
        self.uci_print_str = p  # copy for later print
        if self.extraPayLoad:
            self.uprint('Extra payload received, No response field defined for -{}'.format(self.extraPayLoad))
        if self.partialPayload:
            self.uprint('Incomplete payload received for fields: {}'.format(",".join(self.partialPayload)))
        self.uprint('\n'.join(p))  # print all at one shot as single str to avoid race condn from other threads
        return p

    @staticmethod
    def get_bit_field_from_octet(number, start_pos, end_pos):
        mask = 0
        for b in range(start_pos, end_pos):  # create mask
            mask |= 1 << b
        return (number & mask) >> start_pos

    @staticmethod
    def get_int_from_bytes(bytes_data, start, end, byteorder='little'):
        end = len(bytes_data) if not end else end
        if end - start < 5:  # max 4 bytes are converted to integer, rest assume to be byte string
            # return bytes_data[start:end].hex()
            return int.from_bytes(bytes_data[start:end], byteorder=byteorder, signed=False)
        else:
            return bytes_data[start:end]

    def uprint(self, msg):

        with threading.Lock():
            if self.of:
                fd = self.of
                if isinstance(fd, str):
                    fd = open(self.of, 'a')
                fd.write(msg + '\n')
                if fd and isinstance(self.of, str):
                    fd.close()
			#as per [artf994157]
            # or (self.gid.val == 0x09 and self.oid.val ==0x0A ):
            if self.disable_uci_prints or (self.disable_ntf_print and self.mt.name == 'NTF'):
                return
            log.info(msg)


class UwbDeviceCfg:
    """
    Device Config class
    """
    FIRA_VCOM = 'FIRA_VCOM'
    RHODES = 'RHODES'
    CNTX = 'CONTRONIX'
    ADB = 'ANDROID'
    SIM = 'SIMX86'
    ANDROID_UCI = 'ANDROID_UCI'
    DUMMY = 'DUMMY'
    RHODES_WINUSB = 'RHODESV3'
    SER2NET = 'SER2NET'
    MQTTDEV = 'MQTTDEV'
    SOCKET = 'SOCKET'
    ARMADO = 'ARMADO'
    CRETE = 'CRETE'

    DEVICES = set()
    PIDVID = {(0x94, 0x1fc9): RHODES, (0x5740, 0x483): CNTX, (0x6015, 0x403): RHODES}
    UCI_READY_MODE = False

    def __init__(self, type=None, ip=None, id=None, port=None, rhodes_ser=None, adb_ser=None, variant=None,
                 interface_type=None, ser_props=None, log_file=None):
        """
        Initialize UwbDeviceCfg
        Args:
            type: device type
            ip: ip address
            id: id of device
            port: port used for communication
            rhodes_ser: serial number for rhodes
            adb_ser: serial number of adb device
            variant: variant of device
            interface_type: type of interface
            ser_props: a dictionary. Allowed keys are: baudrate, bytesize, parity, stopbits, timeout, xonxoff, rtscts, write_timeout, dsrdtr, inter_byte_timeout, exclusive.
                       Example: ser_props={'baudrate': 3000000, 'rtscts': True}
            log_file: log file path. If given, all logging will be directed to log file instead of console
        """
        self.dev_type = type
        self.variant = variant
        self.interface_config = self  # variety WAR to match UTF
        self.interface_config.ip_addr = ip
        self.interface_config.com_port = port
        self.interface_config.port = port  # ip port in case of CNTX UDP
        self.interface_config.id = id if id else 'dev'
        self.interface_config.uci_support = True
        self.interface_config.serial_no = rhodes_ser or adb_ser
        self.interface_config.type = interface_type  # todo handle this when same device with multiple interface comes
        self.interface_config.ser_props = ser_props
        if log_file:
            try:
                if not os.path.isfile(log_file):
                    open(log_file, 'w').close()
                if log.handlers and 'StreamHandler' in str(log.handlers[-1]):
                    log.handlers.pop(-1)
                log.addHandler(logging.FileHandler(log_file))
            except Exception as err:
                log.error("Could not create log file: {}. Error: {}".format(log_file, err))

    @staticmethod
    def cleanup_devices():
        for d in UwbDeviceCfg.DEVICES:
            d.close()
        UwbDeviceCfg.DEVICES.clear()

    @staticmethod
    def set_uci_ready_mode():
        for d in UwbDeviceCfg.DEVICES:
            d.set_uci_read_mode(True)


class UciHost:
    """
    UciHost: This can be Rhodes, STM-Cntx, ADB
    Abstract methods needed for a ucihost device to exec, get rsp, read ntf.
    """

    def __init__(self, dev_config=None, port=None, ip=None, adb_ser=None, id=None, type=None, ser_props=None, log_file=None):
        self.port = port
        self.ip = ip
        self.device = None  # helios uwb device object
        self.sniff_on = False
        self.output_file = None
        self.type = type
        self.dev_cfg = dev_config if dev_config else UwbDeviceCfg(port=port, ip=ip, adb_ser=adb_ser, id=id, type=type, ser_props=ser_props, log_file=log_file)
        try:
            self.device_host = self.get_hud()
        except Exception as e:
            log.error('com port/{} ?'.format(e))

    def cleanup(self):
        if self.device:
            self.device.cleanup()
        self.sniff_on = False

    def get_hud(self):
        if self.type:
            pass
        elif self.ip:
            if not self.dev_cfg.dev_type:
                self.dev_cfg.dev_type = UwbDeviceCfg.SIM
        elif self.port:  # to detect rhodes or stm
            if UwbDeviceCfg.RHODES_WINUSB in self.port:  # rhodes winusb name = RHODESV3_MACADDR
                self.dev_cfg.dev_type = UwbDeviceCfg.RHODES_WINUSB
            else:
                self.dev_cfg.dev_type = UwbDeviceCfg.FIRA_VCOM
                for p in list_ports.comports():
                    if p.device.upper() == self.port.upper() and (p.pid, p.vid) in UwbDeviceCfg.PIDVID:
                        self.dev_cfg.dev_type = UwbDeviceCfg.PIDVID.get((p.pid, p.vid))
                        break
        else:
            self.dev_cfg.dev_type = UwbDeviceCfg.DUMMY
        self.device = DeviceFactory().get_device(self.dev_cfg)  # make device object
        self.hud_init()
        UwbDeviceCfg.UCI_READY_MODE and self.device.set_uci_ready_mode(UwbDeviceCfg.UCI_READY_MODE)
        return self.dev_cfg.dev_type

    def disable_ntf_prints(self, disable=True):
        self.device.uci_handler.skip_parse = disable
        self.device.uci_handler.disable_ntf_print = disable

    def disable_uci_prints(self, disable=True):
        self.device.uci_handler.skip_parse = disable
        self.device.uci_handler.disable_uci_print = disable

    def enable_cir_logging_to_files(self, enable=True):
        self.device.uci_handler.cir_logging = enable

    def hud_init(self):
        if not self.device:
            raise UciException('[ERROR]\t\tDevice {} not connected'.format(self.port))
        self.device.initialize(self.dev_cfg)
        self.device.set_uci_handler(UciHandler(self.dev_cfg.id, Uci))
        log.info('\t[DEVICE]\tInitialize Device: {} {}'.format(self.dev_cfg.dev_type,
                                                            'Port:{}'.format(self.port) if self.port else ''))
        UwbDeviceCfg.DEVICES.add(self.device)
        return self.device.open()

    def generate_uci(self, uci=None, payload=(), uci_bytedata=None, uci_hex_str=None):
        device = self.dev_cfg
        of = self.output_file
        return Uci(uci=uci, payload=payload, uci_bytedata=uci_bytedata, device=device, uci_hex_str=uci_hex_str, of=of,
                   disable_uci_prints=self.device.uci_handler.disable_uci_print,
                   uci_ver=self.device.uci_handler.uci_ver)

    def exec_uci(self, uci, *args):
        uci = self.generate_uci(uci=uci, payload=args)
        if self.dev_cfg.dev_type == UwbDeviceCfg.DUMMY:
            return uci
        return self.device.uci_cmd_rsp(uci.uci_raw_data)

    def send_uci(self, uci, *args):
        uci = self.generate_uci(uci=uci, payload=args)
        if self.dev_cfg.dev_type == UwbDeviceCfg.DUMMY:
            return uci
        return self.device.send_uci(uci.uci_raw_data)

    def sendRawCmd(self, uci_raw_data):
        if isinstance(uci_raw_data, str):
            uci_raw_data = bytes.fromhex(re.sub(r'[:\s]', '', uci_raw_data))
        return self.device.uci_cmd_rsp(uci_raw_data)

    def wait_for_notification(self, timeout=2, ntf=None, field=None, subfield=None, subf_id=0, value=None, debug=False):
        t1 = time.time()
        read_ntf = self.read_notification()
        while time.time() - t1 <= timeout:
            debug and read_ntf and log.info(read_ntf.uci_str)
            if read_ntf and read_ntf.uci_str == ntf.__name__:
                try:
                    if field:
                        if read_ntf.fields[field].val == value:
                            return read_ntf
                        else:
                            continue
                    elif subfield:
                        if read_ntf.sub_fields[subf_id][subfield].val == value:
                            return read_ntf
                        else:
                            continue
                except:
                    continue
                return read_ntf
            read_ntf = self.read_notification()
        return None

    def read_notification(self, timeout=1):
        return self.device.uci_read_ntf(timeout)

    def read_raw_notification(self, timeout=1):
        return self.device.uci_read_raw_ntf(timeout)

    def enable_logging(self, logfile):
        pass

    def set_uci_ready_mode(self, enable=True):
        return self.device.set_uci_ready_mode(enable)

    def set_of_handler(self, filename):
        """pass filename or file object"""
        output_file = filename
        if isinstance(filename, str):
            output_file = open(filename, 'w')
        assert callable(output_file.readline), 'Invalid outfile, Logging may be skipped'
        self.output_file = output_file
        self.device.uci_handler.output_file = self.output_file
        return self.output_file

    def set_uci_version(self, ver: str):
        self.device.uci_handler.uci_ver = ver


if __name__ == '__main__':
    a = Uci(uci_hex_str='2004000501E4330101')
    print(a)
