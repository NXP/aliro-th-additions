#
# Copyright 2024 NXP
# SPDX-License-Identifier: Apache-2.0
#

"""
!!! WARNING!!! DO NOT MODIFY THIS FILE
This file is auto generated from the def file - project/uci_def_<ver>.yaml.
If any modifications needed, please modify the def file.
"""

from ctypes import c_uint32, c_uint16, c_uint8, c_uint64
from copy import deepcopy
from typing import TypeVar
Cls = TypeVar('Cls')

def get_uci(cls: Cls) -> Cls:
    """
    parameters and return annotaions- dirty lie to make autocomplete and static
    analyzers give more useful results.
    :param cls:
    :return: copy of a class
    """
    copy_cls = type(f'_{cls.__name__}', cls.__bases__, dict(cls.__dict__))
    for name, attr in cls.__dict__.items():
        try:
            hash(attr)
        except TypeError:
            # Assume lack of __hash__ implies mutability. This is NOT
            # a bullet proof assumption but good in our case.
            setattr(copy_cls, name, deepcopy(attr))

    return copy_cls


class APP_CFG:
    class DEVICE_TYPE:
        TAG_ID = [0]
        LEN = 1
        TAG = 'DEVICE_TYPE'
        CONTROLEE = 0
        CONTROLLER = 1
    class RANGING_ROUND_USAGE:
        TAG_ID = [1]
        LEN = 1
        TAG = 'RANGING_ROUND_USAGE'
        DS_TWR = 2
    class STS_CONFIG:
        TAG_ID = [2]
        LEN = 1
        TAG = 'STS_CONFIG'
        NO_SE_STATIC_STS = 0
        SE_DYNAMIC_STS = 1
        SE_DYNAMIC_STS_FOR_CONTROLEE_INDIVIDUAL_KEY = 2
        PROVISIONED_STS = 3
        PROVISIONED_STS_SUB_SESSION_KEY = 4
    class MULTI_NODE_MODE:
        TAG_ID = [3]
        LEN = 1
        TAG = 'MULTI_NODE_MODE'
        SINGLE_DEVICE_TO_SINGLE_DEVICE = 0
        ONE_TO_MANY = 1
        MANY_TO_MANY = 2
        RESERVED = 3
    class CHANNEL_ID:
        TAG_ID = [4]
        LEN = 1
        TAG = 'CHANNEL_ID'
        CH_5 = 5
        CH_6 = 6
        CH_8 = 8
        CH_9 = 9
        CH_10 = 10
        CH_12 = 12
        CH_13 = 13
        CH_14 = 14
        N = 'CH'
    class NUMBER_OF_CONTROLEES:
        TAG_ID = [5]
        LEN = 1
        TAG = 'NUMBER_OF_CONTROLEES'
        SINGLE_ANCHOR = 1
    class SRC_MAC_ADDRESS:
        TAG_ID = [6]
        LEN = [2, 8]
        TAG = 'SRC_MAC_ADDRESS'
        MASTER_ADDR = 35840
    class DST_MAC_ADDRESS_LIST:
        TAG_ID = [7]
        LEN = '2 * NUMBER_OF_CONTROLEES'
        TAG = 'DST_MAC_ADDRESS_LIST'
        ANCHOR_ADDR = 36096
    class SLOT_DURATION:
        TAG_ID = [8]
        LEN = 2
        TAG = 'SLOT_DURATION'
        DEFAULT_RANGING = 2400
    class RANGING_DURATION:
        TAG_ID = [9]
        LEN = 4
        TAG = 'RANGING_DURATION'
        DEFAULT_RANGING = 200
    class STS_INDEX:
        TAG_ID = [10]
        LEN = 4
        TAG = 'STS_INDEX'
        STS_ZERO = 0
    class MAC_TYPE:
        TAG_ID = [11]
        LEN = 1
        TAG = 'MAC_TYPE'
        CRC_16 = 0
        CRC_32 = 1
    class RNG_DATA_NTF:
        TAG_ID = [14]
        LEN = 1
        TAG = 'RNG_DATA_NTF'
        DISABLE = 0
        ENABLE = 1
        ENABLE_IN_PROXIMITY_RANGE = 2
        ENABLE_INSIDE_AOA_BOUNDS = 3
        ENABLE_INSIDE_AOA_BOUNDS_AND_PROXIMITY_RANGE = 4
        ENABLE_WHILE_ENTERING_LEAVING_PROXIMITY = 5
        ENABLE_WHILE_ENTERING_LEAVING_AOA = 6
        ENABLE_WHILE_ENTERING_LEAVING_AOA_BOUNDS_AND_PROXIMITY_RANGE = 7
    class NEAR_PROXIMITY_CONFIG:
        TAG_ID = [15]
        LEN = 2
        TAG = 'NEAR_PROXIMITY_CONFIG'
        DEFAULT = 0
    class RNG_DATA_NTF_PROXIMITY_FAR:
        TAG_ID = [16]
        LEN = 2
        TAG = 'RNG_DATA_NTF_PROXIMITY_FAR'
        DEFAULT_RANGING = 20000
    class DEVICE_ROLE:
        TAG_ID = [17]
        LEN = 1
        TAG = 'DEVICE_ROLE'
        RESPONDER = 0
        INITIATOR = 1
    class RFRAME_CONFIG:
        TAG_ID = [18]
        LEN = 1
        TAG = 'RFRAME_CONFIG'
        SP0 = 0
        SP1 = 1
        RFU = 2
        SP3 = 3
    class PREAMBLE_CODE_INDEX:
        TAG_ID = [20]
        LEN = 1
        TAG = 'PREAMBLE_CODE_INDEX'
        DEFAULT = 10
    class SFD_ID:
        TAG_ID = [21]
        LEN = 1
        TAG = 'SFD_ID'
        DEFAULT_BPRF = 0
        HPRF_1 = 1
        BPRF = 2
        HPRF_3 = 3
        HPRF_4 = 4
    class SLOTS_PER_RR:
        TAG_ID = [27]
        LEN = 1
        TAG = 'SLOTS_PER_RR'
        DEFAULT_SLOTS = 24
    class KEY_ROTATION:
        TAG_ID = [35]
        LEN = 1
        TAG = 'KEY_ROTATION'
        NO_ROTATION = 0
        STS_ROTATION = 1
        DUDSK_ROTATION = 2
        STS_DUDSK_ROTATION = 3
    class SESSION_PRIORITY:
        TAG_ID = [37]
        LEN = 1
        TAG = 'SESSION_PRIORITY'
    class MAX_RR_RETRY:
        TAG_ID = [42]
        LEN = 2
        TAG = 'MAX_RR_RETRY'
        DEFAULT_RETRY = 0
    class UWB_INITIATION_TIME:
        TAG_ID = [43]
        LEN = 8
        TAG = 'UWB_INITIATION_TIME'
        DEFAULT = 0
    class HOPPING_MODE:
        TAG_ID = [44]
        LEN = 1
        TAG = 'HOPPING_MODE'
        DISABLED = 0
        ENABLED = 1
        NXP_ADAPTIVE_HOPING_ENABLE = 160
    class MAX_NUMBER_OF_MEASUREMENTS:
        TAG_ID = [50]
        LEN = 2
        TAG = 'MAX_NUMBER_OF_MEASUREMENTS'
        UNLIMITED = 0
    class HOP_MODE_KEY:
        TAG_ID = [160]
        LEN = 4
        TAG = 'HOP_MODE_KEY'
    class CCC_CONFIG_QUIRKS:
        TAG_ID = [161]
        LEN = 1
        TAG = 'CCC_CONFIG_QUIRKS'
    class RESPONDER_SLOT_INDEX:
        TAG_ID = [162]
        LEN = 1
        TAG = 'RESPONDER_SLOT_INDEX'
    class RANGING_PROTOCOL_VER:
        TAG_ID = [163]
        LEN = 2
        TAG = 'RANGING_PROTOCOL_VER'
    class UWB_CONFIG_ID:
        TAG_ID = [164]
        LEN = 2
        TAG = 'UWB_CONFIG_ID'
    class PULSESHAPE_COMBO:
        TAG_ID = [165]
        LEN = 1
        TAG = 'PULSESHAPE_COMBO'
    class URSK_TTL:
        TAG_ID = [166]
        LEN = 2
        TAG = 'URSK_TTL'
    class RESPONDER_LISTEN_ONLY:
        TAG_ID = [167]
        LEN = 1
        TAG = 'RESPONDER_LISTEN_ONLY'
    class LAST_STS_INDEX_USED:
        TAG_ID = [168]
        LEN = 4
        TAG = 'LAST_STS_INDEX_USED'


class DEVICE_CFG:
    class DEVICE_STATUS:
        TAG_ID = [0]
        TAG = 'DEVICE_STATUS'
    class LOW_POWER_MODE:
        TAG_ID = [1]
        TAG = 'LOW_POWER_MODE'
        DISABLED = 0
        ENABLED = 1
    class ANTENNA_RX_IDX_DEFINE:
        TAG_ID = [228, 96]
        TAG = 'ANTENNA_RX_IDX_DEFINE'
        LEN = 'n'
    class ANTENNA_TX_IDX_DEFINE:
        TAG_ID = [228, 97]
        TAG = 'ANTENNA_TX_IDX_DEFINE'
        LEN = 'n'
    class ANTENNAS_RX_PAIR_DEFINE:
        TAG_ID = [228, 98]
        TAG = 'ANTENNAS_RX_PAIR_DEFINE'
        LEN = 'n'



class TEST_CFG:
    undefined = None


class PLATFORM:
    uninitialized = 0
    RHODES = 115


class BOARD_VARIANT:
    V1 = 1
    V2 = 2
    GN20_V1 = 3
    V4 = 4


class SESSION_TYPE:
    SESSION_CCC = 160


class CALIB_TYPE:
    VCO_PLL = 0
    RF_CLK_ACCURACY_CALIB = 1
    RX_ANT_DELAY_CALIB = 2
    PDOA_OFFSET_CALIB = 3
    TX_POWER_PER_ANTENNA = 4
    AOA_PHASEFLIP_ANTSPACING = 5
    MANUAL_TX_POW_CTRL = 96
    PA_PPA_CALIB_CTRL = 97
    AOA_ANTENNAS_PDOA_CALIB = 98
    AOA_ANTENNAS_MULTIPOINT_CALIB = 99
    TX_ANT_DELAY_CALIB = 100
    PDOA_MANUFACT_ZERO_OFFSET_CALIB = 101
    AOA_THRESHOLD_PDOA = 102
    TX_TEMPERATURE_COMP_PER_ANTENNA = 103
    SNR_CALIB_CONSTANT_PER_ANTENNA = 104
    RSSI_CALIB_CONSTANT_HIGH_PWR = 105
    RSSI_CALIB_CONSTANT_LOW_PWR = 106


class VENDOR_APP_CFG:
    class ANTENNAS_CONFIGURATION_TX:
        TAG_ID = [2]
        LEN = 'n'
        TAG = 'ANTENNAS_CONFIGURATION_TX'
    class ANTENNAS_CONFIGURATION_RX:
        TAG_ID = [3]
        LEN = 'n'
        TAG = 'ANTENNAS_CONFIGURATION_RX'
    class RAN_MULTIPLIER:
        TAG_ID = [32]
        LEN = 1
        TAG = 'RAN_MULTIPLIER'
    class CSA_MAC_MODE:
        TAG_ID = [130]
        LEN = 1
        TAG = 'CSA_MAC_MODE'




class Cmds:


    class DEVICE_RESET:
        __GID = 0
        __OID = 0
        RESET_CONFIG = c_uint8

    class DEVICE_STATUS_NTF:
        __GID = 0
        __OID = 1

    class GET_DEV_INFO:
        __GID = 0
        __OID = 2

    class GET_CAPS_INFO:
        __GID = 0
        __OID = 3

    class DEVICE_INIT:
        __GID = 14
        __OID = 0
        PLATFORM_ID = c_uint8
        VARIANT_ID = c_uint8

    class SET_CONFIG:
        __GID = 0
        __OID = 4
        PARAMETERS = c_uint8
        DEVICE_TLV = bytearray

    class GET_CONFIG:
        __GID = 0
        __OID = 5
        PARAMETERS = c_uint8
        DEVICE_PARAMS = bytearray

    class QUERY_UWBS_TIMESTAMP:
        __GID = 0
        __OID = 8

    class SESSION_INIT:
        __GID = 1
        __OID = 0
        SESSION_ID = c_uint32
        SESSION_TYPE = c_uint8

    class SESSION_DEINIT:
        __GID = 1
        __OID = 1
        SESSION_ID = c_uint32

    class SESSION_STATUS_NTF:
        __GID = 1
        __OID = 2

    class SET_APP_CONFIG:
        __GID = 1
        __OID = 3
        SESSION_ID = c_uint32
        NUM_CONFIGS = c_uint8
        APP_TLV = bytearray

    class GET_APP_CONFIG:
        __GID = 1
        __OID = 4
        SESSION_ID = c_uint32
        NUM_CONFIGS = c_uint8
        APP_PARAMS = bytearray

    class SESSION_GET_COUNT:
        __GID = 1
        __OID = 5

    class SESSION_GET_STATE:
        __GID = 1
        __OID = 6
        SESSION_ID = c_uint32

    class SESSION_START:
        __GID = 2
        __OID = 0
        SESSION_ID = c_uint32

    class SESSION_STOP:
        __GID = 2
        __OID = 1
        SESSION_ID = c_uint32

    class RANGE_GET_RANGING_COUNT:
        __GID = 2
        __OID = 3
        SESSION_ID = c_uint32

    class SESSION_ROLE_CHANGE_NTF:
        __GID = 2
        __OID = 6

    class RANGE_CCC_DATA:
        __GID = 2
        __OID = 32

    class GENERIC_ERROR_NTF:
        __GID = 0
        __OID = 7

    class SET_VENDOR_APP_CONFIG:
        __GID = 15
        __OID = 0
        SESSION_ID = c_uint32
        NUM_CONFIGS = c_uint8
        VENDOR_TLV = bytearray

    class GET_VENDOR_APP_CONFIG:
        __GID = 15
        __OID = 3
        SESSION_ID = c_uint32
        NUM_CONFIGS = c_uint8
        VENDOR_PARAMS = bytearray

    class SET_DEVICE_CALIBRATION:
        __GID = 15
        __OID = 33
        CHANNEL_ID = c_uint8
        TAG = c_uint8
        LENGTH = c_uint8
        CALIBRATION_VALUE = bytearray
