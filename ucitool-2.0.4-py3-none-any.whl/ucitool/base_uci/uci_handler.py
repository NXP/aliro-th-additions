#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#
import logging as log
import queue
import sys
import threading
import time
from collections import deque

UCI_MT_MASK = 0xE0
UCI_MT_SHIFT = 0x5
UCI_GID_MASK = 0x0F
UCI_OID_MASK = 0x3F

MT_RSP = 2
MT_NTF = 3

isRsp = lambda x: ((x[0]) & UCI_MT_MASK) >> UCI_MT_SHIFT == MT_RSP
isNtf = lambda x: ((x[0]) & UCI_MT_MASK) >> UCI_MT_SHIFT == MT_NTF
gid = lambda x: x[0] & UCI_GID_MASK
oid = lambda x: x[1] & UCI_OID_MASK

# just compare bytes, may be faster no need compare gid, oid, status etc
isCmdRetryNtf = lambda x: x == b'`\x07\x00\x01\n'  # [0x60, 0x07, 0x00, 0x01, 0x0a]
isFwCrashNtf = lambda x: x == b'`\x01\x00\x01\xff'  # [0x60, 0x01, 0x00, 0x01,  0xFF]
isCirNtf = lambda x: gid(x) == 0xE and oid(x) in (0x4, 0x5)  # cir oid-4,5


class UciHandler(threading.Thread):
    def __init__(self, name, uci_obj=None):
        self._stop_event = threading.Event()
        self._start_event = threading.Event()
        self._mutex = threading.Lock()
        self._sleep = 0.001
        self._dev_name = name
        self._uci = uci_obj
        self._device = None
        self._fsci_ntf_queue = queue.Queue()
        self._uci_ntf_queue = queue.Queue()
        self._uci_rsp_queue = queue.Queue()
        # mirror of all NTFs to be consumed by external streams, use deque to get popleft efficiently and make circular
        self._uci_mirror_q = deque(maxlen=100)  # maxsize 100, to avoid memory err if this q is not consumed
        self.disable_ntf_print = False
        self.disable_uci_print = False
        self.cir_logging = False
        self.ntf_cnt = 0
        self.prev_rng_data = None
        self.cir_data = {'cir0_idx': 0, 'cir1_idx': 0}
        self.skip_parse = False
        self.output_file = None
        self.uci_ver = None
        super(UciHandler, self).__init__()
        self.daemon = True

    def set_device(self, device):
        self._device = device

    def start_uci_handler(self):
        self._start_event.set()

    def get_crash_log(self):
        """ issue get error log"""
        log.error("FW crash: Issue DBG_GET_ERROR_LOG Command")
        uci = self._uci(uci='DBG_GET_ERROR_LOG')
        self.uci_cmd_rsp(uci.uci_raw_data)

    def run(self):
        read_pkt_cnt = 5  # when we get achance to read, read as much as possible
        cur_pkt_idx = 0
        try:
            self._start_event.wait()
            while not self._stop_event.isSet():
                while (cur_pkt_idx < read_pkt_cnt) and not self._stop_event.isSet():
                    try:
                        uci_data_list = self._device.uci_read(poll=True, timeout=15)
                    except Exception as e:
                        log.error('error in reading the data from the device, (disconnected/reset?) {}'.format(e))
                        self._stop_event.set()
                    else:
                        if self._stop_event.isSet():
                            log.debug("stop event is set, should stop uci_handler read thread")
                        if uci_data_list:
                            for uci_data in uci_data_list:
                                try:
                                    if isRsp(uci_data) or isCmdRetryNtf(uci_data):  # cmd retry ntf to rsp q so that
                                        self._uci_rsp_queue.put(uci_data)  # can be retried on recv of rsp as CMD_RETRY
                                    else:
                                        if isFwCrashNtf(uci_data):  # oops fw crash, lets get debug log from fw
                                            self.get_crash_log()
                                        # if disable_ntf_prints or skip_parse enabled, no need parse, this will speedup
                                        # uci read bg thread
                                        if not self.skip_parse:
                                            uci_data = self.parse(uci_data)
                                        # enque uci. it may be parsed or raw bytes, uci may be fetched from uci_read_ntf
                                        # in foreground thread.
                                        self._uci_ntf_queue.put(uci_data)
                                        # elif isCirNtf(uci_data): #todo this is disabled considering file write latency
                                        #     if self.cir_logging:
                                        #         self.save_cirs(uci_data)  # this takes approx 3-5 millisecs
                                except Exception in (KeyError, TypeError) as e:
                                    log.error('Error in parsing UCI {}: {}'.format(uci_data, e))
                                self._uci_mirror_q.append(uci_data)  # mirror q for post processor if available
                    cur_pkt_idx += 1
                cur_pkt_idx = 0
        except KeyboardInterrupt:
            self.join()

    def join(self, timeout=None):
        if self.is_alive() and self._start_event.isSet():
            self._stop_event.set()
            log.debug("stop for uci handler is set")
            threading.Thread.join(self, timeout)

    def device_state(self):
        pass

    # @calculate_time # uncomment this line to measure uci cmd-rsp latency
    def uci_cmd_rsp(self, uci_cmd, timeout=2):  # 2 sec cmd timeout
        uci_data = None
        self.uci_read_rsp_clear()
        t1 = time.time()
        self._device.write(uci_cmd)  # write cmd
        while time.time() - t1 < timeout:
            uci_data = self.uci_read_rsp(timeoutInSec=0.2)  # 200ms to read frm q
            if uci_data:
                if isCmdRetryNtf(uci_data.uci_raw_data) and not self._device.uci_ready_mode:
                    time.sleep(0.01)  # 10ms device ready wait after DPD
                    self._device.write(uci_cmd)
                else:
                    return uci_data
            elif time.time() - t1 < 200 and not self._device.uci_ready_mode:  # fw missed cmd in case of timer based wakeup, so no STATUS_CMD_RETRY ntf
                self._device.write(uci_cmd)

        self.device_state()  # no rsp, process dev state ?
        return uci_data

    def parse(self, uci_data):
        """ if uci_data not bytes object, its already parsed from handler bg thread, skip parsing and return as is"""
        if uci_data and isinstance(uci_data, bytes):
            return self._uci(uci_bytedata=uci_data,
                             disable_ntf_print=self.disable_ntf_print,
                             device=self._device.devcfg,
                             disable_uci_prints=self.disable_uci_print,
                             uci_ver=self.uci_ver,
                             of=self.output_file)
        return uci_data

    def uci_read_rsp(self, timeoutInSec=0.3):
        rsp = None
        try:
            rsp = self._uci_rsp_queue.get(block=True, timeout=timeoutInSec)
            return self.parse(rsp)
        except queue.Empty:
            return None
        except Exception in (KeyError, TypeError) as e:
            log.error('Error in parsing UCI {}: {}'.format(rsp, e))
        return None

    def uci_read_raw_ntf(self, timeout=1):
        try:
            return self._uci_mirror_q.popleft()
        except IndexError:
            return None

    def uci_read_ntf(self, timeoutInSec=1):
        ntf = None
        try:
            ntf = self._uci_ntf_queue.get(block=True, timeout=timeoutInSec)
            return self.parse(ntf)
        except (KeyError, TypeError) as e:
            log.error('Error in parsing UCI {}: {}'.format(ntf, e))
        except queue.Empty:
            return None
        return None

    def uci_read_ntf_clear(self):
        with self._uci_ntf_queue.mutex:
            self._uci_ntf_queue.queue.clear()

    def uci_read_rsp_clear(self):
        with self._uci_rsp_queue.mutex:
            self._uci_rsp_queue.queue.clear()

    def fw_download(self, filename, print_log=False, skip_power_up=False):
        if not self._device:
            sys.exit()
        retry_count = 3
        with self._mutex:
            for i in range(retry_count):
                if not skip_power_up:
                    self._device.powerup()
                time.sleep(0.05)
                fw_download_status = self._device.hbci.fw_download(filename, print_log)
                if fw_download_status:
                    log.info("firmware has been downloaded successfully")
                    break
                else:
                    log.error("retrying firmware download, retry count %d", i)

    def save_cirs(self, ucidata):
        cir = ucidata.uci_str.split('_')[1].lower()

        seq = 'seq'
        try:
            if self.prev_rng_data:
                seq = self.prev_rng_data.fields['SEQUENCE_NUM'].val
            cirf = '{}_{}_seq_{}.txt'.format(cir, self.cir_data['{}_idx'.format(cir)], seq)
            with open(cirf, 'w+') as fd:
                data = ucidata.fields['{}_DATA'.format(cir.upper())].val.hex()
                for i in range(0, len(data), 8):
                    fd.write(data[i:i + 8])
            self.cir_data['{}_idx'.format(cir)] += 1
        except:
            pass

    def send_uci(self, uci):
        self.uci_read_rsp_clear()
        self._device.write(uci, uci_pkt=True)  # todo: implement below properly when dpd for data
        # uci_data = self.uci_read_rsp(timeoutInSec=0.2)  # 200ms to read frm q
        # if uci_data.uci_str == Cmds.GENERIC_ERROR_NTF.__name__ and uci_data.fields[
        #     'UCI_STATUS'].name == 'STATUS_CMD_RETRY':
        #     self._device.write(uci, uci_pkt=True)

    def fsci_put_packet(self, packet):
        self._fsci_ntf_queue.put(packet)

    def fsci_get_packet(self):
        fsci_packet = None
        try:
            fsci_packet = self._fsci_ntf_queue.get(block=True, timeout=2)
            return fsci_packet
        except queue.Empty:
            return None
        return None

