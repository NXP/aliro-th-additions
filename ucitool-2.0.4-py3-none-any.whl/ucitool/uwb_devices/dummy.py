#   Copyright (c), 2020 NXP Semiconductors
#   #
#   All rights are reserved. Reproduction in whole or in part is
#   prohibited without the written consent of the copyright owner.
#   #
#   NXP reserves the right to make changes without notice at any time.
#   #
#   NXP makes no warranty, expressed, implied or statutory, including but
#   not limited to any implied warranty of merchantability or fitness for any
#   particular purpose, or that the use will not infringe any third party patent,
#   copyright or trademark. NXP must not be liable for any loss or damage
#   arising from its use.

import logging
import sys

from ucitool.uwb_devices.uwbdevice import UwbDevice

log = logging.getLogger(__name__)


class Dummy(UwbDevice):
    def __init__(self):
        super().__init__()
        self.__name = None
        self.id = None
        self.uci_handler = None
        self.connected = True

    def initialize(self, dev_config):
        self.devcfg = dev_config
        log.info(sys._getframe().f_code.co_name)
        self.dev_type = dev_config.dev_type
        self.id = dev_config.id
        self.interface_type = dev_config.interface_config.type
        self.uci_supported = dev_config.uci_support
        self.variant = dev_config.variant

    def open(self):
        log.info(sys._getframe().f_code.co_name)
        return True

    def uci_read(self, poll=True, timeout=5):
        return bytearray()

    def read(self, rlen=1, timeout=5):
        return bytearray()

    def write(self, data, uci_pkt=True, hbci_pkt=False, hbci_qry_pkt=False):
        pass

    def close(self):
        log.info(sys._getframe().f_code.co_name)
        return True

    def uci_read_rsp(self):
        return self.uci_handler.uci_read_rsp()

    def uci_cmd_rsp(self, uci_cmd, timeout=5):
        pass

    def set_uci_handler(self, uci_hnd):
        self.uci_handler = uci_hnd


