#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#
import socket


class Ser2Net(object):
    """
    Class which wraps a tcp socket connected to ser2net running on e.g. raspberry pi to same interface as pyserial
    On Raspberry Pi (or any Linux machine), ser2net daemon must be running. See for instance this instruction:
    https://confluence.sw.nxp.com/display/USS/Raspberry+Pi
    """

    s = None

    def __init__(self, host, port, timeout=0.1):
        super().__init__()
        self.host = host
        self.port = port
        self.timeout = timeout

    def __del__(self):
        if self.s is not None:
            self.s.close()

    def initialize(self, dev_config):
        pass

    def write(self, data):
        self.s.sendall(bytes(data))

    @property
    def in_waiting(self):
        # there is no way in python for windows to use ioctl to read number of bytes in socket buffer. 
        # So do a read with msg_peek which keeps the data in socket
        self.s.settimeout(0)

        try:
            dummy = self.s.recv(1024 * 16, socket.MSG_PEEK)  # 16k to accommodate min 4 cirs
        except:
            # note: if no data is in socket, we get an exception, so map it to 0 bytes length
            return 0
        finally:
            self.s.settimeout(self.timeout)
        return len(dummy)

    def read(self, rlen=1, timeout=5):
        try:
            return self.s.recv(rlen)
        except:
            # note: if no data is in socket, we get an exception, so map it to 0 bytes length
            return

    def reset_input_buffer(self):
        flush_done = False
        while flush_done:
            num_of_bytes = Ser2Net.s.in_waiting
            if num_of_bytes == 0:
                flush_done = True
            else:
                self.s.recv(num_of_bytes)

    def reset_output_buffer(self):
        pass

    def isOpen(self):
        if self.s is not None:
            return self.s.fileno() >= 0
        else:
            return False

    def open(self):
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.s.connect((self.host, self.port))
        self.s.settimeout(self.timeout)

    def close(self):
        self.s.close()
