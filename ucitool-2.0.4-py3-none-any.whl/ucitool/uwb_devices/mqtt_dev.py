#
# Copyright (c), 2022 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import time
import json
import queue
import binascii
import paho.mqtt.client as mqtt

from paho.mqtt.client import Properties
from paho.mqtt.packettypes import PacketTypes

from ucitool.uwb_devices.uwbdevice import UwbDevice



class MqttDevice(UwbDevice):

    def __init__(self):
        super().__init__()
        self.__name = None
        #self.id = None
        self.uci_handler = None
        self.mqtt_q = queue.Queue()
        self.device_id = '+'
        self.seq_count = 0
        self.mqtt_client = None


    def is_connected(self):
        if self.mqtt_client:
            return self.mqtt_client.connected_flag
        return False


    def on_connect(self, client, userdata, flags, rc, properties=None):
        if rc == 0:
            client.connected_flag = True
            print("MQTT client connected to Broker.")
        else:
            client.bad_connection_flag = True


    def on_disconnect(self, client, userdata, rc, properties):
        client.connected_flag = False
        print("MQTT client disconnected from Broker.")


    def on_publish(self, client, userdata, result):
        pass


    def on_message(self, client, userdata, message):
        data = message.payload.decode("utf-8")
        print(f"*** MQTT RECV: Topic {message.topic}  Message: {data}")
        data_dict = json.loads(data)
        uci_bytes = bytearray.fromhex(data_dict['UCI_BYTES'])
        self.mqtt_q.put(uci_bytes)
        if message.topic == self.raw_rsp_topic and \
           self.seq_count == int.from_bytes(message.properties.CorrelationData, 'big'):
           self.seq_count += 1


    def initialize(self, dev_config):
        print(f"MQTT Initialize: {dev_config}")
        self.interface_type = dev_config.interface_config.type
        self.variant = dev_config.variant
        self.uci_supported = dev_config.uci_support
        self.dev_type = dev_config.dev_type
        self.devcfg = dev_config
        self.mqtt_dev_id = dev_config.id
        self.ip = dev_config.interface_config.ip_addr
        self.port = dev_config.interface_config.port

        # Set MQTT topics based on Device ID
        self.raw_topic = f'devices/{self.mqtt_dev_id}/raw'
        self.raw_rsp_topic = f'devices/{self.mqtt_dev_id}/raw_rsp'


    def open(self):
        # Create MQTT client and set its connection flags
        self.mqtt_client = mqtt.Client("MQTT Device Client",
                                       protocol=mqtt.MQTTv5)
        self.mqtt_client.connected_flag = False
        self.mqtt_client.bad_connection_flag = False
        # Set MQTT client callbacks
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_disconnect = self.on_disconnect
        self.mqtt_client.on_publish = self.on_publish
        self.mqtt_client.on_message = self.on_message
        # Connect to the MQTT Broker/server
        print(f"MQTT: connecting to broker on {self.ip}:{self.port}")
        try:
            timeout_ts = time.time() + 5
            self.mqtt_client.connect(self.ip, port=self.port)
            self.mqtt_client.loop_start()
            while not self.mqtt_client.connected_flag and \
                  not self.mqtt_client.bad_connection_flag and \
                  time.time() < timeout_ts:
                time.sleep(0.2)

            if not self.mqtt_client.connected_flag:
                self.mqtt_client.loop_stop()
                print("MQTT Device could not connect to the broker on time.")
                sys.exit(1)
            if self.mqtt_client.bad_connection_flag:
                self.mqtt_client.loop_stop()
                print("MQTT Device could not connect to the broker due to a bad connection.")
                sys.exit(1)

        except:
            # Something went wrong when connecting to the MQTT Broker
            print("Exception: MQTT Device could not connect to the broker.")
            sys.exit(1)

        # Subscribe to the topic to get UCI responses
        self.mqtt_client.subscribe(self.raw_rsp_topic)
        # Set and start UCI Handler
        self.uci_handler.set_device(self)
        self.uci_handler.start()
        return self.is_connected()


    def close(self):
        self.mqtt_client.loop_stop()
        if self.is_connected():
            self.mqtt_client.disconnect() # disconnect gracefully


    def poll_read(self, rlen=None, timeout=5):
        return self.read(timeout=timeout)


    def read(self, rlen=1, timeout=1):
        end_ts = time.time() + timeout
        while time.time() < end_ts:
            if not self.mqtt_q.empty():
                return self.mqtt_q.get()
            time.sleep(0.1)
        return


    def write(self, data):
        properties = Properties(PacketTypes.PUBLISH)
        properties.ResponseTopic = self.raw_rsp_topic
        properties.CorrelationData = bytes([self.seq_count])

        hexstr = binascii.hexlify(data).decode('ascii')
        d = {'timestamp': time.time(), 'UCI_BYTES': hexstr}
        print(f"MQTT WRITE: {d}")
        self.mqtt_client.publish(self.raw_topic, json.dumps(d),
                                 properties=properties)


    @property
    def in_waiting(self):
        """To be implemented by each device(if required)"""
        return 0

