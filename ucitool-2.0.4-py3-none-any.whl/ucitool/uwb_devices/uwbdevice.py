#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#
import collections
import logging as log
import threading

UCI_PBF_MASK = 0x10  # UCI Packet Boundry Flag Mask
UCI_EXT_PAYLOAD_LEN_MASK = 0x80  # 7th bit of 2 octet in hdr
UCI_EXT_PAYLOAD_LEN_POS = 7


class UwbDevice(object):
    def __init__(self):
        self.__name = None
        self.id = None
        self.uci_supported = None
        self.devcfg = None
        self.uci_handler = None
        self.uci_ready_mode = False
        self.pend_pkt_dict = {}
        self.partial_pkt_buf = bytes()
        self._mutex = threading.Lock()
        self.ser_props = None

    def initialize(self, dev_config):
        self.interface_type = dev_config.interface_config.type
        self.variant = dev_config.variant
        self.uci_supported = dev_config.uci_support
        self.dev_type = dev_config.dev_type
        self.devcfg = dev_config
        self.id = dev_config.id
        self.ip = dev_config.interface_config.ip_addr
        self.com_port = dev_config.interface_config.com_port
        self.port = dev_config.interface_config.port
        self.ser_props = dev_config.interface_config.ser_props
        if self.ser_props is None:
            self.ser_props = {}
        if 'baudrate' not in self.ser_props:
            self.ser_props['baudrate'] = 115200

    def open(self):
        """To be implemented by each device"""
        pass

    def close(self):
        """To be implemented by each device"""
        pass

    def read(self, rlen=1, timeout=0):
        """To be implemented by each device"""
        pass

    def write(self, data):
        """To be implemented by each device"""
        pass

    @property
    def in_waiting(self):
        """To be implemented by each device(if required)"""
        return 0

    def send_uci(self, uci_cmd):
        return self.uci_handler.send_uci(uci_cmd)

    def uci_read_raw_ntf(self, timeout):
        return self.uci_handler.uci_read_raw_ntf(timeoutInSec=timeout)

    def set_uci_handler(self, uci_hnd):
        self.uci_handler = uci_hnd

    # @calculate_time  # uncomment to measure uci cmd-rsp latency. benchmark results: 10-20ms on rhodes
    def uci_cmd_rsp(self, uci_cmd, timeout=2):
        return self.uci_handler.uci_cmd_rsp(uci_cmd, timeout)

    def set_uci_ready_mode(self, enable=True):
        self.uci_ready_mode = enable

    def uci_read_rsp_clear(self):
        return self.uci_handler.uci_read_rsp_clear()

    def uci_read_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_log_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_read_ntf(self, timeout=1):
        return self.uci_handler.uci_read_ntf(timeoutInSec=timeout)

    def uci_log_ntf(self):
        return self.uci_handler.uci_log_ntf()

    def uci_read_rsp(self):
        return self.uci_handler.uci_read_rsp()

    def fsci_read_packet(self):
        return self.uci_handler.fsci_get_packet()

    # get the key
    def get_pend_pkt_dict_key(self, hdr):
        # gid << 8  | oid
        dict_key = ((hdr[0] & 0x0F) << 8) | (hdr[1] & 0x3F)
        return dict_key

    def uci_read(self, poll=True, timeout=5):
        return self.defragment_uci(self.poll_read())  # read all available and split into list of UCIs)

    def defragment_uci(self, payload):
        uci_lst = []
        if not payload: return uci_lst
        idx = 0  # index pointer
        payload = self.partial_pkt_buf + payload  # take previously received partial pkt now
        self.partial_pkt_buf = bytes()  # all partial taken no more partial then
        hdr_only = payload and len(payload) == 4

        while payload and idx < len(payload):
            hdr = payload[idx:idx + 4]  # get header
            if len(hdr) != 4:  # partial header! cant move forward, buffer partial hdr and consider in next round
                self.partial_pkt_buf += hdr
                return uci_lst
            idx += 4  # incr pointer after header
            if hdr[0] == 0x00 and hdr[1] == 0x00 and hdr[2] == 0x00 and hdr[3] == 0x00:
                log.error('Zero Header packet')
                return []
            length = hdr[3]
            if (hdr[1] & UCI_EXT_PAYLOAD_LEN_MASK) >> UCI_EXT_PAYLOAD_LEN_POS:
                length = hdr[3] << 8 | hdr[2]

            # check, if we have received a pbf=1 packet for this type earlier, if not, create an empty payload array
            dict_key = self.get_pend_pkt_dict_key(hdr)
            uci_payload = self.pend_pkt_dict.pop(dict_key, bytearray())
            if hdr_only:
                chunk = self.read(length, timeout=5)  # in case we get hdr only read read again length
            else:
                chunk = payload[idx:idx + length]
                idx += length  # incr pointer after payload
            if len(chunk) != length:
                self.partial_pkt_buf = hdr + chunk  # hdr ok, but payload not ok, buffer it and consider in next iter
                uci_payload and self.pend_pkt_dict.update({dict_key: uci_payload})
                return uci_lst
            uci_payload.extend(chunk)
            if not hdr[0] & UCI_PBF_MASK:
                if len(uci_payload) > 0xFF:  # re-adjust len and ext len bit in header for agg(pbf1 + pbf0) uci pkt
                    hdr = hdr[:1] + bytes([hdr[1] | (1 << 7)]) + len(uci_payload).to_bytes(2, 'little')
                uci_lst.append(hdr + uci_payload)  # ok we got end of uci
            else:
                # we wil not return this now, store the packet in the dict & ,merge later when we get next pbf=0 pkt
                self.pend_pkt_dict[dict_key] = uci_payload
        return uci_lst  # this may contain multiple UCIs

    def poll_read(self, rlen=None, timeout=5):
        # len param to this method is ignored, from typical flow of read hdr-> check length-> read length
        # we change to, read whatever there in serial buffer, to make host acknowledge UWBS ASAP that we have read
        # whatever UWBS sent, so that UWBS NTF q wil get freed early.
        # after read full buffer which may have multiple UCIs, de-fragment it into list of UCIs and wait for next read.
        with self._mutex:
            if self.in_waiting >= 4:  # min header len
                return self.read(self.in_waiting)
