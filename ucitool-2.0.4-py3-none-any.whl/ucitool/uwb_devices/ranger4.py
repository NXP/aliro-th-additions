#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import logging
import sys
import threading
import time

import serial

from ucitool.uwb_devices.uwbdevice import UwbDevice

log = logging.getLogger(__name__)


class Ranger4(UwbDevice):
    def __init__(self):
        self.__name = None
        self.id = None

    def initilize(self, dev_config):
        log.info(sys._getframe().f_code.co_name)
        self.dev_type = dev_config.dev_type
        self.id = dev_config.id
        self._mutex = threading.Lock()
        self.interface_type = dev_config.interface_config.type
        self.com_port = dev_config.interface_config.com_port
        self.clock_rate = 115200

        self.ser = serial.Serial()
        log.debug('PORT :' + self.com_port)
        self.ser.port = self.com_port
        self.ser.baudrate = self.clock_rate
        self.ser.timeout = None
        self.variant = dev_config.variant

    def open(self):
        log.info(sys._getframe().f_code.co_name)
        if self.ser.isOpen():
            return
        self.ser.open()

    def flush_port(self):
        log.info(sys._getframe().f_code.co_name)
        log.info("Flushing port..")
        time.sleep(1)
        self.ser.flushOutput()
        self.ser.flushInput()

    def close(self):
        log.info(sys._getframe().f_code.co_name)
        if self.ser.isOpen():
            self.ser.close()

    def read(self, rlen=1, timeout=5):
        self._mutex.acquire()
        payload = None
        try:
            payload = self.ser.read(rlen)
            # logstr = '[' + self.id + '] RX:' + ':'.join('%02x' % i for i in (payload))
            # log.info(logstr)
        finally:
            self._mutex.release()
        return payload

    def poll_read(self, rlen=1, timeout=5):
        self._mutex.acquire()
        payload = None
        try:
            d_in = self.ser.inWaiting()
            if (d_in > 0):
                payload = self.ser.read(rlen)
                # logstr = '[' + self.id + '] RX:' + ':'.join('%02x' % i for i in (payload))
                # log.info(logstr)
        finally:
            self._mutex.release()
        return payload

    def write(self, data):
        self._mutex.acquire()
        try:
            logstr = '[' + self.id + '] TX:' + ':'.join('%02x' % i for i in (data))
            log.info(logstr)
            self.ser.write(data)
        except:
            log.error('Write Failed')
        finally:
            self._mutex.release()
