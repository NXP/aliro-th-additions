#
# Copyright (c), 2020-2023 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import argparse
import logging
import re
import threading
import time

import serial

from ucitool.UciGenerator import set_uci_ver, get_uci_helpers, get_installed_ver
from ucitool.base_uci.uci import Uci, UciHost, uci2dict

uci_devices = []
my_args = None
runtime_vars = {}
logger = logging.getLogger()
pat_dict = dict(utf=r'\].*\[(.*)\].*[TX|RX]:(.*)\(uci.py',  # uwb test framework
                logcat=r'(Uci[X|R]).*len.*>(.*)',  # android logcat
                rhodes=r'(SEND|RECV).*:(.*)',  # Rhodes
                iot=r'TMLUWB.*3s[TX|RX].*:.*(\d*).*:(.*)',  # R UART, IOT testbench etc
                lp=r'(DUT_TX|DUT_RX).*:(.*)',  # litepoint iqfact+
                myself=r'(^RAW:)(.*)')  # ucitool


def handle_partial_pkt(match_obj, pend_pkt_dict):
    res = None
    try:
        if match_obj:
            msg = match_obj.group(2).strip()
            uci_hex_str = re.sub(r'[:\s]', '', msg)
            mt_to_oid = int(uci_hex_str[:4], 16)
            partial_pkt_key = mt_to_oid & 0xEF_3F  # mt_gid_oid mask
            msg = msg[:8] + pend_pkt_dict.pop(partial_pkt_key, '') + msg[8:]
            if mt_to_oid & 0x10_00:  # pbf enabled
                pend_pkt_dict[partial_pkt_key] = msg[8:]  # remove header
            else:
                res = msg
    except:  # noqa
        pass
    return res


def run_uci(ucis, u_devices, parallel=False, parallel_on_diff=False):
    hud_threads = {}
    gbls = globals()
    if parallel_on_diff:
        if len(ucis) > 1 and ucis[0] in gbls:
            uci_fn = gbls[ucis[0]]
            hud_threads[u_devices[0]] = threading.Thread(target=exec_uci, args=(uci_fn, u_devices[0],))
            if ucis[1] in gbls:
                uci_fn = gbls[ucis[1]]
                hud_threads[u_devices[1]] = threading.Thread(target=exec_uci, args=(uci_fn, u_devices[0],))
    else:
        for uci in ucis:
            if uci and uci in gbls:
                uci_fn = gbls[uci]
                if parallel:
                    for dev in u_devices:  # add threads
                        hud_threads[dev] = threading.Thread(target=exec_uci, args=(uci_fn, dev,))
                elif uci_devices:
                    for dev in u_devices:
                        exec_uci(uci_fn, dev)  # exec in first device if no parallel and more than one com is specified
                else:
                    uci_fn(None)
            elif uci:
                logger.warning("Unknown UCI {}".format(uci))
    for t in hud_threads:  # start threads
        hud_threads[t].start()
    for t in hud_threads:  # wait for threads to complete
        hud_threads[t].join()
    for dev in u_devices:
        dev.device.close()


def exec_uci(uci, device):
    gbls = globals()
    gbls['device_creation'](device, skip_fw_download=not my_args.firmware, fw=my_args.firmware)
    return uci(device)


def get_uci_devices():
    global uci_devices, runtime_vars
    if my_args.connection:
        for com in my_args.connection:
            port = com if 'com' in com else my_args.port
            ip = com if 'com' not in com else None
            uci_devices.append(UciHost(port=port, ip=ip, id='dev'))
            runtime_vars[com] = {}
            runtime_vars[com]["com"] = com
    elif my_args.mode == 'parse' and my_args.parse_live:
        uci_devices.append(UciHost(adb_ser=my_args.parse_live))
    else:
        uci_devices.append(UciHost(id='dummy'))
    return uci_devices


def calculate_time(func):
    """Decorate any func with this to know func's exact runtime"""

    def run(*args, **kwargs):
        t1 = time.time()
        ret = func(*args, **kwargs)
        logger.info('Time taken to execute {} is {} secs'.format(func.__name__, time.time() - t1))
        return ret

    return run


# @calculate_time
def parse_uci(uci_str, out_file=None, suppress_prints=False):
    u = Uci(uci_hex_str=uci_str, of=out_file, disable_uci_prints=suppress_prints)
    if u.uci_str: return u


def cleanup():
    for dev in uci_devices:
        dev.device.close()


def grep_uci_patter(line):
    for p in pat_dict.values():  # detect which patter to apply: type of log file
        if re.search(p, line):
            return p


@calculate_time
def parse_file(file, of=None, log_type=None, suppress_prints=False, uci_ver=None, get_res_dict=False):
    res = []
    u_dict = []
    if uci_ver: set_uci_ver(uci_ver)
    pat, pend_pkt_dict, ptrn_succ = pat_dict.get(log_type), {}, False
    fd = file
    if isinstance(file, str):
        fd = open(file, 'r', errors='ignore')
    for line in fd:
        if isinstance(line, bytes): line = line.decode()
        pat = pat or grep_uci_patter(line)
        m = pat and re.search(pat, line)  # apply search only if pattern had found
        m = handle_partial_pkt(m, pend_pkt_dict)
        u = m and parse_uci(m, out_file=of, suppress_prints=True)
        uci_dict = {}
        u and (res.append(u) or get_res_dict and u_dict.append(uci2dict(u, uci_dict)))
        ptrn_succ = ptrn_succ or (not ptrn_succ and u)
        if not ptrn_succ: pat = None
    if isinstance(file, str):
        fd.close()
    return res, u_dict


# def sniff_live():
#     # Check the queues if we received some output (until there is nothing more to get).
#     try:
#         self.start_logcat()
#         while self.sniff_on and not self.hud.logcat_r.eof():
#             while self.sniff_on and not self.hud.logcat_q.empty():
#                 try:
#                     match = re.search('NxpUci.*len.*=.*>(.*)', self.hud.get_logcat_lines()[0].decode())
#                     if match:
#                         self.parse_uci_hex_str(match.group(1).strip())
#                 except UnicodeDecodeError:
#                     pass
#     except KeyboardInterrupt:
#         self.sniff_on = False
#         self.hud.logcat_p.kill()
#         raise
#     finally:
#         self.hud.logcat_p.kill()


def serve_args():
    if my_args.ver:
        set_uci_ver(my_args.ver)
    if my_args.loglevel:
        logging.basicConfig(level=int(my_args.loglevel) * 10, handlers=[logging.StreamHandler()])
    globals().update(get_uci_helpers())  # sourcing helpers for commandline
    if my_args.mode == 'parse':
        if my_args.hex_str:
            parse_uci(my_args.hex_str, my_args.outfile)
        elif my_args.logfile:
            parse_file(my_args.logfile, my_args.outfile, my_args.log_type)
        elif my_args.parse_live:
            if get_uci_devices():
                uci_devices[0].start_siff()
    else:
        if my_args.uci and get_uci_devices():
            run_uci(my_args.uci, uci_devices, parallel=my_args.parallel, parallel_on_diff=bool(my_args.pdifferent))
        else:
            logger.info('uciTool ver: {}'.format(get_installed_ver()))


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description="Uwb Command Interface")
        subparser = parser.add_subparsers(dest='mode')
        parser.add_argument('-c', '--connection', nargs='+', required=False, help="com/ip address")
        parser.add_argument('-d', '--debug', required=False, help="print uci hext str, No execution")
        parser.add_argument('-port', '--port', nargs='+', required=False, help="port for connection")
        parser.add_argument('-u', '--uci', nargs='+', required=False, help="uci name")
        parser.add_argument('-v', '--ver', required=False, help="uci version")
        parser.add_argument('-fw', '--firmware', required=False, help="FW image to download")  # todo need to add
        parser.add_argument('-of', '--outfile', required=False, help="log uci outputs to this file")
        parser.add_argument('-a', '--args', nargs='+', required=False, help="Extra argumens needed for uci functions")
        parser.add_argument('-p', '--parallel', required=False, help="Run UCIs in parallel")
        parser.add_argument('-l', '--loglevel', required=False, help="log level")
        parser.add_argument('-pd', '--pdifferent', required=False,
                            help="Run UCIs in parallel, but on different devices")

        sniff_args = subparser.add_parser('parse')
        sniff_args.add_argument('-v', '--ver', required=False, help="uci version")
        sniff_args.add_argument('-if', '--logfile', required=False, help="input file location")
        sniff_args.add_argument('-of', '--outfile', required=False, help="parsed sniff filename")
        sniff_args.add_argument('-s', '--hex_str', required=False, help="hex string to pass")
        sniff_args.add_argument('-t', '--log_type', default='utf', required=False,
                                help="type of logfile: mig,utf,logcat etc")
        sniff_args.add_argument('-l', '--parse_live', default=1, required=False, help="Parse live from android device")

        my_args = parser.parse_args()
        serve_args()
    except KeyboardInterrupt:
        logger.info('Good Bye!')
    except serial.serialutil.SerialException as e:
        logger.error('Wrong COM port, {} '.format(e))
    except Exception as exc:
        logger.error("An error happened, Here is what I know: {}".format(exc))

    finally:
        cleanup()
