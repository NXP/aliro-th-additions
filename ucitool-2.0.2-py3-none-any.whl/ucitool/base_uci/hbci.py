#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#
import logging
import logging as log
import struct
import time
from enum import IntFlag


log = logging.getLogger()
log.setLevel(logging.INFO)
PHHBCI_LEN_HDR = 4
PHHBCI_LEN_LRC = 1
PHHBCI_MAX_LEN_DATA_MOSI = 2048
PHHBCI_MAX_LEN_PAYLOAD_MOSI = PHHBCI_MAX_LEN_DATA_MOSI + PHHBCI_LEN_LRC
PHHBCI_MAX_LEN_DATA_MISO = 256
PHHBCI_MAX_LEN_PAYLOAD_MISO = PHHBCI_MAX_LEN_DATA_MISO + PHHBCI_LEN_LRC
PHHBCI_GPIO_TIMEOUT_MS = 10000
PHHBCI_GPIO_QBTIMEOUT_MS = 5000
PHHBCI_APDU_SEG_FLAG = 0x8000


class HbciCLA(IntFlag):
    CLA_GENERAL_QRY = 0x01
    CLA_GENERAL_ANS = 0x02
    CLA_GENERAL_CMD = 0x03
    CLA_GENERAL_ACK = 0x04
    CLA_TEST_OS_QRY = 0x11
    CLA_TEST_OS_ANS = 0x12
    CLA_TEST_OS_CMD = 0x13
    CLA_PATCH_ROM_QRY = 0x21
    CLA_PATCH_ROM_ANS = 0x22
    CLA_PATCH_ROM_CMD = 0x23
    CLA_HIF_IMAGE_QRY = 0X51
    CLA_HIF_IMAGE_ANS = 0x52
    CLA_HIF_IMAGE_CMD = 0x53


class HbciGenQryIns(IntFlag):
    INS_STATUS = 0x21
    INS_CHIP_ID = 0x31
    INS_HELIOS_ID = 0x32
    INS_CA_RPKEY = 0x33
    INS_NXP_PKEY = 0x34


class HbciGenAnsIns(IntFlag):
    INS_HBCI_READY = 0x21
    INS_MODE_TOS_READY = 0x22
    INS_MODE_PROM_READY = 0x23
    INS_MODE_HIF_IMG_READY = 0x24
    INS_MODE_IM4_IMG_READY = 0x25
    INS_CHIP_ID = 0x31
    INS_HELIOS_ID = 0x32
    INS_CA_RPKEY = 0x33
    INS_NXP_PKEY = 0x34
    INS_HBCI_FAIL = 0xE1
    INS_MODE_TOS_FAIL = 0xE2
    INS_MODE_PROM_FAIL = 0xE3
    INS_MODE_HIF_IMG_FAIL = 0xE4
    INS_MODE_IM4_IMG_FAIL = 0xE5


class HbciGenCmdIns(IntFlag):
    INS_MODE_TOS = 0x22
    INS_MODE_PROM = 0x23
    INS_MODE_HIF_IMG = 0x24
    INS_MODE_IM4_IMG = 0x25


class HbciGenAckIns(IntFlag):
    INS_VALID_APDU = 0x01
    INS_LRC_MISMATCH = 0x81
    INS_INVALID_CLA = 0x82
    INS_INVALID_INS = 0x83
    INS_INVALID_SEG_LEN = 0x84


class HbciTestOSQryIns(IntFlag):
    INS_WRITE_STATUS = 0x01
    INS_AUTH_STATUS = 0x02
    INS_JTAG2AHB_STATUS = 0x03
    INS_PAYLOAD_STATUS = 0x04
    INS_DEV_STATUS = 0x08
    INS_ATTEMPT_REMAINING = 0x09


class HbciTestOSAnsIns(IntFlag):
    INS_WRITE_SUCCESS = 0x01
    INS_AUTH_SUCCESS = 0x02
    INS_JTAG2AHB_SUCCESS = 0x03
    INS_PAYLOAD_SUCCESS = 0x04
    INS_DEV_UNLOCKED = 0x08
    INS_ATTEMPT_REMAINING = 0x09
    INS_OTP_FULL = 0x81
    INS_INVALID_PWD_LEN = 0x82
    INS_AUTH_FAIL = 0x83
    INS_DEV_LOCKED = 0x84
    INS_JTAG2AHB_FAIL = 0x85
    INS_PAYLOAD_FAIL = 0x86


class HbciTestOSCmdIns(IntFlag):
    INS_WRITE_PWD = 0x01
    INS_AUTH_PWD = 0x02
    INS_ENABLE_JTAG2AHB = 0x24
    INS_DOWNLOAD_PAYLOAD = 0x25


class HbciBootROMQryIns(IntFlag):
    INS_PATCH_STATUS = 0x01


class HbciBootROMAnsIns(IntFlag):
    INS_PATCH_SUCCESS = 0x01
    INS_PATCH_FILE_TOO_LARGE = 0x81
    INS_INVALID_PATCH_FILE_MARKER = 0x82
    INS_TOO_MANY_PATCH_TBL_ENTRY = 0x83
    INS_INVALID_PATCH_CODE_SIZE = 0x84
    INS_INVALID_GLOBAL_PATCH_MARKER = 0x85
    INS_INVALID_SIG_SIZE = 0x86
    INS_INVALID_SIG = 0X87


class HbciBootROMCMD(IntFlag):
    INS_DOWNLOAD_PATCH = 0x01


class HbciHIFImgQryIns(IntFlag):
    INS_IMG_STATUS = 0x01


class HbciHIFImgAnsIns(IntFlag):
    INS_IMG_SUCCESS = 0X01
    INS_HDR_SUCCESS = 0x04
    INS_QUICK_BOOT_SET_SUCCESS = 0x05
    INS_HDR_TOO_LARGE = 0x81
    INS_HDR_PARSE_ERROR = 0X82
    INS_INV_CIPHER_TYPE_CRYPTO = 0x83
    INS_INV_CIPHER_TYPE_MODE = 0x84
    INS_INV_CIPHER_TYPE_HASH = 0x85
    INS_INV_CIPHER_TYPE_CURVE = 0x86
    INS_INV_ECC_KEY_LEN_ERR = 0x87
    INS_INV_PAYLOAD_DESCR = 0x88
    INS_INV_FW_VERSION = 0x89
    INS_INV_ECID_MASK = 0x8A
    INS_INV_ECID_VALUE = 0x8B
    INS_INV_ENC_PAYLOAD_HASH = 0x8C
    INS_INV_HDR_SIG = 0x8D
    INS_INST_SET_TOO_LARGE = 0x8E
    INS_INST_PARSE_ERR = 0x8F
    INS_PAYLOAD_TOO_LARGE = 0x90
    INS_QUICK_BOOT_SET_PARSE_ERR = 0x91
    INS_INV_STATIC_HASH = 0x92
    INS_INV_DYNAMIC_HASH = 0x93
    INS_EXE_SET_PARSE_ERR = 0x94
    INS_KEY_READ_ERR = 0x95


class HbciHIFImgCmdIns(IntFlag):
    INS_DOWNLOAD_IMG = 0x01


class Hbci():
    def __init__(self, write, read, name, dev_type):
        self._write = write
        self._read = read
        self._name = name
        self.dev_type = dev_type
        self.img_size = 0

    def create_apdu_hdr(self, cla, ins, seg=0, length=0):
        apdu = bytearray([cla, ins]) + bytearray(struct.pack("<H", length))
        return apdu

    def create_apdu(self, cla, ins, seg=0, data=None, data_len=0):
        if data_len > 0:
            length = data_len
        elif data is not None:
            length = len(data)
        else:
            length = 0
        apdu = bytearray([cla, ins]) + bytearray(struct.pack("<H", length))
        if length > 0 and data is not None:
            apdu += data
        return apdu

    def calc_lrc(self, data):
        lrc = 0
        for apdu_data in data:
            lrc += apdu_data
        lrc = lrc % 256
        lrc ^= 0xFF
        lrc += 1
        return (lrc & 0xFF)

    def fw_download(self, filename, print_log=False):
        # HBCI Query
        t1 = time.time()
        log.info('\t[HBCI]\t\tFw download in progress...')
        apdu = self.create_apdu(HbciCLA.CLA_GENERAL_QRY, HbciGenQryIns.INS_STATUS)
        log.debug("[" + self._name + "]  TX:" + ':'.join('%02x' % i for i in apdu))

        self._write(apdu, False, True, False)

        expected_res = bytearray([HbciCLA.CLA_GENERAL_ANS, HbciGenAnsIns.INS_HBCI_READY, 0x00, 0x00])
        read_data = self._read(PHHBCI_LEN_HDR)
        log.debug("[" + self._name + "]  RX:" + ':'.join('%02x' % i for i in read_data))

        if expected_res != read_data:
            log.error("fw_download: mismatch (1)")
            log.error("[" + self._name + "]  RX:" + ':'.join('%02x' % i for i in read_data))
            return False

        # HIF Mode
        apdu = self.create_apdu(HbciCLA.CLA_GENERAL_CMD, HbciGenCmdIns.INS_MODE_HIF_IMG)
        log.debug("[" + self._name + "]  TX:" + ':'.join('%02x' % i for i in apdu))

        self._write(apdu, False, True, False)
        expected_res = bytearray([HbciCLA.CLA_GENERAL_ACK, HbciGenAckIns.INS_VALID_APDU, 0x00, 0x00])
        read_data = self._read(PHHBCI_LEN_HDR)

        log.debug('{} HBCI RX {}'.format(self._name, read_data.hex() if read_data else ''))

        if expected_res != read_data and read_data:
            log.error("fw_download: mismatch (2)")
            log.error('{} HBCI RX {}'.format(self._name, read_data.hex() if read_data else ''))
            return False

        # HIF Mode staus query
        apdu = self.create_apdu(HbciCLA.CLA_GENERAL_QRY, HbciGenQryIns.INS_STATUS)
        log.debug("[" + self._name + "]  TX:" + ':'.join('%02x' % i for i in apdu))

        self._write(apdu, False, True, False)
        expected_res = bytearray([HbciCLA.CLA_GENERAL_ANS, HbciGenAnsIns.INS_MODE_HIF_IMG_READY, 0x00, 0x00])
        read_data = self._read(PHHBCI_LEN_HDR)
        log.debug('{} HBCI RX {}'.format(self._name, read_data.hex() if read_data else ''))

        if expected_res != read_data and read_data:
            log.error("fw_download: mismatch (3)")
            log.error('{} HBCI RX {}'.format(self._name, read_data.hex() if read_data else ''))
            return False

        with open(filename, "rb") as fw:
            firmware_data = bytearray(fw.read())
            image_size = 0 if firmware_data is None else len(firmware_data)
            self.img_size = image_size
            payload_size = image_size
            image_idx = 0
            while True:
                if image_size > PHHBCI_MAX_LEN_DATA_MOSI:
                    data_size = PHHBCI_MAX_LEN_DATA_MOSI
                    payload_size = PHHBCI_APDU_SEG_FLAG
                else:
                    lrc = PHHBCI_LEN_LRC if image_size else 0
                    data_size = image_size
                    payload_size = data_size + lrc

                data_len = payload_size

                # FW Backet header Download 0
                apdu_hdr = self.create_apdu_hdr(HbciCLA.CLA_HIF_IMAGE_CMD, HbciHIFImgCmdIns.INS_DOWNLOAD_IMG, 0x00,
                                                data_len)
                log.debug("[" + self._name + "]  TX:" + ':'.join('%02x' % i for i in apdu_hdr))
                self._write(apdu_hdr, False, True, False)
                expected_res = bytearray([HbciCLA.CLA_GENERAL_ACK, HbciGenAckIns.INS_VALID_APDU, 0x00, 0x00])

                read_data = self._read(PHHBCI_LEN_HDR)
                log.debug("[" + self._name + "]  RX:" + ':'.join('%02x' % i for i in read_data))

                if expected_res != read_data:
                    log.error("fw_download: mismatch (4)")
                    log.error('{} HBCI RX {}'.format(self._name, read_data.hex() if read_data else ''))
                    return False

                if data_size:
                    data_to_send = bytearray(firmware_data[image_idx:image_idx + data_size])

                    apdu = self.create_apdu(HbciCLA.CLA_HIF_IMAGE_CMD, HbciHIFImgCmdIns.INS_DOWNLOAD_IMG, 0x00,
                                            data_to_send, payload_size)
                    lrc = self.calc_lrc(apdu)
                    data_to_send += bytearray([lrc])
                    log.debug("[" + self._name + "]  TX:" + ':'.join('%02x' % i for i in (data_to_send)))
                    self._write(data_to_send, False, True, False)
                    expected_res = bytearray([HbciCLA.CLA_GENERAL_ACK, HbciGenAckIns.INS_VALID_APDU, 0x00, 0x00])
                    read_data = self._read(PHHBCI_LEN_HDR)
                    log.debug('{} HBCI RX {}'.format(self._name, read_data.hex() if read_data else ''))

                    image_idx += data_size
                    image_size -= data_size
                    payload_size = data_size + PHHBCI_LEN_LRC

                    if expected_res != read_data:
                        log.error("fw_download: mismatch (5)")
                        return False

                # exit while loop
                if image_size <= 0:
                    break

        if self.dev_type == 'CONTRONIX':
            time.sleep(0.3)
        # FW Download status Query
        apdu = self.create_apdu(HbciCLA.CLA_HIF_IMAGE_QRY, HbciHIFImgQryIns.INS_IMG_STATUS)
        apdu and log.debug("[" + self._name + "]  TX:" + ':'.join('%02x' % i for i in (apdu)))
        self._write(apdu, False, False, True)
        expected_res = bytearray([HbciCLA.CLA_HIF_IMAGE_ANS, HbciHIFImgAnsIns.INS_IMG_SUCCESS, 0x00, 0x00])
        read_data = self._read(PHHBCI_LEN_HDR, 5)
        log.debug('{} HBCI RX {}'.format(self._name, read_data.hex() if read_data else ''))

        if expected_res != read_data:
            log.error("fw_download: mismatch (6)")
            return False
        log.info('\t[HBCI]\t\tFw download success. Image Size: {} Time Taken: {} secs'.format(self.img_size,
                                                                                           time.time() - t1))
        time.sleep(0.3)
        return True

    def get_chip_id(self):
        try:
            cla = HbciCLA.CLA_GENERAL_QRY
            ins = HbciGenQryIns.INS_CHIP_ID
            read_query_data = None

            apdu = self.create_apdu(cla, ins)
            logstr = "[" + self._name + "]  TX:" + ':'.join('%02x' % i for i in (apdu))
            log.debug(logstr)
            self._write(apdu, uci_pkt=False, hbci_custom_pkt=True, length=4)
            log.debug(f'{self._name}: write apdu is done!!!')

            read_data = self._read(PHHBCI_LEN_HDR)
            log.debug(f'{self._name}: read apdu is done!!!')
            logstr = "[" + self._name + "]  RX:" + ':'.join('%02x' % i for i in read_data)
            log.debug(logstr)

            rcvd_cls = read_data[0]
            rcvd_ins = read_data[1]
            payload_size = read_data[2]
            segment = (payload_size & PHHBCI_APDU_SEG_FLAG)

            lrc = PHHBCI_LEN_LRC if payload_size else 0
            data_size = payload_size - lrc
            if segment:
                data_size = PHHBCI_MAX_LEN_DATA_MOSI

            apdu = self.create_apdu(HbciCLA.CLA_GENERAL_ACK, HbciGenAckIns.INS_VALID_APDU, data_len=read_data[2])
            logstr = "[" + self._name + "]  TX:" + ':'.join('%02x' % i for i in (apdu))
            log.debug(logstr)
            self._write(apdu, uci_pkt=False, hbci_custom_pkt=True, length=read_data[2])
            read_query_data = self._read(apdu[2])
            logstr = "[" + self._name + "]  RX:" + ':'.join('%02x' % i for i in read_query_data)
            log.debug(logstr)
            read_query_data_bytearray = (''.join(format(x, '02x') for x in read_query_data))
            received_crc = int(read_query_data_bytearray[-2:], 16)

            payload_buf = bytearray(read_query_data[0:data_size])
            apdu = self.create_apdu(rcvd_cls, rcvd_ins, data=payload_buf, data_len=payload_size)
            lrc = self.calc_lrc(apdu)
            if received_crc == lrc:
                chip_id = hex(int.from_bytes(payload_buf[0:16], byteorder='big'))
                return chip_id
            else:
                log.error("CHIP ID : LRC DOESN'T MATCH")
                return None
        except Exception as e:
            log.error('Error in getting chip id from bootrom.\n{}'.format(e))
            return None
