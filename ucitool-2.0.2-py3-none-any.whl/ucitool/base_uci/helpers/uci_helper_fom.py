#   Copyright (c), 2020 NXP Semiconductors
#   All rights are reserved. Reproduction in whole or in part is
#   prohibited without the written consent of the copyright owner.
#   #
#   NXP reserves the right to make changes without notice at any time.
#   #
#   NXP makes no warranty, expressed, implied or statutory, including but
#   not limited to any implied warranty of merchantability or fitness for any
#   particular purpose, or that the use will not infringe any third party patent,
#   copyright or trademark. NXP must not be liable for any loss or damage
#   arising from its use.


import time

from ucitool.base_uci.cmds import Cmds, get_uci, APP_CFG, DEVICE_CFG, PLATFORM, BOARD_VARIANT, SESSION_TYPE, TEST_CFG, \
    CALIB_TYPE
from ucitool.base_uci.uci import UciHost, ConfigSetBuilder, ConfigGetBuilder


def __calculate_time(func):
    """
    Decorator to find a UCI run time.
    """

    def run(*args, **kwargs):
        t1 = time.time()
        ret = func(*args, **kwargs)
        print('Time taken to execute {} is {} secs'.format(func.__name__, time.time() - t1))
        return ret

    return run


def session_get_count(dev):
    """
        UCI cmd to retrieve the session count
        """
    uci = get_uci(Cmds.SESSION_GET_COUNT)
    return dev.exec_uci(uci)


def get_dev_info(dev):
    """
    UCI cmd to retrieve the
    device information like (UCI version and other vendor specific info)
    """
    uci = get_uci(Cmds.GET_DEV_INFO)
    return dev.exec_uci(uci)


def get_caps(dev):
    """
    DH shall use CORE_GET_CAPS_INFO_CMD command to get the capability of the UWBD.
    The capability information is vendor specific and DH shall use capability information to communicate with UWBD.
    """
    uci = get_uci(Cmds.GET_CAPS_INFO)
    return dev.exec_uci(uci)


def set_device_config(dev, config=None, value=None):
    """
    UCI to  set the device configuration parameters.
    """
    uci = get_uci(Cmds.SET_CONFIG)
    c_builder = ConfigSetBuilder()
    if config and value:
        uci.PARAMETERS = 1
        c_builder.add_attr(config, value)
    else:
        uci.PARAMETERS = 1
        c_builder.add_attr(DEVICE_CFG.LOW_POWER_MODE, DEVICE_CFG.LOW_POWER_MODE.DISABLED)
    uci.DEVICE_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_device_config(dev, config=None):
    """
    UCI to get the current device configuration
    """
    uci = get_uci(Cmds.GET_CONFIG)
    c_builder = ConfigGetBuilder()
    if config:
        uci.PARAMETERS = 1
        c_builder.add_attr(config)
    else:
        uci.PARAMETERS = 5
        c_builder.add_attr(DEVICE_CFG.DPD_WAKEUP_SRC).add_attr(DEVICE_CFG.AOA_CALIBRATION_CTRL)
        c_builder.add_attr(DEVICE_CFG.WTX_COUNT_CONFIG).add_attr(DEVICE_CFG.DELAY_CALIBRATION)
        c_builder.add_attr(DEVICE_CFG.DEVICE_STATUS)
    uci.DEVICE_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def device_suspend(dev):
    """
    UCI to put device into suspend
    """
    return dev.exec_uci(get_uci(Cmds.DEV_SUSPEND))


def device_reset(dev):
    """
    UCI to reset device
    """
    uci = get_uci(Cmds.DEVICE_RESET)
    # uci.RESET_CONFIG =  Todo Need to fill this
    return dev.exec_uci(uci)


def session_init(dev, session_id=0x11111111, session_type=SESSION_TYPE.SESSION_RANGING):
    """
    UCI to create the new UWB session
    :param : session ID
             session_type: SESSION_RANGING,SESSION_DATA_TRANSFER,SESSION_DEVICE_TEST_MODE
    """
    uci = get_uci(Cmds.SESSION_INIT)
    uci.SESSION_ID = session_id
    uci.SESSION_TYPE = session_type
    return dev.exec_uci(uci)


def session_de_init(dev, session_id=0x11111111):
    """
    UCI to de-initialize the session
    param : session ID
    """
    uci = get_uci(Cmds.SESSION_DEINIT)
    uci.SESSION_ID = session_id
    return dev.exec_uci(uci)


def set_app_config(dev, session_id=0x11111111, device_role=APP_CFG.DEVICE_ROLE.INITIATOR,
                   device_type=APP_CFG.DEVICE_TYPE.CONTROLLER,
                   src_addr=APP_CFG.SRC_MAC_ADDRESS.MASTER_ADDR,
                   dst_addr=APP_CFG.DST_MAC_ADDRESS_LIST.ANCHOR_ADDR,
                   rng_type=APP_CFG.RANGING_CONFIG.DS_TWR,
                   channel=APP_CFG.CHANNEL_ID.CH_5,
                   ppdu_cfg=APP_CFG.RFRAME_CONFIG.STS_FOLLOWS_SFD_NO_PPDU,
                   multi_node_mode=APP_CFG.MULTI_NODE_MODE.SINGLE_DEVICE_TO_SINGLE_DEVICE,
                   no_of_anchors=APP_CFG.NUMBER_OF_CONTROLEES.SINGLE_ANCHOR,
                   rx_mode=APP_CFG.RX_MODE.DUAL_RX,
                   tx_antenna=None,
                   rx_antenna=None):
    """
    UCI to set application configuration parameters
    :param:device_role:CONTROLLER, CONTROLEE
           device_type:INITIATOR,RESPONDER
           src_addr:SRC_MAC_ADDRESS
           dst_addr:DST_MAC_ADDRESS
           rng_type:ONE_WAY,DS_TWR,SS_TWR
           ppdu_cfg: NO_STS,STS_FOLLOWS_SFD,STS_FOLLOWS_PSDU,STS_FOLLOWS_SFD_NO_PPDU
           power_idx: 0-127
    """
    uci = get_uci(Cmds.SET_APP_CONFIG)
    uci.SESSION_ID = session_id
    c_builder = ConfigSetBuilder()
    c_builder.add_attr(APP_CFG.DEVICE_ROLE, device_role)
    c_builder.add_attr(APP_CFG.RANGING_CONFIG, rng_type)
    c_builder.add_attr(APP_CFG.STS_CONFIG, APP_CFG.STS_CONFIG.NO_SE_STATIC_STS)
    c_builder.add_attr(APP_CFG.MULTI_NODE_MODE, multi_node_mode)
    c_builder.add_attr(APP_CFG.CHANNEL_ID, channel)
    c_builder.add_attr(APP_CFG.NUMBER_OF_CONTROLEES, no_of_anchors)
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS, src_addr)
    c_builder.add_attr(APP_CFG.DST_MAC_ADDRESS_LIST, dst_addr)
    c_builder.add_attr(APP_CFG.SLOT_DURATION, APP_CFG.SLOT_DURATION.DEFAULT_RANGING)
    c_builder.add_attr(APP_CFG.RANGING_INTERVAL, APP_CFG.RANGING_INTERVAL.DEFAULT_RANGING)
    c_builder.add_attr(APP_CFG.STS_INDEX, APP_CFG.STS_INDEX.STS_ZERO)
    c_builder.add_attr(APP_CFG.MAC_TYPE, APP_CFG.MAC_TYPE.CRC_16)
    c_builder.add_attr(APP_CFG.AOA_RESULT_REQ, APP_CFG.AOA_RESULT_REQ.NEG_90_TO_90)
    c_builder.add_attr(APP_CFG.RNG_DATA_NTF, APP_CFG.RNG_DATA_NTF.ENABLE)
    c_builder.add_attr(APP_CFG.RNG_DATA_NTF_PROXIMITY_FAR, APP_CFG.RNG_DATA_NTF_PROXIMITY_FAR.DEFAULT_RANGING)
    c_builder.add_attr(APP_CFG.NEAR_PROXIMITY_CONFIG, APP_CFG.NEAR_PROXIMITY_CONFIG.DEFAULT_RANGING)
    c_builder.add_attr(APP_CFG.DEVICE_TYPE, device_type)
    c_builder.add_attr(APP_CFG.MAC_CFG, APP_CFG.MAC_CFG.FIRA_SESSION)  # check cpec and uci
    c_builder.add_attr(APP_CFG.RX_MODE, rx_mode)
    c_builder.add_attr(APP_CFG.RFRAME_CONFIG, ppdu_cfg)
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX, APP_CFG.PREAMBLE_CODE_INDEX.DEFAULT_BPRF)
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE, APP_CFG.PSDU_DATA_RATE.DEFAULT)
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR, APP_CFG.PREAMBLE_DUR.DEFAULT)
    c_builder.add_attr(APP_CFG.TOA_MODE, APP_CFG.TOA_MODE.FIRSTPATH_ON_RX1RX2)
    if (tx_antenna is not None):
        c_builder.add_attr(APP_CFG.TX_ANTENNA_SELECTION, tx_antenna)
    if (rx_antenna is not None):
        c_builder.add_attr(APP_CFG.RX_ANTENNA_PAIR_SEL, rx_antenna)
    uci.NUM_CONFIGS = len(c_builder)
    uci.APP_TLV = c_builder.get()
    return dev.exec_uci(uci)


def set_config(dev, config, value, session_id=0x11111111):
    """
    UCI to set configuration paramters
    :param:
    session_id
    config: any APP_CFG param
    value:
    """
    c_builder = ConfigSetBuilder()
    uci = get_uci(Cmds.SET_APP_CONFIG)
    uci.NUM_CONFIGS = 1
    uci.SESSION_ID = session_id
    c_builder.add_attr(config, value)
    uci.APP_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_config(dev, config, session_id=0x11111111):
    """
     UCI to get the  configurations
     :param: session_id
             onfig: any APP_CFG param
    """
    c_builder = ConfigGetBuilder()
    uci = get_uci(Cmds.GET_APP_CONFIG)
    uci.NUM_CONFIGS = 1
    uci.SESSION_ID = session_id
    uci.APP_PARAMS = c_builder.get()
    c_builder.add_attr(config)
    return dev.exec_uci(uci)


def get_app_config(dev, session_id=0x11111111):
    """
    UCI to get the application parameters
    param : session_id
    """
    uci = get_uci(Cmds.GET_APP_CONFIG)
    uci.SESSION_ID = session_id
    uci.NUM_CONFIGS = 25
    c_builder = ConfigGetBuilder()
    c_builder.add_attr(APP_CFG.DEVICE_ROLE),
    c_builder.add_attr(APP_CFG.RANGING_CONFIG),
    c_builder.add_attr(APP_CFG.STS_CONFIG),
    c_builder.add_attr(APP_CFG.MULTI_NODE_MODE),
    c_builder.add_attr(APP_CFG.CHANNEL_ID),
    c_builder.add_attr(APP_CFG.NUMBER_OF_CONTROLEES),
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS),
    c_builder.add_attr(APP_CFG.DST_MAC_ADDRESS_LIST),
    c_builder.add_attr(APP_CFG.SLOT_DURATION),
    c_builder.add_attr(APP_CFG.RANGING_INTERVAL),
    c_builder.add_attr(APP_CFG.STS_INDEX),
    c_builder.add_attr(APP_CFG.MAC_TYPE),
    c_builder.add_attr(APP_CFG.AOA_RESULT_REQ),
    c_builder.add_attr(APP_CFG.RNG_DATA_NTF),
    c_builder.add_attr(APP_CFG.RNG_DATA_NTF_PROXIMITY_FAR),
    c_builder.add_attr(APP_CFG.NEAR_PROXIMITY_CONFIG),
    c_builder.add_attr(APP_CFG.DEVICE_TYPE),
    c_builder.add_attr(APP_CFG.MAC_CFG),
    c_builder.add_attr(APP_CFG.RX_MODE),
    c_builder.add_attr(APP_CFG.RFRAME_CONFIG),
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX),
    c_builder.add_attr(APP_CFG.SFD_ID),
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE),
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR),
    c_builder.add_attr(APP_CFG.TOA_MODE),
    uci.APP_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def set_channel(dev, session_id=0x11111111, channel=APP_CFG.CHANNEL_ID.CH_5):
    """
     UCI to set channel
     :param: session_id
             channel: CH_5,CH_6,CH_7,CH_8,CH_9
    """
    return set_config(dev, session_id=session_id, config=APP_CFG.CHANNEL_ID, value=channel)


def set_power_idx(dev, channel=APP_CFG.CHANNEL_ID.CH_9, pwr_idx=0x0, session_id=0x0):
    """
      UCI to set power
      :param:
        channel: 5, 6, 8, 9
        pwr_idx: 0 to 127
      """
    set_config(dev, session_id=session_id, config=APP_CFG.TX_ADAPTIVE_PAYLOAD_POWER,
               # disable rms power index per pay load
               value=APP_CFG.TX_ADAPTIVE_PAYLOAD_POWER.DISABLED)
    return set_calibration(dev, channel, CALIB_TYPE.TX_POWER, pwr_idx)


def get_calibration(dev, channel=APP_CFG.CHANNEL_ID.CH_9, calibParam=CALIB_TYPE.TX_POWER):
    """
    channel: channel for which param is applied and to be read
    calibPAram: calib param Id.
    return: calib value
    """
    uci = get_uci(Cmds.GET_DEVICE_CALIBRATION)
    uci.CHANNEL_ID = channel
    uci.CALIB_PARAM = calibParam
    return dev.exec_uci(uci)


def set_calibration(dev, channel=APP_CFG.CHANNEL_ID.CH_9, calibParam=CALIB_TYPE.TX_POWER, value=0):
    """
    channel: channel for which calibration to be set
    calibParam: calib param Id.
    calibvalue: calib param Id.
    return: rsp
    """
    uci = get_uci(Cmds.SET_DEVICE_CALIBRATION)
    uci.CHANNEL_ID = channel
    uci.CALIB_PARAM = calibParam
    if isinstance(value, int):
        ln = max((value.bit_length() + 7) // 8, 2)  # min calib value is of len 2
        value = list(value.to_bytes(ln, 'little'))
    uci.CALIBRATION_VALUE = value
    return dev.exec_uci(uci)


def do_calibration(dev, channel=APP_CFG.CHANNEL_ID.CH_9, calibParam=CALIB_TYPE.VCO_PLL):
    """
    channel: channel for which calibration to be done
    calibPAram: calib param Id.
    return: rsp
    """
    uci = get_uci(Cmds.DO_CALIBRATION)
    uci.CHANNEL_ID = channel
    uci.CALIB_PARAM = calibParam
    return dev.exec_uci(uci)


def set_ranging_interval(dev, session_id=0x11111111, ri=APP_CFG.RANGING_INTERVAL.DEFAULT_RANGING):
    """  Ranging interval is time in ms between beginning of one ranging round to the beginning of the next.
    Minimum Ranging interval should be at least the duration of one ranging round length.
    :param: session_id
            ranging interval:  DEFAULT_RANGING(200ms)
    """
    return set_config(dev, session_id=session_id, config=APP_CFG.RANGING_INTERVAL, value=ri)


def set_ppdu_config(dev, session_id=0x11111111, ppdu=APP_CFG.RFRAME_CONFIG.STS_FOLLOWS_PSDU):
    """
    UCI to set ppdu configuration
    :param: session_id
            ppdu:NO_STS,STS_FOLLOWS_SFD,STS_FOLLOWS_PSDU,STS_FOLLOWS_SFD_NO_PPDU
    """
    return set_config(dev, session_id=session_id, config=APP_CFG.RFRAME_CONFIG, value=ppdu)


def set_sts_config(dev, session_id=0x11111111, sts=APP_CFG.STS_CONFIG.NO_SE_STATIC_STS):
    """
    This parameter indicates how system shall generate the STS.
    0= Static STS (SE not involved) (default)
    1= Dynamic STS (Session Key will be generated via SE)
    """
    return set_config(dev, session_id=session_id, config=APP_CFG.STS_CONFIG, value=sts)


def set_app_config_per(dev, session_id=0x0,
                       src_addr=APP_CFG.SRC_MAC_ADDRESS.MASTER_ADDR,
                       dst_addr=APP_CFG.DST_MAC_ADDRESS_LIST.ANCHOR_ADDR,
                       preamble_id=APP_CFG.PREAMBLE_CODE_INDEX.DEFAULT_BPRF,
                       channel=APP_CFG.CHANNEL_ID.CH_9,
                       rx_mode=APP_CFG.RX_MODE.DUAL_RX,
                       tx_antenna=None,
                       rx_antenna=None):
    """
    UCI to set application configuration to prepare device for PER test
    parma:  session_id
              src :SRC_MAC_ADDRESS
              dst :DST_MAC_ADDRESS
              preamble_id :PREAMBLE_ID.DEFAULT(18-dec)
              channel :CH_5,CH_6,CH_7,CH_8,CH_9
              power_idx :DEFAULT_MAX_POWER
    """
    uci = get_uci(Cmds.SET_APP_CONFIG)
    uci.SESSION_ID = session_id
    c_builder = ConfigSetBuilder()
    c_builder.add_attr(APP_CFG.CHANNEL_ID, channel),
    c_builder.add_attr(APP_CFG.STS_CONFIG, APP_CFG.STS_CONFIG.NO_SE_STATIC_STS),
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS, src_addr),
    c_builder.add_attr(APP_CFG.DST_MAC_ADDRESS_LIST, dst_addr),
    c_builder.add_attr(APP_CFG.STS_INDEX, APP_CFG.STS_INDEX.STS_ZERO),
    c_builder.add_attr(APP_CFG.NUMBER_OF_CONTROLEES, APP_CFG.NUMBER_OF_CONTROLEES.SINGLE_ANCHOR),
    c_builder.add_attr(APP_CFG.MAC_TYPE, APP_CFG.MAC_TYPE.CRC_16),
    c_builder.add_attr(APP_CFG.MAC_CFG, APP_CFG.MAC_CFG.DEFAULT_PER),
    c_builder.add_attr(APP_CFG.RX_MODE, rx_mode),
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX, preamble_id),
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE, APP_CFG.PSDU_DATA_RATE.DEFAULT),
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR, APP_CFG.PREAMBLE_DUR.DEFAULT)
    toa_mode = APP_CFG.TOA_MODE.FIRSTPATH_ON_RX1RX2
    if rx_mode == APP_CFG.RX_MODE.DUAL_RX:
        toa_mode = APP_CFG.TOA_MODE.FIRSTPATH_ON_RX1RX2
    elif rx_mode == APP_CFG.RX_MODE.RX1:
        toa_mode = APP_CFG.TOA_MODE.FIRSTPATH_ON_RX1
    elif rx_mode == APP_CFG.RX_MODE.RX2:
        toa_mode = APP_CFG.TOA_MODE.FIRSTPATH_ON_RX2
    c_builder.add_attr(APP_CFG.TOA_MODE, toa_mode)
    if tx_antenna is not None:
        c_builder.add_attr(APP_CFG.TX_ANTENNA_SELECTION, tx_antenna)
    if rx_antenna is not None:
        c_builder.add_attr(APP_CFG.RX_ANTENNA_PAIR_SEL, rx_antenna)
    uci.NUM_CONFIGS = len(c_builder)
    uci.APP_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_app_config_per(dev):
    """
    UCI to get the per application configurations
    """
    uci = get_uci(Cmds.GET_APP_CONFIG)
    uci.SESSION_ID = 0  # for per session id is always 0
    uci.NUM_CONFIGS = 14
    c_builder = ConfigGetBuilder()
    c_builder.add_attr(APP_CFG.CHANNEL_ID),
    c_builder.add_attr(APP_CFG.STS_CONFIG),
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS),
    c_builder.add_attr(APP_CFG.DST_MAC_ADDRESS_LIST),
    c_builder.add_attr(APP_CFG.STS_INDEX),
    c_builder.add_attr(APP_CFG.MAC_TYPE),
    c_builder.add_attr(APP_CFG.MAC_CFG),
    c_builder.add_attr(APP_CFG.RX_MODE),
    c_builder.add_attr(APP_CFG.RFRAME_CONFIG),
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX),
    c_builder.add_attr(APP_CFG.SFD_ID),
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE),
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR),
    c_builder.add_attr(APP_CFG.TOA_MODE),
    uci.APP_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def set_test_config(dev, config, value, session_id=0x0):
    """
    UCI to set test onfiguration paramters
    :param:
    session_id
    config: any TEST_CFG param
    value:
    """
    c_builder = ConfigSetBuilder()
    uci = get_uci(Cmds.TEST_CONFIG_SET)
    uci.NUM_TEST_CONFIG = 1
    uci.SESSION_ID = session_id
    c_builder.add_attr(config, value)
    uci.TEST_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_test_config(dev, config):
    """
    UCI to get  test configurations.
    """
    uci = get_uci(Cmds.TEST_CONFIG_GET)
    uci.SESSION_ID = 0
    uci.NUM_TEST_CONFIG = 1
    c_builder = ConfigGetBuilder()
    c_builder.add_attr(config)
    uci.TEST_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def set_test_config_per(dev,
                        n_pkts=TEST_CFG.NUM_PACKETS.DEFAULT,
                        tgap=TEST_CFG.T_GAP.DEFAULT,
                        tstart=TEST_CFG.T_START.DEFAULT,
                        twin=TEST_CFG.T_WIN.DEFAULT,
                        rawphr=TEST_CFG.RAW_PHR.RANGE_ENABLED
                        ):
    """UCI to set test configurations for per test
      params: n_pkts : number of packets
              tgap   : gap between start of one packet to the next in us
              tstart : Max time from the start of T_GAP to SFD found state in us
              twin   : Max time for which RX is looking for a packet from the start of T_GAP in us
      """
    uci = get_uci(Cmds.TEST_CONFIG_SET)
    uci.NUM_TEST_CONFIG = 9
    uci.SESSION_ID = 0  # per session id is 0 always
    c_builder = ConfigSetBuilder()
    c_builder.add_attr(TEST_CFG.NUM_PACKETS, n_pkts),
    c_builder.add_attr(TEST_CFG.T_GAP, tgap),
    c_builder.add_attr(TEST_CFG.T_START, tstart),
    c_builder.add_attr(TEST_CFG.T_WIN, twin),
    c_builder.add_attr(TEST_CFG.RANDOMIZE_PSDU, TEST_CFG.RANDOMIZE_PSDU.DEFAULT),
    c_builder.add_attr(TEST_CFG.RAW_PHR, rawphr),
    c_builder.add_attr(TEST_CFG.RMARKER_RX_START, TEST_CFG.RMARKER_RX_START.DEFAULT),
    c_builder.add_attr(TEST_CFG.RMARKER_TX_START, TEST_CFG.RMARKER_TX_START.DEFAULT),
    c_builder.add_attr(TEST_CFG.STS_INDEX_AUTO_INCR, TEST_CFG.STS_INDEX_AUTO_INCR.DEFAULT)
    uci.TEST_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_test_config_per(dev):
    """
    UCI to get per test configurations.
    """
    uci = get_uci(Cmds.TEST_CONFIG_GET)
    uci.SESSION_ID = 0
    uci.NUM_TEST_CONFIG = 9
    c_builder = ConfigGetBuilder()
    c_builder.add_attr(TEST_CFG.NUM_PACKETS),
    c_builder.add_attr(TEST_CFG.T_GAP),
    c_builder.add_attr(TEST_CFG.T_START),
    c_builder.add_attr(TEST_CFG.T_WIN),
    c_builder.add_attr(TEST_CFG.RANDOMIZE_PSDU),
    c_builder.add_attr(TEST_CFG.RAW_PHR),
    c_builder.add_attr(TEST_CFG.RMARKER_RX_START),
    c_builder.add_attr(TEST_CFG.RMARKER_TX_START),
    c_builder.add_attr(TEST_CFG.STS_INDEX_AUTO_INCR)
    uci.TEST_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def set_app_config_data(dev, session_id=0x1, device_type=APP_CFG.DEVICE_TYPE.CONTROLLER,
                        src_addr=APP_CFG.SRC_MAC_ADDRESS.MASTER_ADDR):
    """
       UCI to set application parameters for data transfer.
       :param: session_id
                device_type : INITIATOR,RESPONDER
                src_addr :  SRC_MAC_ADDRESS
    """
    uci = get_uci(Cmds.SET_APP_CONFIG)
    uci.SESSION_ID = session_id
    uci.NUM_CONFIGS = 12
    c_builder = ConfigSetBuilder()
    c_builder.add_attr(APP_CFG.DEVICE_TYPE, device_type),
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS, src_addr),
    c_builder.add_attr(APP_CFG.CHANNEL_ID, APP_CFG.CHANNEL_ID.CH_5),
    c_builder.add_attr(APP_CFG.STS_CONFIG, APP_CFG.STS_CONFIG.NO_SE_STATIC_STS),
    c_builder.add_attr(APP_CFG.STS_INDEX, APP_CFG.STS_INDEX.STS_ZERO),
    c_builder.add_attr(APP_CFG.MAC_TYPE, APP_CFG.MAC_TYPE.CRC_16),
    c_builder.add_attr(APP_CFG.MAC_CFG, APP_CFG.MAC_CFG.FIRA_SESSION),
    c_builder.add_attr(APP_CFG.RX_MODE, APP_CFG.RX_MODE.DUAL_RX),
    c_builder.add_attr(APP_CFG.RFRAME_CONFIG, APP_CFG.RFRAME_CONFIG.STS_FOLLOWS_SFD_NO_PPDU),
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX, APP_CFG.PREAMBLE_CODE_INDEX.DEFAULT_BPRF),
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE, APP_CFG.PSDU_DATA_RATE.DEFAULT),
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR, APP_CFG.PREAMBLE_DUR.DEFAULT),
    uci.APP_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_app_config_data(dev, session_id=0x1):
    """
     UCI to get configurations of data transfer
    :param: session_id
    """
    uci = get_uci(Cmds.GET_APP_CONFIG)
    uci.SESSION_ID = session_id
    uci.NUM_CONFIGS = 13
    c_builder = ConfigGetBuilder()
    c_builder.add_attr(APP_CFG.DEVICE_TYPE),
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS),
    c_builder.add_attr(APP_CFG.CHANNEL_ID),
    c_builder.add_attr(APP_CFG.STS_CONFIG),
    c_builder.add_attr(APP_CFG.STS_INDEX),
    c_builder.add_attr(APP_CFG.MAC_TYPE),
    c_builder.add_attr(APP_CFG.MAC_CFG),
    c_builder.add_attr(APP_CFG.RX_MODE),
    c_builder.add_attr(APP_CFG.RFRAME_CONFIG),
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX),
    c_builder.add_attr(APP_CFG.SFD_ID),
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE),
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR),
    uci.APP_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def rng_start(dev, session_id=0x11111111):
    """
       UCI to start ranging
       :param: session_id
    """
    uci = get_uci(Cmds.RANGE_START)
    uci.SESSION_ID = session_id
    return dev.exec_uci(uci)


def rng_stop(dev: object, session_id: object = 0x11111111) -> object:
    """
        UCI to stop ranging
        :param: session_id
    """
    uci = get_uci(Cmds.RANGE_STOP)
    uci.SESSION_ID = session_id
    return dev.exec_uci(uci)


def range_ctrl_request(dev, session_id=None, interval=None):
    """
        UCI to set ranging control request to
        update the ranging interval during activated ranging session
        :param: session_id
                updated ranging interval
    """
    uci = get_uci(Cmds.RANGE_INTERVAL_UPDATE_REQ)
    uci.SESSION_ID = session_id
    uci.RANGING_INTERVAL = interval
    return dev.exec_uci(uci)


def app_data_tx(dev, session_id=None, short_addr=None, app_data=None):
    """
      uci to transfer tx data
      :param:session_id
            short_addr
            app_data
    """
    uci = get_uci(Cmds.APP_DATA_TX)
    uci.SESSION_ID = session_id
    uci.APP_DATA = app_data
    uci.SHORT_ADDR = short_addr
    return dev.exec_uci(uci)


def app_data_rx(dev, session_id=None, short_addr=None):
    """
       uci to get rx data
       :param: session_id
               short_addr
    """
    uci = get_uci(Cmds.APP_DATA_RX)
    uci.SESSION_ID = session_id
    uci.SHORT_ADDR = short_addr
    return dev.exec_uci(uci)


def periodic_tx(dev, psdu_data=None):
    """
      uci to start per tx.
      Issue this after applying all required configuration and the "Device test mode" session must be in SESSION_IDLE.
      Otherwise UWBD responds with TEST_PERIODIC_TX_RSP with status
      STATUS_SESSION_NOT_CONFIGURED error indicating that session is not configured.
      param: psdu_data
     """
    if psdu_data is None:
        psdu_data = [0x1]
    uci = get_uci(Cmds.TEST_PERIODIC_TX)
    uci.PSDU_DATA = psdu_data
    return dev.exec_uci(uci)


def periodic_rx(dev, psdu_data=None):
    """
       uci to start per rx
       param: psdu_data
    """
    if psdu_data is None:
        psdu_data = [0x1]
    uci = get_uci(Cmds.TEST_PER_RX)
    uci.PSDU_DATA = psdu_data
    return dev.exec_uci(uci)


def device_init(dev, board=PLATFORM.RHODES, variant=BOARD_VARIANT.V2):
    """
       uci to set platform configs, defaults to Rhodes V2
       :param:
       board: NXP_REF,SSG,RHODES
    """
    uci = get_uci(Cmds.DEVICE_INIT)
    uci.VARIANT_ID = variant
    uci.PLATFORM_ID = board
    rsp = dev.exec_uci(uci)
    ntf = dev.wait_for_notification(ntf=Cmds.DEVICE_STATUS_NTF, timeout=2)
    retry = 1
    while ntf and ntf.fields['DEVICE_STATUS'].name != 'STATUS_READY':
        ntf = dev.wait_for_notification(ntf=Cmds.DEVICE_STATUS_NTF, timeout=2)
        if retry == 3:
            print('No device ready ntf yet, continue!')
            break
        retry += 1
    return rsp


def se_do_bind(dev):
    """
    UCI to do the binding
    """
    return dev.exec_uci(Cmds.SE_DO_BIND)


def debug_get_error_log(dev):
    """
    DBG_GET_ERROR_LOG_CMD command to fetch the error log from SR100 in STATUS_ERROR state.
    SR100 responds by DBG_GET_ERROR_LOG_RSP with error log data
    """
    return dev.exec_uci(Cmds.DBG_GET_ERROR_LOG)


def rx_test(dev):
    """
     UCI  to recieve a single rx packet
     """
    uci = get_uci(Cmds.TEST_RX)
    return dev.exec_uci(uci)


def tx_test(dev, psdu_data=None):
    """
     UCI  to send a single tx packet
     """
    if psdu_data is None:
        psdu_data = [0x1, 0x2, 0x3, 0x4]
    uci = get_uci(Cmds.TEST_TX)
    uci.PSDU_DATA = psdu_data
    return dev.exec_uci(uci)


def loopback_test(dev, psdu_data=None):
    """
     UCI  to do a device to device loopback
     """
    if psdu_data is None:
        psdu_data = [0x1, 0x2, 0x3, 0x4]
    uci = get_uci(Cmds.TEST_LOOPBACK)
    uci.PSDU_DATA = psdu_data
    return dev.exec_uci(uci)


# @__calculate_time
def device_creation(dev, fw=None, skip_fw_download=False):
    """
     Device host command to do init a device and do UWBD firmware download
    """
    if not skip_fw_download:
        dev.device.fw_download(fw)
    dev.device.uci_handler.start_uci_handler()


def fw_download(dev):
    """
    This does nothing, but a place holder for fw download
    """
    pass


def parse(dev, uci):
    """
      Device host command to parse a uci data
    """
    dev.generate_uci(uci_hex_str=uci)


def get_session_state(dev, session_id=0x11111111):
    uci = get_uci(Cmds.SESSION_GET_STATE)
    uci.SESSION_ID = session_id
    return dev.exec_uci(uci)


# ----------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':
    PARSE = True
    INIT = True
    RANGING = False
    PER = False
    dh1 = UciHost(port='com1', id='master')
    dh2 = UciHost(port='com58', id='anchor')
    if PARSE:
        parse(dh1, '2002001404010100e400020000e4010400000028e4020100')
        parse(dh1,
              '63:00:00:bc:1d:44:33:22:11:08:00:c8:00:01:00:01:e7:00:00:01:37:25:0e:00:28:22:f5:ff:05:00:00:00:00:00:00:00:00:0c:e8:00:00:00:36:25:07:00:28:28:d8:ff:00:00:00:00:00:00:00:00:00:0d:e9:00:00:01:30:25:0a:00:28:26:05:00:02:00:00:00:00:00:00:00:00:0e:ea:00:00:00:48:25:0d:00:2a:2a:f9:ff:00:00:00:00:00:00:00:00:00:0f:eb:00:00:00:83:25:08:00:28:28:00:00:00:00:00:00:00:00:00:00:00:10:ec:00:00:00:6c:25:15:00:28:28:0f:00:00:00:00:00:00:00:00:00:00:11:ed:00:00:00:67:25:1b:00:28:28:af:ff:00:00:00:00:00:00:00:00:00:12:ee:00:00:01:75:25:c4:ff:26:26:0e:00:0c:00:00:00:00:00:00:00:00:13')
    if INIT:
        device_creation(dh1)
        device_creation(dh2)
        device_init(dh1)
        device_init(dh2)
        set_device_config(dh1)
        set_device_config(dh2)
        get_device_config(dh1)
        get_device_config(dh2)
        get_dev_info(dh1)
        get_dev_info(dh2)
    if RANGING:
        session_init(dh1)
        session_init(dh2)
        set_app_config(dh1)
        set_app_config(dh2,
                       device_role=APP_CFG.DEVICE_ROLE.RESPONDER,
                       device_type=APP_CFG.DEVICE_TYPE.CONTROLEE,
                       src_addr=APP_CFG.DST_MAC_ADDRESS_LIST.ANCHOR_ADDR,
                       dst_addr=APP_CFG.SRC_MAC_ADDRESS.MASTER_ADDR)
        get_app_config(dh1)
        get_app_config(dh2)
        rng_start(dh1)
        rng_start(dh2)
        print('waiting')
        time.sleep(30)
        rng_stop(dh1)
        rng_stop(dh2)
        session_de_init(dh1)
        session_de_init(dh2)
    # #####  PER TEST #######
    if PER:
        session_init(dh1, session_id=0x0, session_type=SESSION_TYPE.SESSION_DEVICE_TEST_MODE)
        session_init(dh2, session_id=0x0, session_type=SESSION_TYPE.SESSION_DEVICE_TEST_MODE)
        set_app_config_per(dh1)
        set_app_config_per(dh2, src_addr=APP_CFG.DST_MAC_ADDRESS_LIST.ANCHOR_ADDR,
                           dst_addr=APP_CFG.SRC_MAC_ADDRESS.MASTER_ADDR)
        get_app_config_per(dh1)
        get_app_config_per(dh2)
        periodic_rx(dh2)
        periodic_tx(dh1)

        time.sleep(10)
        session_de_init(dh1, session_id=0x0)
        session_de_init(dh2, session_id=0x0)

        dh1.device.uci_read_ntf(timeout=4)
    # dh1.device.close()
    # dh2.device.close()
