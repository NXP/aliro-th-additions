#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#
import logging
import enum
import time


log = logging.getLogger(__name__)
HDLL_FTR_LEN = HDLL_HDR_LEN = 2


class CRETE_CMDS(enum.Enum):
    HELIOS_RESET = bytes.fromhex('040000')
    GET_MCU_VERSION = bytes.fromhex('060000')
    GET_BOARDID = bytes.fromhex('070000')
    MCU_RESET = bytes.fromhex('090000')
    HDLL_GET_NTF = bytes.fromhex('100000')
    HELIOS2_RESET = bytes.fromhex('110000')
    HDLL_RESET_TO_UCI = bytes.fromhex('120000')


class TYPES(enum.IntEnum):
    BYTES = enum.auto()
    UINTL = enum.auto()
    UINTB = enum.auto()
    SINTL = enum.auto()
    SINTB = enum.auto()
    INT2BL = enum.auto()
    INT2BB = enum.auto()
    STR2B = enum.auto()


class Eenum(enum.IntEnum):
    def __str__(self):
        return "{}({})".format(self._name_, hex(self._value_))

    @classmethod
    def _missing_(cls, value):
        entry = int.__new__(cls)
        entry._name_, entry._value_ = 'ERR_INVALID_ENUM_VAL', value
        return entry


class ENUMS:
    class MT(Eenum):
        CMD = 0x00
        RSP = 0x01
        NTF = 0x02

    class GID(Eenum):
        PROTOCOL = 0x01
        GENERIC = 0x02
        EDL = 0x03
        TESTOS = 0x04

    # OID STARTS
    class PROTOCOL(Eenum):
        HDLL = 0x01
        HCP = 0x02
        EDL = 0x03
        TESTOS = 0x04

    class GENERIC(Eenum):
        RESET = 0x01
        GET_INFO = 0x02

    class EDL(Eenum):
        EDL_DOWNLOAD_CERTIFICATE = 0x01
        EDL_DOWNLOAD_FLASH_WRITE_FIRST = 0x02
        EDL_DOWNLOAD_FLASH_WRITE = 0x03
        EDL_DOWNLOAD_FLASH_WRITE_LAST = 0x04
        EDL_DOWNLOAD_SRAM_WRITE_FIRST = 0x05
        EDL_DOWNLOAD_SRAM_WRITE = 0x06
        EDL_DOWNLOAD_SRAM_WRITE_LAST = 0x07
        EDL_LIFECYCLE_CERTIFICATE = 0x11
        EDL_LIFECYCLE_WRITE_FIRST = 0x12
        EDL_LIFECYCLE_WRITE_LAST = 0x13
        EDL_PATCH_SRAM_WRITE = 0x21
        EDL_PATCH_SRAM_WRITE_LAST = 0x22
        EDL_PATCH_FLASH_WRITE = 0x23

    class TESTOS(Eenum):
        TESTOS_READ = 0x01
        TESTOS_READ_NEXT = 0x02
        TESTOS_WRITE = 0x11
        TESTOS_WRITE_NO_XWORD = 0x12
        TESTOS_WRITE_XWORD = 0x13
        TESTOS_WRITE_NEXT = 0x14
        TESTOS_RAM_PAGE = 0x21
        TESTOS_FLASH_CHECK = 0x22
    # OID ENDS

    class STATUS(Eenum):
        GENERIC_SUCCESS = 0x00
        ACKNOWLEDGE = 0x01
        READY = 0x02
        GENERIC_ERROR = 0x80
        MEMORY_ERROR = 0x81
        TIMEOUT_ERROR = 0x82
        CRC_ERROR = 0x83
        INVALID_ERROR = 0x84
        INVALID_LENGTH_ERROR = 0x90
        INVALID_ADDRESS_ERROR = 0x91
        ECC_SIGNATURE_ERROR = 0x92
        SHA384_HASH_ERROR = 0x93
        LIFECYCLE_VALIDITY_ERROR = 0x94
        CHIP_ID_ERROR = 0x95
        CHIP_VERSION_ERROR = 0x96
        CERTIFICATE_VERSION_ERROR = 0x97
        FIRMWARE_VERSION_ERROR = 0x98
        SRAM_DOWNLOAD_ALLOW_ERROR = 0x99
        KEY_DERIVATION_ERROR = 0xA0
        ENCRYPTED_PAYLOAD_DECRYPTION_ERROR = 0xA1
        INVALID_ENCRYPTED_PAYLOAD_ERROR = 0xA2
        PROTECTED_CACHE_LOAD_ERROR = 0xB0
        PROTECTED_CACHE_DEPLOY_ERROR = 0xB1
        LIFECYCLE_UPDATE_ERROR = 0xB2
        FLASH_BLANK_PAGE_ERROR = 0xC0
        FLASH_CHECK_MARGIN_ERROR = 0xC1

    class ENABLE_DISABLE(Eenum):
        DISABLE = 0
        ENABLE = 1

    class BOOT_STATUS(Eenum):
        OK = 0x00
        WARN = 0x01
        ERR = 0x02
        WARN_ERR = 0x03

    class SESSION_CONTROL(Eenum):
        OPEN = 0X55
        CLOSE = 0XAA

    class SESSION_TYPE(Eenum):
        FLASH_UPDATE = 0x46
        LIFECYCLE_UPDATE = 0x4C
        NONE = 0x00

    class AT_PAGE_STATUS(Eenum):
        N1_N2_PAGE_OK = 0x55
        RECOVERED_N1 = 0x5A
        RECOVERED_N2 = 0xA5
        ERROR = 0xAA

    class DEVICE_LIFECYCLE(Eenum):
        VIRGIN = 0xCCCCCCCC
        DEGRADED = 0x5C5C5C5C
        FLASH_TEST = 0xAAAAAAAA
        DEVELOPMENT = 0xC5C5C5C5
        CUSTOMER = 0xA5A5A5A5
        PROTECTED = 0x55555555
        NXP_RMA = 0x5A5A5A5A

    class NEXT_LIFECYCLE(Eenum):
        VIRGIN = 0xCC
        DEGRADED = 0x5C
        FLASH_TEST = 0xAA
        DEVELOPMENT = 0xC5
        CUSTOMER = 0xA5
        PROTECTED = 0x55
        NXP_RMA = 0x5A

    class LIFECYCLE_VALIDITY(Eenum):
        TRUE = 0x55
        FALSE = 0x00

    LCV_FLASH_TEST = LCV_DEVELOPMENT = LCV_CUSTOMER = LCV_PROTECTED = LCV_NXP_RMA = LCV_DEGRADED = LCV_VIRGIN = \
        ID_CHECK_ENABLE = LIFECYCLE_VALIDITY

    class CHIP_MASK(Eenum):
        TRUE = 0xFFFF
        FALSE = 0x00


class Fields:
    TYPE_CONV = {
        TYPES.BYTES: lambda x: x[0] if len(x) == 1 else x,
        TYPES.UINTL: lambda x: int.from_bytes(x, 'little'),
        TYPES.UINTB: lambda x: int.from_bytes(x, 'big'),
        TYPES.SINTB: lambda x: int.from_bytes(x, 'little', signed=True),
        TYPES.SINTL: lambda x: int.from_bytes(x, 'big', signed=True),
        TYPES.INT2BL: lambda x, size=1: x.to_bytes(size, 'little'),
        TYPES.INT2BB: lambda x, size=1: x.to_bytes(size, 'big'),
        TYPES.STR2B: lambda x: bytes.fromhex(x),
    }

    def __init__(self, pl, **kwargs):
        self.idx = 0
        self.pl = pl
        self.fields = {}
        self.pkt_type = ''
        self.add(**kwargs)

    def add(self, **kwargs):
        for name, val in kwargs.items():
            val = getattr(ENUMS, name.upper(), lambda x: x)(val)
            self.fields[name] = val
        return self

    def get_bytes(self, size=1, otype=TYPES.BYTES, remove=True):
        byte_data = self.pl[self.idx:self.idx+size]
        if remove:
            self.idx += size
        assert len(byte_data) == size, 'Not enough bytes to unpack. pkt: {}, Expected: {}, Actual: {} bytes'.format(self.pl.hex(), size, len(byte_data))
        return Fields.TYPE_CONV[otype](byte_data)

    def __str__(self):
        pkt_str = []
        for name, val in self.fields.items():
            if type(val) == int:
                pkt_str.append('{}: 0x{:x}'.format(name, val))
            elif isinstance(val, (bytes, bytearray)):
                pkt_str.append('{}: 0x{}'.format(name, val.hex()))
            else:
                pkt_str.append('{}: {}'.format(name, val))
        return 'raw: {}\nparsed: {}'.format(self.pl.hex(), ', '.join(pkt_str))


class Hdll:
    def __init__(self, device=None):
        self.dev = device
        self.is_armado = self.dev.__class__.__name__ == 'Armado'
        self.is_crete = self.dev.__class__.__name__ == 'Crete'
        self.hdll_read_args = {'chk_gpio': False} if self.is_armado else {}

    def get_hdll_pkt(self, timeout=1, log_fun=None):
        hdr = self.dev.read(HDLL_HDR_LEN, timeout)
        pl_len = (int.from_bytes(hdr, 'big') & 0x1fff) + HDLL_FTR_LEN
        return self.parse_pkt(hdr + self.dev.read(pl_len, timeout, **self.hdll_read_args), log_fun)

    def pkt_builder(self, gid, oid, chunk=0, mt=ENUMS.MT.CMD, log_fun=None, **pl_args):
        oid_cls = getattr(ENUMS, ENUMS.GID(gid).name)
        pkt_type = '{}_{}'.format(oid_cls(oid).name, ENUMS.MT(mt).name).lower()
        pl = getattr(Hdll, pkt_type)(pl_args)
        pkt = ((chunk << 13) | (2+len(pl))).to_bytes(2, 'big') + bytes([(mt << 6) | gid, oid]) + pl
        return self.parse_pkt(pkt + self.calc_crc(pkt), log_fun)

    @staticmethod
    def parse_pkt(raw, log_fun=None):
        pkt = Fields(raw)
        pkt.add(rfu=pkt.get_bytes(remove=False) & 0xC0, chunk=pkt.get_bytes(remove=False) & 0x20,
                length=pkt.get_bytes(2, TYPES.UINTB) & 0x1FFF, mt=pkt.get_bytes(remove=False) >> 6 & 0x3,
                gid=pkt.get_bytes(remove=False) & 0x3F).add(oid=pkt.get_bytes())
        oid_cls = getattr(ENUMS, pkt.fields['gid'].name)
        pkt.add(oid=oid_cls(pkt.get_bytes()))
        if raw[4:-2]:  # payload exists
            pkt.pkt_type = '{}_{}'.format(pkt.fields['oid'].name, pkt.fields['mt'].name).lower()
            getattr(Hdll, pkt.pkt_type, Hdll.default_payload)(pkt)
        pkt.add(crc=int(pkt.get_bytes(2).hex(), 16))
        if log_fun:
            log_fun(pkt)
        return pkt

    @staticmethod
    def reset_cmd(pkt=None, **pl_args):  # noqa no payload to build/parse
        return b''

    get_info_cmd = reset_cmd

    @staticmethod
    def get_info_rsp(pkt):
        pkt.add(status=ENUMS.STATUS(pkt.get_bytes()))
        if pkt.fields['status'] == ENUMS.STATUS.GENERIC_SUCCESS:
            pkt.add(boot_status=pkt.get_bytes(), session_control=pkt.get_bytes(), session_type=pkt.get_bytes(),
                    rom_version=pkt.get_bytes(), at_page_status=pkt.get_bytes(), padding=pkt.get_bytes(2, TYPES.UINTB),
                    chip_version=pkt.get_bytes(2, TYPES.UINTB), firmware_version=pkt.get_bytes(2, TYPES.UINTB),
                    chip_variant=pkt.get_bytes(4, TYPES.UINTB), device_lifecycle=pkt.get_bytes(4, TYPES.UINTB),
                    die_id=pkt.get_bytes(16), die_id_crc=pkt.get_bytes(4, TYPES.UINTB))

    @staticmethod
    def edl_download_certificate_cmd(pkt=None, **pl_args):
        if pl_args:
            conv, conv2 = Fields.TYPE_CONV[TYPES.INT2BB], Fields.TYPE_CONV[TYPES.STR2B]
            return conv(pl_args["padding"], 2) + conv(pl_args["chip_version"], 2) + bytes([
                pl_args["lcv_flash_test"], pl_args["lcv_development"], pl_args["lcv_customer"], pl_args["lcv_protected"], pl_args["lcv_nxp_rma"],
                pl_args["lcv_degraded"], pl_args["lcv_virgin"], pl_args["padding2"], pl_args["next_lifecycle"], pl_args["id_check_enable"]]) + \
                conv(pl_args['certificate_version'], 2) + conv2(pl_args['ecc_public_key']) + conv2(pl_args['ecc_signature'])
        elif pkt:
            pkt.add(padding=pkt.get_bytes(2, TYPES.UINTB), chip_version=pkt.get_bytes(2, TYPES.UINTB), lcv_flash_test=pkt.get_bytes(),
                    lcv_development=pkt.get_bytes(), lcv_customer=pkt.get_bytes(), lcv_protected=pkt.get_bytes(), lcv_nxp_rma=pkt.get_bytes(),
                    lcv_degraded=pkt.get_bytes(), lcv_virgin=pkt.get_bytes(), padding2=pkt.get_bytes(), next_lifecycle=pkt.get_bytes(),
                    id_check_enable=pkt.get_bytes(), certificate_version=pkt.get_bytes(2, TYPES.UINTB), ecc_public_key=pkt.get_bytes(96), ecc_signature=pkt.get_bytes(96))

    @staticmethod
    def edl_download_flash_write_first_cmd(pkt=None, **pl_args):
        if pl_args:
            conv, conv2 = Fields.TYPE_CONV[TYPES.INT2BB], Fields.TYPE_CONV[TYPES.STR2B]
            return conv(pl_args["firmware_version"], 2) + conv(pl_args["chip_mask"]) + conv2(pl_args['chip_id']) + \
                conv2(pl_args['masked_key']) + conv2(pl_args['udf_seed']) + conv2(pl_args['nonce']) + \
                conv2(pl_args['key_derivation_data']) + conv2(pl_args['hash']) + conv2(pl_args['ecc_signature'])
        elif pkt:
            pkt.add(firmware_version=pkt.get_bytes(2, TYPES.UINTB), chip_mask=pkt.get_bytes(2, TYPES.UINTB), chip_id=pkt.get_bytes(16),
                    masked_key=pkt.get_bytes(16), udf_seed=pkt.get_bytes(16), nonce=pkt.get_bytes(12),
                    key_derivation_data=pkt.get_bytes(32), hash=pkt.get_bytes(48), ecc_signature=pkt.get_bytes(96))

    @staticmethod
    def edl_download_flash_write_cmd(pkt=None, **pl_args):
        if pl_args:
            conv, conv2 = Fields.TYPE_CONV[TYPES.INT2BB], Fields.TYPE_CONV[TYPES.STR2B]
            return conv(pl_args["padding"], 2) + conv(4+len(pl_args["payload"]), 2) + \
                conv(pl_args['magic_number'], 4) + conv(pl_args['address'], 4) + conv2(pl_args['payload']) + \
                conv2(pl_args['hash'])
        elif pkt:
            pkt.add(padding=pkt.get_bytes(2, TYPES.UINTB), length=pkt.get_bytes(2, TYPES.UINTB), magic_number=pkt.get_bytes(4, TYPES.UINTB),
                    address=pkt.get_bytes(4, TYPES.UINTB)).add(payload=pkt.get_bytes(pkt.fields['length']-4), hash=pkt.get_bytes(48))

    @staticmethod
    def edl_download_flash_write_last_cmd(pkt=None, **pl_args):
        if pl_args:
            conv, conv2 = Fields.TYPE_CONV[TYPES.INT2BB], Fields.TYPE_CONV[TYPES.STR2B]
            return conv(pl_args["padding"], 2) + conv(len(pl_args["payload"]), 2) + \
                conv(pl_args['magic_number'], 4) + conv2(pl_args['payload'])
        elif pkt:
            pkt.add(padding=pkt.get_bytes(2, TYPES.UINTB), length=pkt.get_bytes(2, TYPES.UINTB), magic_number=pkt.get_bytes(4, TYPES.UINTB)).add(payload=pkt.get_bytes(pkt.fields['length']))

    @staticmethod
    def generic_status_rsp(pkt):
        pkt.add(status=pkt.get_bytes(), padding=pkt.get_bytes())

    hdll_ntf = edl_ntf = testos_ntf = edl_download_certificate_rsp = edl_download_flash_write_first_rsp = \
        edl_download_flash_write_rsp = edl_download_flash_write_last_rsp = generic_status_rsp

    @staticmethod
    def default_payload(pkt):
        pkt.add(payload=pkt.get_bytes(len(pkt.pl) - 6))

    @staticmethod
    def calc_crc(ip_data):  # 'CRC-16/IBM-3740', 'CRC-16/AUTOSAR', 'CRC-16/CCITT-FALSE'
        poly, crc = 0x1021, 0xffff
        for byte in ip_data:
            crc ^= (byte << 8)
            for _ in range(0, 8):
                crc = (crc << 1) ^ poly if crc & 0x8000 else (crc << 1)
            crc &= 0xFFFF
        crc ^= 0x0000
        return crc.to_bytes(2, 'big')

    def fw_download(self, filename, print_log=False):
        try:
            log_fun = log.log if print_log else log.debug
            log.info('\t[HDLL]\t\tFw download in progress...')
            start_time = time.time()
            fw_data = open(filename, "rb").read()
            img_size = 0 if fw_data is None else len(fw_data)
            assert img_size, "FW file: {} size is 0 or invalid".format(filename)
            log_fun('unprocessed data discarded before fw download: {}'.format(self.dev.read(200).hex()))
            self.dev.powerup()
            self.exec_if_crete(CRETE_CMDS.HDLL_GET_NTF, log_fun)
            boot_rsp = self.get_hdll_pkt(log_fun=log_fun)
            assert boot_rsp.pkt_type in {'hdll_ntf', 'edl_ntf'}, "unexpected response. Expected: hdll/edl_ntf, actual:{}".format(boot_rsp.pkt_type)
            if boot_rsp.pkt_type == 'hdll_ntf':
                assert self.validate_pkt(boot_rsp, 'hdll_ntf', status=ENUMS.STATUS.READY), "unexpected response!!!"
                get_info_cmd = self.pkt_builder(gid=ENUMS.GID.GENERIC, oid=ENUMS.GENERIC.GET_INFO, log_fun=log_fun)
                self.dev.write(get_info_cmd.pl, uci_pkt=False, hbci_pkt=True)
                get_info_rsp = self.get_hdll_pkt(log_fun=log_fun)
                assert self.validate_pkt(get_info_rsp, 'get_info_rsp', status=ENUMS.STATUS.GENERIC_SUCCESS), "unexpected response"
                self.exec_if_crete(CRETE_CMDS.HDLL_GET_NTF, log_fun)
                edl_pkt = self.get_hdll_pkt(log_fun=log_fun)
                assert self.validate_pkt(edl_pkt, 'edl_ntf', status=ENUMS.STATUS.READY), "unexpected response"
            else:
                log_fun("Device is in DEGRADED/VIRGIN lifecycle, booted in EDL mode.")
                assert self.validate_pkt(boot_rsp, 'edl_ntf', status=ENUMS.STATUS.READY), "unexpected response!!!"
            idx, hdr_ftr = 0, HDLL_HDR_LEN + HDLL_FTR_LEN
            while idx < len(fw_data):
                pl_len = int.from_bytes(fw_data[idx:idx + HDLL_HDR_LEN], 'big') & 0x1fff
                pkt = self.parse_pkt(fw_data[idx:idx + pl_len + hdr_ftr], log_fun=log_fun)
                idx += pl_len + hdr_ftr
                self.dev.write(pkt.pl, hbci_qry_pkt=True, uci_pkt=False) if pkt.pkt_type == 'edl_download_flash_write_last_cmd' else self.dev.write(pkt.pl, hbci_pkt=True, uci_pkt=False)
                rsp = self.get_hdll_pkt(log_fun=log_fun)
                self.validate_pkt(rsp, pkt.pkt_type[:-3] + 'rsp', status=ENUMS.STATUS.GENERIC_SUCCESS)
            self.dev.powerup() if self.is_armado else self.exec_if_crete(CRETE_CMDS.HDLL_GET_NTF, log_fun)
            boot_rsp = self.get_hdll_pkt(log_fun=log_fun)
            assert self.validate_pkt(boot_rsp, 'hdll_ntf', status=ENUMS.STATUS.READY), "unexpected response"
            log.info('\t[HDLL]\t\tFw download success. Image Size: {} Time Taken: {} secs'.format(img_size, time.time() - start_time))
            self.dev.uci_enable(True) if self.is_armado else 0
            return True
        except AssertionError as err:
            log.error(err)
            return False

    @staticmethod
    def validate_pkt(pkt, exp_pkt_type, **kwargs):
        if exp_pkt_type != pkt.pkt_type:
            log.error("Unexpected HDLL pkt. Expected {} Actual: {}".format(exp_pkt_type, pkt.pkt_type))
            return False
        for k, v in kwargs.items():
            if pkt.fields.get(k) != v:
                log.error("Field: {} value mismatch. Expected {} Actual: {}".format(k, pkt.fields.get(k), v))
                return False
        return True

    def exec_if_crete(self, cmd, log_fun=log.debug):
        if self.is_crete:
            log_fun(cmd.name + ':' + str(cmd.value.hex()))
            self.dev.write(cmd.value, uci_pkt=False)


if __name__ == '__main__':
    data_bytes = '00f203020109000000000000000000000000000000000000e5be7ff6ee95aa0519a0e3e22d166bc102b475ea1d1843ee7c055940b0440fed0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f0bb936e851be77c9c87afea37cf55bcd80723864c118a63a665715dc01a5f7c35d6decaffb5c30e36275dd540f1050eaa76dd78df9aaee41b56f8dfa0611fe29bb46503739f2eb2c80e6cc789623423c81ac4d09bd378321ad284c8975f5097fe7b765c96bb83219de488f49b12321db5420cbdff570f4fe233c8ddc6260b5130d3de0364825cec819cf99f8c95e89bdced'
    data = bytes.fromhex(data_bytes.replace(':', ''))
    print(Hdll.parse_pkt(data), 'computed_crc: {}'.format(Hdll.calc_crc(data[:-2]).hex()), sep='\n')
