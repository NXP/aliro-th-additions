#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#
import logging
import logging as log
import sys
import threading
import time


from ucitool.base_uci.hbci import Hbci
from ucitool.uwb_devices.uwbdevice import UwbDevice

logger = logging.getLogger()
UCI_PBF_MASK = 0x10  # UCI Packet Boundry Flag Mask
UCI_EXT_PAYLOAD_LEN_MASK = 0x80  # 7th bit of 2 octet in hdr
UCI_EXT_PAYLOAD_LEN_POS = 7

UCI_HEADER_LEN = 3

SOFTWARE_VERSION_TLV_LEN = 4
BOARD_ID_TLV_LEN = 18


def list_winusb_devices():
    try:
        from winusbcdc import WinUsbPy
        winusb_api = WinUsbPy()
        return list(winusb_api.list_usb_devices(deviceinterface=True, present=True).keys())
    except:
        return []


class RhodesWinUsb(UwbDevice):
    def __init__(self, name=None, ser=None):
        super().__init__()
        self.name = name
        self.id = None
        self.ser = None
        self.uci_handler = None
        self.pend_pkt_dict = {}
        # MCU command type
        self.mcu_cmd_type = 0x10
        self.agg_params = [("time_ms", (2, 300)), ("agg_buf_size", (1, 2))]

    def initialize(self, dev_config):
        from winusbcdc import WinUsbPy
        self.devcfg = dev_config
        log.info(sys._getframe().f_code.co_name)
        self.dev_type = dev_config.dev_type
        self.id = dev_config.id
        self._mutex = threading.Lock()
        self._read_mutex = threading.Lock()
        self.hbci = Hbci(self.write, self.read, self.id, self.dev_type)
        self.uci_supported = dev_config.uci_support
        self.variant = dev_config.variant
        self.use_usb = 1
        self.winusb_api = WinUsbPy()
        # self.winusb_api.usb_device_guid = GUID(0x6beb3222, 0x28e5, 0x4a09,  #
        #                                        (c_byte * 8)(0xb7, 0xc0, 0x97, 0x99, 0x32, 0x66, 0x89, 0x9f))
        # # read: device to host
        self.bulk_in = 0x82
        # write: host to device
        self.bulk_out = 0x03
        self.bulk_in_timeout_secs = 2
        self.winusb_read_init(self.bulk_in)
        # queue all the partially received packets, dictionary is indexed by gid_oid of the notification

    # get the key
    def get_pend_pkt_dict_key(self, hdr):
        # gid << 8  | oid
        dict_key = ((hdr[0] & 0x0F) << 8) | (hdr[1] & 0x3F)
        return dict_key

    def uci_read(self, poll=True, timeout=5):
        uci_payload = bytearray()
        while True:
            # logger.info('attempt read {}'.format(time.time()))
            uci_hdr = self.poll_read(4)
            if not uci_hdr:
                return []
            if len(uci_hdr) == 0 or len(uci_hdr) != 4:
                log.error("Incorrect UCI HDR Size: %d", len(uci_hdr))
                return []
            if uci_hdr[0] == 0x00 and uci_hdr[1] == 0x00 and uci_hdr[2] == 0x00 and uci_hdr[3] == 0x00:
                log.error('spurious interrupt, handle this')
                return []
            if (uci_hdr[1] & UCI_EXT_PAYLOAD_LEN_MASK) >> UCI_EXT_PAYLOAD_LEN_POS:
                length = uci_hdr[3] << 8 | uci_hdr[2]
            else:
                length = uci_hdr[3]
            log.debug("uci_hdr : %02x%02x%02x%02x : len: %8d", uci_hdr[0], uci_hdr[1], uci_hdr[2], uci_hdr[3], length)
            # check, if we have received a partial packet for this type earlier, if not, create an empty payload array
            dict_key = self.get_pend_pkt_dict_key(uci_hdr)
            uci_payload = self.pend_pkt_dict.pop(dict_key, bytearray())

            chunk = self.read(length, timeout=5)
            if chunk is None or len(chunk) == 0:
                log.debug('CHUNK is None')
                break
            if len(chunk) != length:
                log.error('@@partial chunk is received...... not handled properly')
            uci_payload.extend(chunk)
            if not uci_hdr[0] & UCI_PBF_MASK:
                break
            else:
                # store the packet in the dict
                self.pend_pkt_dict[dict_key] = uci_payload
        return [uci_hdr + uci_payload]

    def set_uci_handler(self, uci_hnd):
        self.uci_handler = uci_hnd

    # @calculate_time # uncomment to measure uci cmd-rsp latency. benchmark results: 10-20ms
    def uci_cmd_rsp(self, uci_cmd, timeout=2):
        return self.uci_handler.uci_cmd_rsp(uci_cmd, timeout)

    def uci_read_msg(self):
        return self.uci_handler.uci_read_msg()

    def get_winusb_dev_name(self, dev_dict, idx=0):
        name = None
        for i, key in enumerate(dev_dict):
            if (i == idx):
                name = key
                break
        return name

    def open(self):
        open_res = False
        result = self.winusb_api.list_usb_devices(deviceinterface=True, present=True)
        pl2303_vid = 0x1FC9
        pl2303_pid = 0x94
        if result:
            if self.winusb_api.init_winusb_device(self.name, pl2303_vid, pl2303_pid):
                interface_descriptor = self.winusb_api.query_interface_settings(0)
                pipe_info_list = map(self.winusb_api.query_pipe, range(interface_descriptor.b_num_endpoints))
                self.flush_port()
                # set the read timeout for the bulk-in
                self.winusb_api.set_timeout(self.bulk_in, self.bulk_in_timeout_secs)
                open_res = True
        self.uci_handler.set_device(self)
        self.uci_handler.start()
        return open_res

    def flush_port(self):
        with self._mutex:
            self.flush_port_unlock()

    def flush_port_unlock(self):
        self.winusb_api.flush(self.bulk_out)
        self.winusb_api.flush(self.bulk_in)

    def close(self):
        log.info(sys._getframe().f_code.co_name)
        log.debug("waiting for the uci handler to close")
        if self.uci_handler.is_alive():
            self.uci_handler.join()
            log.debug("uci handler is closed")
        self.winusb_api.close_winusb_device()

    def uci_read_rsp_clear(self):
        return self.uci_handler.uci_read_rsp_clear()

    def uci_read_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_log_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_read_ntf(self, timeout=1):
        return self.uci_handler.uci_read_ntf(timeoutInSec=timeout)

    def uci_log_ntf(self):
        return self.uci_handler.uci_log_ntf()

    def uci_read_rsp(self):
        return self.uci_handler.uci_read_rsp()

    def fw_download(self, filename, print_log=False, skip_powerup=False):
        self.uci_handler.fw_download(filename, print_log, skip_powerup)

    def winusb_read_init(self, ep):
        self.read_ready_ep = ep
        self.read_size = 64000  # max size rhodes can pump
        self.read_ready_buf = bytearray(self.read_size)
        self.read_ready_idx = 0
        self.read_ready_valid_size = 0

    def winusb_read_ready_available_bytes(self, _ep):
        return self.read_ready_valid_size - self.read_ready_idx

    # read the available bytes. assumed all the checks are done before calling this function
    def winusb_read_buf(self, ep, read_len):
        read_buf = self.read_ready_buf[self.read_ready_idx: self.read_ready_idx + read_len]
        # update the index
        self.read_ready_idx = self.read_ready_idx + read_len
        return read_buf

    def b2i(self, b):
        return int.from_bytes(b, byteorder='little', signed=False)

    # fill buffer
    def winusb_read_fillbuf(self, ep):
        ret_val = True
        # we attempt to read max size of bytes
        buf = self.winusb_api.read(ep, self.read_size)
        if buf is not None:
            try:
                buf_bytes = bytearray(buf.raw)
            except AttributeError:
                buf_bytes = bytearray(buf)
            self.read_ready_valid_size = len(buf_bytes)
            # if (self.read_ready_valid_size > 10000):
            #    log.info("this is unexpected....catch it")
            self.read_ready_idx = 0
            self.read_ready_buf[0:len(buf_bytes)] = buf_bytes
            log.debug("new buffer from the device, number of bytes %d", self.read_ready_valid_size)
            # dump bytes
            tb = self.read_ready_buf
            log.debug("first 5 bytes: %02x%02x%02x%02x%02x", tb[0], tb[1], tb[2], tb[3], tb[4])
        else:
            log.error("error in reading from the pipe")
            ret_val = False
        return ret_val

    def winusb_read(self, ep, read_len):
        read_len_orig = read_len
        ready_bytes = self.winusb_read_ready_available_bytes(ep)
        # if we have enough bytes, return bytes immediately.
        log.info("request for read: %d ready_bytes: %d", read_len, ready_bytes)
        if ready_bytes >= read_len:
            return self.winusb_read_buf(ep, read_len)
        # read the pending bytes
        read_buf = bytearray(read_len)
        cur_byte_idx = 0
        while True:
            # if we have any ready bytes, copy them
            if ready_bytes:
                copy_bytes = min(read_len, ready_bytes)
                read_buf[cur_byte_idx:cur_byte_idx + copy_bytes] = self.winusb_read_buf(ep, copy_bytes)
                # pending bytes
                read_len = read_len - copy_bytes
                cur_byte_idx = cur_byte_idx + copy_bytes
            if (read_len != 0):
                # fill the buffer
                log.info("issuing a read to winusb, still need %d bytes to fullfill the request", read_len)
                if self.winusb_read_fillbuf(ep):
                    ready_bytes = self.winusb_read_ready_available_bytes(ep)
                else:
                    break
            else:
                break
        # fill the remaining bytes
        # read_buf[ready_bytes:ready_bytes+read_len] = self.winusb_read_buf(ep, read_len)
        # log.info("requested for %d bytes, returned %d", read_len_orig, ready_bytes+read_len)
        if read_len != 0:
            log.error("error: requested for %d bytes, but could could read only %d", read_len_orig,
                      read_len_orig - read_len)
            return None
        else:
            log.info("requested for %d bytes, returned %d", read_len_orig, read_len_orig - read_len)
            return read_buf

    def read(self, rlen=1, timeout=5):
        # handling the exception in the main caller, that is uci_handler (uci_read) so that function
        # prototype is not changed
        with self._read_mutex:
            return self.winusb_read(self.bulk_in, rlen)

    def poll_read(self, rlen=1, timeout=5):
        log.debug("trying to acquire the mutex in poll_read")
        # handling the exception in the main caller, that is uci_handler (uci_read) so that function
        # prototype is not changed
        with self._read_mutex:
            # TBD: is there a way to check the number of pending bytes: I don't think so
            payload = self.winusb_read(self.bulk_in, rlen)
            return payload

    def powerup(self):
        log.info(sys._getframe().f_code.co_name)
        write_buf = bytearray()
        write_buf.extend([0x04, 0x00, 0x00])
        read_rsp = bytearray()
        read_rsp.extend([0x01, 0x02, 0x03, 0x04])
        with self._mutex:
            self.flush_port_unlock()
            log.debug('PowerUp TX:' + str(write_buf.hex()))
            self.winusb_api.write(self.bulk_out, bytes(write_buf))
            time.sleep(0.05)
            rx = self.winusb_read(self.bulk_in, 4)
            log.debug('PowerUp RX1:' + str(rx.hex()))
            while rx != read_rsp:
                # there may be a notifications generated by the firmware pending to be read
                # just keep reading data till we find our magic sequence
                rx_1 = self.winusb_read(self.bulk_in, 1)
                rx[0:3] = rx[1:4]
                rx[3] = rx_1[0]
                log.info('PowerUp RX2:' + str(rx.hex()))
            log.debug('PowerUp RX3:' + str(rx.hex()))

    def reset(self):
        log.info(sys._getframe().f_code.co_name)
        write_buf = bytearray()
        write_buf.extend([0x06, 0x00, 0x00])
        read_rsp = bytearray()
        with self._mutex:  # looks good
            if (self.use_usb == 0):
                self.ser.reset_output_buffer()
                self.ser.reset_input_buffer()
                log.error('Issue Rhodes MCU Reset')
                self.ser.write(write_buf)
                # let the device unload
                time.sleep(1)
            else:
                self.flush_port_unlock()
                log.error('Issue Rhodes MCU Reset')
                self.winusb_api.write(self.bulk_out, bytes(write_buf))
        # close outside of _mutex, otherwise it can/will create a deadlock with uci_handler (run function)
        self.close()

    def get_software_version(self):
        log.info(sys._getframe().f_code.co_name)
        write_buf = bytearray()
        write_buf.extend([0x06, 0x00, 0x00])
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            log.debug('softwareVersion Tlv:' + str(write_buf.hex()))
            self.ser.write(write_buf)
            time.sleep(0.05)
            rx = self.ser.read(SOFTWARE_VERSION_TLV_LEN)
            if rx and len(rx) > 2:
                rx = rx[2:].hex()  # strip off header
                log.debug('softwareVersion:' + str(rx))
            return rx

    def get_board_id(self):
        log.info(sys._getframe().f_code.co_name)
        write_buf = bytearray()
        write_buf.extend([0x07, 0x00, 0x00])
        with self._mutex:
            self.ser.reset_output_buffer()
            self.ser.reset_input_buffer()
            log.debug('boardID Tlv:' + str(write_buf.hex()))
            self.ser.write(write_buf)
            time.sleep(0.05)
            rx = self.ser.read(BOARD_ID_TLV_LEN)
            if rx and len(rx) > 2:
                rx = rx[2:].hex()  # strip off header
                log.debug('boardID:' + str(rx))
            return rx

    def write(self, data, uci_pkt=True, hbci_pkt=False, hbci_qry_pkt=False):
        with self._mutex:
            try:
                write_buf = bytearray()
                if uci_pkt:
                    write_buf.extend([0x01])
                elif hbci_pkt:
                    write_buf.extend([0x02])
                elif hbci_qry_pkt:
                    write_buf.extend([0x03])
                write_buf.extend(len(data).to_bytes(2, 'big'))
                write_buf.extend(data)
                if (self.use_usb == 0):
                    self.ser.write(write_buf)
                else:
                    self.winusb_api.write(self.bulk_out, bytes(write_buf))
            except:
                log.error('Write Failed')

    def flash_write(self, offset, data):
        """
        Rhodes API to write flash area. offset=0 is first offset of last sector.
        Last sector in MCU is reserved for users.
        @offset: offset to read from
        @data:data to be written.
        """
        cmd = bytearray([0x07])  # cmd + len(offset+ nwords)
        cmd.extend((len(data) + 2).to_bytes(2, byteorder='big'))
        cmd.extend(offset.to_bytes(2, byteorder='little'))
        cmd.extend(data)
        log.info('Flash write- offset-{} len-{} data-{}'.format(offset, len(data), data))
        with self._mutex:
            if (self.use_usb == 0):
                self.ser.reset_output_buffer()
                self.ser.reset_input_buffer()
                # temp fix
                log.info('[' + self.id + ']' + 'Flash write:' + str(cmd.hex()))
                self.ser.write(cmd)
                # time.sleep(0.1)
                out = self.ser.read(10)
            else:
                self.flush_port_unlock()
                self.winusb_api.write(self.bulk_out, bytes(cmd))
                # time.sleep(0.1)
                out = self.winusb_read(self.bulk_in, 10)
            if out:
                return int.from_bytes(out, byteorder='big') == 0
        log.error('Error writing flash')

    def flash_read(self, offset=0, nwords=1):
        """
        Rhodes API to read flash area. offset=0 is first offset of last sector.
        Last sector in MCU is reserved for users.
        @offset: offset to read from
        @nwords: number of 32bit words to read
        """
        cmd = bytearray([0x06, 0x0, 0x04])  # cmd + len(offset+ nwords)
        cmd.extend(offset.to_bytes(2, byteorder='little'))
        cmd.extend(nwords.to_bytes(2, byteorder='little'))
        read_len = 4 * (nwords + 1)  # 32bit addressable + status byte(4 bytes)
        log.info('Flash read- offset-{} nwords-{}'.format(offset, nwords))
        with self._mutex:
            if (self.use_usb == 0):
                self.ser.reset_output_buffer()
                self.ser.reset_input_buffer()
                # temp fix
                log.info('[' + self.id + ']' + 'Flash read:' + str(cmd.hex()))
                self.ser.write(cmd)
                # time.sleep(0.1)
                out = self.ser.read(read_len)
            else:
                self.flush_port_unlock()
                self.winusb_api.write(self.bulk_out, bytes(cmd))
                # time.sleep(0.1)
                out = self.winusb_read(self.bulk_in, read_len)
            if out and int.from_bytes(bytes=out[0:4], byteorder='little') != 0x0:
                log.error('Flash read failed')
                return
            if len(out) < read_len:
                log.error('Error read, not enough data is read')
                return

            out = out[4:]
            logger.info([out[i:i + 4].hex() for i in range(0, len(out), 4)])
            return [out[i:i + 4] for i in range(0, len(out), 4)]

    # mcu specific commands
    def mcu_cmd_hdr_size(self):
        # 1 byte for the type, 2 bytes for the length
        return 1 + 2

    # calculate the size of the MCU parameters
    def mcu_cmd_param_size(self, params):
        size = 0
        # sum the size of each parameter
        for _idx, pval in enumerate(params):
            size = size + pval[1][0]
        return size

    # prepare the command buffer
    def mcu_prepare_cmd(self, params):
        params_size = self.mcu_cmd_param_size(params)
        # create and fill the buffer
        cmd_buf = bytearray(self.mcu_cmd_hdr_size() + params_size)
        # write the type
        cur_idx = 0
        field_len = 1
        cmd_buf[cur_idx:cur_idx + field_len] = self.mcu_cmd_type.to_bytes(length=field_len, byteorder='big')
        cur_idx = cur_idx + field_len
        # write the length of the parameters
        field_len = 2
        cmd_buf[cur_idx:cur_idx + field_len] = params_size.to_bytes(length=field_len, byteorder='big')
        cur_idx = cur_idx + field_len
        if params:
            # write parameters
            for _idx, pval in enumerate(params):
                # length of the field
                field_len = pval[1][0]
                if (field_len <= 4):
                    cmd_buf[cur_idx:cur_idx + field_len] = pval[1][1].to_bytes(length=field_len, byteorder='big')
                else:
                    cmd_buf[cur_idx:cur_idx + field_len] = pval[1][1]
                cur_idx = cur_idx + field_len
        return cmd_buf

    def write_mcu_cmd(self, cmd_buf):
        with self._mutex:  # looks good
            if (self.use_usb == 0):
                self.ser.write(cmd_buf)
            else:
                self.winusb_api.write(self.bulk_out, bytes(cmd_buf))

    def enable_aggregation(self, params=None):
        # command format
        # TYPE: self.mcu_cmd_type (0x10)
        # VALUE: [1 byte: sub_type, 2 bytes: time_ms, 1 byte agg_buf_size]
        cmd_subtype = [("cmd_subtype", (0x1, 0x1))]
        if not params:
            # each parameter is of (size_bytes, val)
            params = self.agg_params
        else:
            # remember the current aggregate params
            self.agg_params = params
        params = cmd_subtype + params

        # create and fill the buffer
        cmd_buf = self.mcu_prepare_cmd(params)
        # write the mcu command
        self.write_mcu_cmd(cmd_buf)

    def disable_aggregation(self):
        params = [("cmd_subtype", (1, 0x02))]
        # create and fill the buffer
        cmd_buf = self.mcu_prepare_cmd(params)
        # write the mcu command
        self.write_mcu_cmd(cmd_buf)
