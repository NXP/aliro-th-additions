#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import logging
import queue
import threading
import time

from ucitool.uwb_devices.uwbdevice import UwbDevice
from ucitool.base_uci.hdll import Hdll, ENUMS
from python_lpc_for_uwb import (H2V2_LPC_PINS as LPC, H2V2_IOEXPANDER as EXP, Helios, GPIO_MODE,
                                GPIO_EXTENDER_MODE, SPI)


log = logging.getLogger(__name__)

UCI_HEADER_LEN = 4
HDLL_FTR_LEN = HDLL_HDR_LEN = 2
UCI_PBF_MASK = 0x10  # UCI Packet Boundry Flag Mask


class Armado(UwbDevice):
    boot_modes = {'normal': [0, 1, 1, 1],
                  'application': [1, 0, 0, 1],
                  'download': [1, 0, 1, 0],
                  'testos_hif': [1, 0, 1, 1],
                  'testos_jtag2ahb_val': [1, 1, 0, 0],
                  'testos_jtag2ahb_htol': [1, 1, 0, 1],
                  'ate_wt1_jtag2ahb': [1, 1, 1, 1]}

    def __init__(self):
        super().__init__()
        self.__name = None
        self.id = None
        self._device = None
        self._data_queue = queue.Queue()
        self.uci_ready_mode = True
        self.dev_type = None
        self.interface_type = None
        self.com_port = None
        self.gpio_event = None
        self.ip_addr = None
        self.port = None
        self.hbci = None
        self.spi_h_cfg = {'spi': SPI.SPI_H, 'datarate': 10500000, 'mode': 0, 'ss_pol': 0, 'bit_order': 0}

    def initialize(self, dev_config):
        self.devcfg = dev_config
        self.dev_type = dev_config.dev_type
        self._mutex = threading.Lock()
        self.gpio_event = threading.BoundedSemaphore()
        self.id = dev_config.id
        self.interface_type = dev_config.interface_config.type
        self.com_port = dev_config.interface_config.com_port
        self.ip_addr = dev_config.interface_config.ip_addr
        self.port = dev_config.interface_config.port
        self.hbci = Hdll(self)  # Actually HDLL for H2 but named as hbci to retain fw-download functionality from uci handler
        self.uci_supported = dev_config.uci_support

    def flush_queue(self):
        while not self._data_queue.empty():
            self._data_queue.get()

    def set_uci_handler(self, uci_hnd):
        self.uci_handler = uci_hnd

    def uci_cmd_rsp(self, uci_cmd, timeout=5):
        return self.uci_handler.uci_cmd_rsp(uci_cmd, timeout)

    def uci_read_rsp_clear(self):
        return self.uci_handler.uci_read_rsp_clear()

    def uci_read_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_read_ntf(self, timeout=3):
        return self.uci_handler.uci_read_ntf(timeoutInSec=timeout)

    def cir_ntf_clear(self):
        return self.uci_handler.cir_ntf_clear()

    def read_cir_ntf(self):
        return self.uci_handler.read_cir_ntf()

    def uci_log_ntf(self):
        return self.uci_handler.uci_log_ntf()

    def read_dl_ntf(self):
        return self.uci_handler.read_dl_ntf()

    def read_psdu_ntf(self):
        return self.uci_handler.read_psdu_ntf()

    def uci_read_rsp(self):
        return self.uci_handler.uci_read_rsp()

    def uci_log_ntf_clear(self):
        return self.uci_handler.uci_log_ntf_clear()

    def fw_download(self, filename, print_log=False, skip_powerup=False):  # noqa
        not self.uci_ready_mode and self.uci_handler.fw_download(filename, print_log, skip_power_up=True)

    def enable_jtag2ahb(self, print_log=False):
        self.uci_handler.enable_jtag2ahb(print_log)

    def open(self):
        if self.com_port:
            self._device = Helios(self.com_port)
        else:
            if self.port is not None:
                self._device = Helios(tgt_addr=self.ip_addr, local_port=self.port)
            else:
                self._device = Helios(tgt_addr=self.ip_addr)
        self.spi_config()
        self.gpio_config()
        self.set_boot_strap_pins()
        self.uci_handler.set_device(self)
        try:
            self.gpio_event.acquire(blocking=False)
        except ValueError:
            pass
        self.powerup()
        self.verify_normal_boot()
        self.uci_ready_mode = False
        self.uci_enable(True)
        self.uci_handler.start()

    def verify_normal_boot(self):
        hdll_pkt = self.hbci.get_hdll_pkt(log_fun=log.info)
        if not self.hbci.validate_pkt(hdll_pkt, 'hdll_ntf', status=ENUMS.STATUS.READY):
            log.warning('Expected normal boot mode response')

    @staticmethod
    def flush_port(self):  # noqa
        log.info("Dummy function. Use Flush from XSLIP!")

    def close(self):
        # if self.uci_handler.is_alive():
        #    self.uci_handler.join()
        if self._device:
            self._device.close()
        self._device = None

    def uci_cb_handler(self, data, helios_obj):  # noqa
        self._data_queue.put(data['data'])

    def uci_read(self, poll=False, timeout=5):
        while True:
            try:
                uci_data = self._data_queue.get(timeout=1)
                uci_hdr = uci_data[0:4]  # UCI header
                dict_key = self.get_pend_pkt_dict_key(uci_hdr)  # check if partial pkt received earlier
                uci_pend_pl = self.pend_pkt_dict.pop(dict_key, bytearray())
                uci_pend_pl.extend(uci_data[4:])
                if uci_hdr[0] & UCI_PBF_MASK:  # check for partial pkt
                    self.pend_pkt_dict[dict_key] = uci_pend_pl
                else:
                    return [uci_hdr + uci_pend_pl]
            except:  # noqa
                return None

    def read(self, rlen=None, timeout=2, chk_gpio=True):
        if chk_gpio and not self.gpio_event.acquire(timeout=timeout) or rlen is None or rlen <= 0:
            return b''
        with self._mutex:
            buf = self._device.spi_transmit_read_master(self.spi_h_cfg["spi"], b'\xff' + bytes(rlen), timeout=timeout)
            # log.debug("from read: {}, req_rlen: {}".format(buf[0]["data"][1:].hex(), rlen))
            return buf[0]["data"][1:] if buf else b''

    def write(self, data, uci_pkt=False, hbci_pkt=False, hbci_qry_pkt=False, hbci_custom_pkt=False, length=4):
        with self._mutex:
            return self._device.spi_transmit_read_master(self.spi_h_cfg["spi"], b'\x00' + data)

    def gpio_config(self):
        self._device.gpio_host_int_irq_notification_callback_add(self.gpio_cb)
        self._device.gpio_host_int_irq_enable(enable=True)

    def spi_config(self):
        self._device.gpio_extender_set_mode_value_single(EXP.RB3_H_SPI_OE, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)
        self._device.gpio_extender_set_mode_value_single(EXP.LPC_H_SPI_OE, mode=GPIO_EXTENDER_MODE.OUTPUT, value=1)
        self._device.gpio_extender_set_mode_value_single(EXP.LPC_H_SPI_A_EN_N, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)
        self._device.gpio_extender_set_mode_value_single(EXP.LPC_GPIO6_7_H_SEL, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)
        self._device.gpio_extender_set_mode_value_single(EXP.LPC_H_SPI_B_EN_N, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)
        self._device.gpio_extender_set_mode_value_single(EXP.LPC_H_I2C_I3C_SEL, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)
        self._device.gpio_extender_set_mode_value_single(EXP.H_I2C_I3C_EN_N, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)
        self._device.gpio_extender_set_mode_value_single(EXP.SEL_H_I3C, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)
        self._device.spi_config_set(**self.spi_h_cfg)
        self._device.uci_set_callback(self.uci_cb_handler)

    def gpio_cb(self, data, helios_obj):  # noqa
        try:
            self.gpio_event.release()
        except:  # noqa
            log.warning("IRQ received before processing the previous IRQ")

    def uci_enable(self, enable=True):
        if enable:
            self._device.uci_enable()
        else:
            self._device.uci_disable()
            time.sleep(0.5)
            self.flush_queue()

    def reset_armado(self, timeout=5):
        self._device.reset()
        time.sleep(timeout)

    def powerup(self):
        self.uci_enable(False)
        self._device.gpio_generic_set_mode_value_single(LPC.LPC_H2_RSTN, GPIO_MODE.OUTPUT_PUSH_PULL, 0)
        time.sleep(0.05)
        self._device.gpio_generic_set_mode_value_single(LPC.LPC_H2_RSTN, GPIO_MODE.OUTPUT_PUSH_PULL, 1)

    def set_boot_strap_pins(self, boot_mode='normal'):
        if boot_mode not in Armado.boot_modes:
            msg = "Invalid boot_mod" + boot_mode + ". Valid boot modes: " + str(Armado.boot_modes.values())
            log.error(msg)
            raise Exception(msg)

        self._device.gpio_generic_set_mode_value_single(LPC.EN_LS_1V8_VDDIO, GPIO_MODE.OUTPUT_PUSH_PULL, value=1)
        # mux config to enable TM, EF1, EF2, QSPI_CS pins. Implement RSTN pin if required
        self._device.gpio_generic_set_mode_value_single(LPC.LPC_TM_DIR, GPIO_MODE.OUTPUT_PUSH_PULL, 1)  # TM
        self._device.gpio_extender_set_mode_value_single(EXP.EF1_EN, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)  # EF1
        self._device.gpio_extender_set_mode_value_single(EXP.EF1_SEL0, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)  # EF1
        self._device.gpio_extender_set_mode_value_single(EXP.EF1_SEL1, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)  # EF1
        self._device.gpio_extender_set_mode_value_single(EXP.EF2_EN, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)  # EF2
        self._device.gpio_extender_set_mode_value_single(EXP.EF2_SEL0, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)  # EF2
        self._device.gpio_extender_set_mode_value_single(EXP.EF2_SEL1, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)  # EF2
        self._device.gpio_extender_set_mode_value_single(EXP.LS_LPC_ALT_QSPI_CS_DIR_N, mode=GPIO_EXTENDER_MODE.OUTPUT, value=0)  # QSPI_CS
        self._device.gpio_extender_set_mode_value_single(EXP.GPIO9_TDI1_EN_N, mode=GPIO_EXTENDER_MODE.OUTPUT, value=1)  # QSPI_CS
        self._device.gpio_extender_set_mode_value_single(EXP.SEL_GPIO9, mode=GPIO_EXTENDER_MODE.OUTPUT, value=1)  # QSPI_CS

        # set boot strap pins to desired value
        pin_vals = Armado.boot_modes[boot_mode]
        self._device.gpio_generic_set_mode_value_single(LPC.LPC_TM, GPIO_MODE.OUTPUT_PUSH_PULL, pin_vals[0])
        self._device.gpio_generic_set_mode_value_single(LPC.LPC_EF1, GPIO_MODE.OUTPUT_PUSH_PULL, pin_vals[1])
        self._device.gpio_generic_set_mode_value_single(LPC.LPC_EF2, GPIO_MODE.OUTPUT_PUSH_PULL, pin_vals[2])
        self._device.gpio_generic_set_mode_value_single(LPC.LPC_ALT_QSPI_CS, GPIO_MODE.OUTPUT_PUSH_PULL, pin_vals[3])
