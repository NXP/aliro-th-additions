#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import logging as log
import os

import serial

from ucitool.uwb_devices.ser2net_wrapper import Ser2Net
from ucitool.uwb_devices.uwbdevice import UwbDevice


class FiraVcom(UwbDevice):
    def __init__(self):
        super().__init__()
        self.ser = None
        self.uci_handler = None
        self.uci_ready_mode = True
        self.com_port = None

    def initialize(self, dev_config):
        super().initialize(dev_config)
        if self.ip:
            self.ser = Ser2Net(self.ip, self.port)
        else:
            self.ser = serial.Serial(**self.ser_props)
            self.ser.port = self.com_port
            if os.name != 'nt':  # for linux: to prevent multiple opens on the same com port, set 'exclusive' parameter
                self.ser.exclusive = True
            self.uci_ready_mode = True
        self.ser.timeout = 0.2

    def open(self):
        if self.ser.isOpen():
            return True
        self.ser.open()
        self.uci_handler.set_device(self)
        self.uci_handler.start()
        return self.ser.isOpen()

    def flush_port(self):
        with self._mutex:
            log.debug("Flushing port..")
            self.ser.reset_input_buffer()
            self.ser.reset_output_buffer()

    def close(self):
        log.debug("waiting for the uci handler to close")
        self.uci_handler.is_alive() and self.uci_handler.join()
        log.debug("uci handler is closed")
        self.ser.isOpen() and self.ser.close()

    def uci_read_rsp(self):
        return self.uci_handler.uci_read_rsp()

    def read(self, rlen=1, timeout=5):
        # handling the exception in the main caller, that is uci_handler (uci_read) so that function
        # prototype is not changed
        with self._mutex:
            return self.ser.read(rlen)

    def poll_read(self, rlen=None, timeout=5):
        # len param to this method is ignored, from typical flow of read hdr-> check length-> read length
        # we change to, read whatever there in serial buffer, to make host acknowledge UWBS ASAP that we have read
        # whatever UWBS sent, so that UWBS NTF q wil get freed early.
        # after read full buffer which may have multiple UCIs, de-fragment it into list of UCIs and wait for next read.
        packet = list()
        with self._mutex:
            if self.ser.in_waiting >= 1: # Read 1 byte to check if it is a UWB packet
                indicator_byte = self.ser.read(1)
                if (indicator_byte == b'\xff'):
                    # UWB packet
                    # Continue reading
                    packet = list(self.ser.read(4)) # Read header bytes
                    packet_length = (packet[2] << 8) | packet[3]
                    payload = list(self.ser.read(packet_length))
                    packet.extend(list(payload))
                    return bytes(packet)
                else:
                    # UWB packet not found
                    # This could be an FSCI packet
                    packet.append(indicator_byte) # Add the first byte as it was a part of the header
                    header = list(self.ser.read(4)) # Read 4 more bytes to get the complete header
                    packet.extend(header)
                    packet_length = (header[3] << 8) | header[2]
                    if packet_length > 0:
                        payload = list(self.ser.read(packet_length))
                        packet.extend(payload)
                    checksum = list(self.ser.read(1))
                    packet.extend(checksum)
                    print(packet)
                    self.uci_handler.fsci_put_packet(packet)
                    return None

        # with self._mutex:
        #     if self.ser.in_waiting >= 4:  # min header len
        #         return self.ser.read(self.ser.in_waiting)

    def write(self, data):
        with self._mutex:
            try:
                return self.ser.write(data)
            except:
                log.error('Write Failed')
