#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import logging
import socket
import sys
import threading
import time

from ucitool.uwb_devices.uwbdevice import UwbDevice

log = logging.getLogger()
UCI_PBF_MASK = 0x10  # UCI Packet Boundry Flag Mask
UCI_LENGTH_MASK = 0xC0  # UCI 2K length Mask
UCI_2K_LENGTH_SIZE = 2048  # UCI 2K length size
UCI_1K_LENGTH_SIZE = 1024  # UCI 2K length size
UCI_512b_LENGTH_SIZE = 2048  # UCI 2K length size

UCI_HEADER_LEN = 3
SIM_PORT = 27015


class HeliosSimX86(UwbDevice):
    def __init__(self):
        super().__init__()
        self.__name = None
        self.id = None
        self.soc = socket.socket()
        self.uci_handler = None
        self.connected = False

    def initialize(self, dev_config):
        self.devcfg = dev_config
        log.info(sys._getframe().f_code.co_name)
        self.dev_type = dev_config.dev_type
        self.id = dev_config.id
        self._mutex = threading.Lock()
        self.interface_type = dev_config.interface_config.type
        self.host = dev_config.interface_config.ip_addr
        self.port = 27015
        self.soc.settimeout(0.01)
        self.uci_supported = dev_config.uci_support
        self.variant = dev_config.variant

    def open(self):
        log.info(sys._getframe().f_code.co_name)
        if self.connected:
            return True
        try:
            self.soc.connect((self.host, self.port))
            self.connected = True

        except socket.timeout:
            self.connected = False
        self.uci_handler.set_device(self)
        time.sleep(0.5)
        self.uci_handler.start()
        return self.connected

    def uci_read(self, poll=True, timeout=5):
        uci_payload = bytearray()
        while True:
            # log.info('attempt read {}'.format(time.time()))
            uci_hdr = self.read(4)
            if not uci_hdr:
                return
            if len(uci_hdr) == 0 or len(uci_hdr) != 4:
                log.debug("Incorrect UCI HDR Size:" + str(len(uci_hdr)))
                return
            if uci_hdr[0] == 0x00 and uci_hdr[1] == 0x00 and uci_hdr[2] == 0x00 and uci_hdr[3] == 0x00:
                log.warning('spurios interrupt, handle this')
                return
            length = uci_hdr[3]
            if ((uci_hdr[1] & UCI_LENGTH_MASK) >> 6) == 3:
                chunk = self.read(UCI_2K_LENGTH_SIZE, timeout=5)
            elif ((uci_hdr[1] & UCI_LENGTH_MASK) >> 6) == 2:
                chunk = self.read(UCI_1K_LENGTH_SIZE, timeout=5)
            elif ((uci_hdr[1] & UCI_LENGTH_MASK) >> 6) == 1:
                chunk = self.read(UCI_512b_LENGTH_SIZE, timeout=5)
            else:
                chunk = self.read(length, timeout=5)
            if chunk is None or len(chunk) == 0:
                log.debug('CHUNK is None')
                break
            uci_payload.extend(chunk)
            if not uci_hdr[0] & UCI_PBF_MASK:
                break
        return uci_hdr + uci_payload

    def read(self, rlen=1, timeout=5):
        with self._mutex:
            payload = None
            try:
                payload = self.soc.recv(rlen)
            except socket.timeout:
                return payload
        return payload

    def write(self, data, uci_pkt=True, hbci_pkt=False, hbci_qry_pkt=False):
        with self._mutex:
            try:
                self.soc.send(data)
            except socket.timeout:
                log.error('Write Failed')
            except Exception:
                log.error('Write Failed, unknown')

    def close(self):
        log.info(sys._getframe().f_code.co_name)
        self.uci_handler.join()
        if self.connected:
            self.soc.close()

    def uci_read_rsp(self):
        return self.uci_handler.uci_read_rsp()

    def uci_cmd_rsp(self, uci_cmd, timeout=5):
        return self.uci_handler.uci_cmd_rsp(uci_cmd, timeout)

    def set_uci_handler(self, uci_hnd):
        self.uci_handler = uci_hnd

    def uci_read_rsp_clear(self):
        return self.uci_handler.uci_read_rsp_clear()

    def uci_read_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_log_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_read_ntf(self, timeout=1):
        return self.uci_handler.uci_read_ntf(timeoutInSec=timeout)
