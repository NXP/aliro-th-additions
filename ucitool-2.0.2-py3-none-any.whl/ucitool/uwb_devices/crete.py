#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import logging
import os
import serial
import threading
import time

from ucitool.uwb_devices.uwbdevice import UwbDevice
from ucitool.base_uci.hdll import Hdll, CRETE_CMDS, ENUMS


log = logging.getLogger(__name__)

UCI_HEADER_LEN = 4
UCI_PBF_MASK = 0x10  # UCI Packet Boundry Flag Mask
EXT_PL_MASK = 0x80  # 2nd octet of header
MT_MASK = 0xE0


class Crete(UwbDevice):

    def __init__(self):
        super().__init__()
        self.__name = None
        self.id = None
        self.ser = None
        self.uci_ready_mode = True
        self.devcfg = None
        self.dev_type = None
        self.interface_type = None
        self.com_port = None
        self.hbci = None
        self._mutex = None
        self.uci_supported = None
        self.uci_buff = None
        self.uci_handler = None

    def initialize(self, dev_config):
        super().initialize(dev_config)
        self._mutex = threading.Lock()
        self.ser = serial.Serial(**self.ser_props)
        self.ser.port = self.com_port
        if os.name != 'nt':  # for linux: to prevent multiple opens on the same com port, set 'exclusive' parameter
            self.ser.exclusive = True
        self.uci_ready_mode = True
        self.ser.timeout = 0.2
        self.hbci = Hdll(self)  # Actually HDLL for H2 but named as hbci to retain fw-download functionality from uci handler

    def set_uci_handler(self, uci_hnd):
        self.uci_handler = uci_hnd

    def uci_cmd_rsp(self, uci_cmd, timeout=5):
        return self.uci_handler.uci_cmd_rsp(uci_cmd, timeout)

    def uci_read_rsp_clear(self):
        return self.uci_handler.uci_read_rsp_clear()

    def uci_read_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_read_ntf(self, timeout=3):
        return self.uci_handler.uci_read_ntf(timeoutInSec=timeout)

    def cir_ntf_clear(self):
        return self.uci_handler.cir_ntf_clear()

    def read_cir_ntf(self):
        return self.uci_handler.read_cir_ntf()

    def uci_log_ntf(self):
        return self.uci_handler.uci_log_ntf()

    def read_dl_ntf(self):
        return self.uci_handler.read_dl_ntf()

    def read_psdu_ntf(self):
        return self.uci_handler.read_psdu_ntf()

    def uci_read_rsp(self):
        return self.uci_handler.uci_read_rsp()

    def uci_log_ntf_clear(self):
        return self.uci_handler.uci_log_ntf_clear()

    def fw_download(self, filename, print_log=False, skip_powerup=False):  # noqa
        not self.uci_ready_mode and self.uci_handler.fw_download(filename, print_log, skip_power_up=True)

    def enable_jtag2ahb(self, print_log=False):
        self.uci_handler.enable_jtag2ahb(print_log)

    def open(self):
        if not self.ser.isOpen():
            self.ser.open()
            self.uci_handler.set_device(self)
            self.powerup()
            self.uci_buff = bytearray()
            self.verify_normal_boot()
            self.uci_ready_mode = False
            self.uci_handler.start()
        return self.ser.isOpen()

    def verify_normal_boot(self):
        self.hbci.exec_if_crete(CRETE_CMDS.HDLL_GET_NTF)
        hdll_pkt = self.hbci.get_hdll_pkt(log_fun=log.info)
        if not self.hbci.validate_pkt(hdll_pkt, 'hdll_ntf', status=ENUMS.STATUS.READY):
            log.warning('Expected normal boot mode response')
        else:
            self.hbci.exec_if_crete(CRETE_CMDS.HDLL_RESET_TO_UCI)
            time.sleep(0.01)

    def flush_port(self):
        log.debug("Flushing port..")
        with self._mutex:
            self.ser.reset_input_buffer()
            self.ser.reset_output_buffer()

    def close(self):
        if self.ser:
            self.ser.close()
        self.ser = None

    def uci_read(self, poll=False, timeout=None):
        self.uci_buff.extend(self.read())
        buff_len = len(self.uci_buff)
        if buff_len > 4:
            uci_hdr = bytes(self.uci_buff[0:4])  # UCI header
            pl_idx = 2 if (uci_hdr[1] & EXT_PL_MASK) or (uci_hdr[0] & MT_MASK == 0) else 3
            pl_len = int.from_bytes(uci_hdr[pl_idx:], 'little')  # if data packet or extended payload bit enabled
            if buff_len >= (4+pl_len):
                dict_key = self.get_pend_pkt_dict_key(uci_hdr)  # check if partial pkt received earlier
                uci_pend_pl = self.pend_pkt_dict.pop(dict_key, bytearray())
                uci_pend_pl.extend(self.uci_buff[4:4+pl_len])
                del self.uci_buff[:4+pl_len]
                if uci_hdr[0] & UCI_PBF_MASK:  # check for partial pkt
                    self.pend_pkt_dict[dict_key] = uci_pend_pl
                else:
                    return [uci_hdr + uci_pend_pl]
        return None

    def read(self, rlen=None, timeout=1):
        if rlen is None:
            with self._mutex:
                return self.ser.read(self.ser.in_waiting)
        else:
            end_time = time.time() + timeout
            while (end_time > time.time()) and (rlen > self.ser.in_waiting):
                time.sleep(0)
            with self._mutex:
                return self.ser.read(rlen)

    def write(self, data, uci_pkt=True, hbci_pkt=False, hbci_qry_pkt=False, hbci_custom_pkt=False, length=4):
        # hbci_pkt -> hdll_cmd, hbci_qry_pkt -> hdll_edl_last_write
        hdr = (0x01 if uci_pkt else (0x0E if hbci_pkt else (0x0F if hbci_qry_pkt else None)))
        if hdr is not None:
            data = bytes([hdr, *len(data).to_bytes(2, 'big'), *data])
        try:
            with self._mutex:
                return self.ser.write(data)
        except:  # noqa
            log.error('Write Failed')

    def reset_crete(self, timeout=1):
        self.hbci.exec_if_crete(CRETE_CMDS.MCU_RESET)
        time.sleep(timeout)  # let the device unload
        self.close()

    def powerup(self):
        self.flush_port()
        self.hbci.exec_if_crete(CRETE_CMDS.HELIOS_RESET)
        timeout = time.time() + 2
        while timeout >= time.time():
            rx = self.read(4)
            rx and log.info('PowerUp RX:' + str(rx.hex()))
            if rx == bytes([0x01, 0x02, 0x03, 0x04]):
                time.sleep(0.003)
                return
        log.error("Error power up rhodes")
        assert False, "Crete PowerUp Failed"
