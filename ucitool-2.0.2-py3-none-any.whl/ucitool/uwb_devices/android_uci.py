#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import logging
import socket
import sys
import threading
import time

from ucitool.uwb_devices.uwbdevice import UwbDevice

log = logging.getLogger(__name__)
UCI_PBF_MASK = 0x10  # UCI Packet Boundry Flag Mask
UCI_LENGTH_MASK = 0xC0  # UCI 2K length Mask
UCI_2K_LENGTH_SIZE = 2048  # UCI 2K length size
UCI_1K_LENGTH_SIZE = 1024  # UCI 2K length size
UCI_512b_LENGTH_SIZE = 2048  # UCI 2K length size

UCI_HEADER_LEN = 3

POWER_ON = b'\x01'
POWER_OFF = b'\x02'
FW_DOWNLOAD = b'\x03'
BOARD_CONFIG = b'\x04'
CMD_RSP = 0x05
TH_EXIT = b'\xFF'


class AndroidUci(UwbDevice):
    pbf_mask, mt_gid_oid_mask, ext_pl_mask = 0x10_00_00_00, 0xEF_3F_00_00, 0x00_80_00_00
    hdr_len, pl_idx, ext_pl_idx = 4, 3, 2
    def __init__(self):
        super().__init__()
        self.__name = None
        self.id = None
        self.sd = socket.socket()
        self.uci_handler = None
        self.connected = False

    def initialize(self, dev_config):
        self.devcfg = dev_config
        log.info(sys._getframe().f_code.co_name)
        self.dev_type = dev_config.dev_type
        self.id = dev_config.id
        self._mutex = threading.Lock()
        self.interface_type = dev_config.interface_config.type
        self.host = dev_config.interface_config.ip_addr
        self.port = dev_config.interface_config.port
        self.sd.settimeout(0.01)
        self.uci_supported = dev_config.uci_support
        self.variant = dev_config.variant
        self.ser_buff = bytearray()

    def open(self):
        log.info(sys._getframe().f_code.co_name)
        if self.connected:
            return True
        try:
            self.sd.connect((self.host, self.port))
            self.connected = True

        except socket.timeout:
            self.connected = False
        self.uci_handler.set_device(self)
        time.sleep(0.5)
        self.uci_handler.start()
        return self.connected

    def powerup(self):
        self.sd.send(POWER_ON)

    def fw_download(self, filename=None):
        self.sd.send(POWER_ON)
        time.sleep(0.02)
        self.sd.send(FW_DOWNLOAD)
        time.sleep(2)  # HVH requires ~1.5 sec for INIT NTF
        self.sd.send(BOARD_CONFIG)
        time.sleep(0.1)
        
    def poll_read(self, timeout=5):
        return self.read(timeout=timeout)

    def read(self, rlen=8192, timeout=5):
        payload = None
        with self._mutex:
            try:
                payload = self.sd.recv(rlen)
            except socket.timeout:
                pass
        return payload

    def write(self, data, uci_pkt=True, hbci_pkt=False, hbci_qry_pkt=False):
        with self._mutex:
            try:
                uci_data = bytearray([CMD_RSP])
                uci_data.extend(data)
                self.sd.send(uci_data)
            except socket.timeout:
                log.error('Write Failed')
            except Exception:
                log.error('Write Failed, unknown')

    def close(self):
        log.info(sys._getframe().f_code.co_name)
        self.uci_handler.join()
        if self.connected:
            self.sd.send(TH_EXIT)
            self.sd.close()

    def uci_read_rsp(self):
        return self.uci_handler.uci_read_rsp()

    def uci_cmd_rsp(self, uci_cmd, timeout=5):
        return self.uci_handler.uci_cmd_rsp(uci_cmd, timeout)

    def set_uci_handler(self, uci_hnd):
        self.uci_handler = uci_hnd

    def uci_read_rsp_clear(self):
        return self.uci_handler.uci_read_rsp_clear()

    def uci_read_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_log_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_read_ntf(self, timeout=1):
        return self.uci_handler.uci_read_ntf(timeoutInSec=timeout)

    def defragment_uci(self, payload):
        if payload:
            self.ser_buff.extend(payload)
        idx, buff_len, pkt_list = 0, len(self.ser_buff), []
        while (idx + AndroidUci.hdr_len) <= buff_len:
            idx += AndroidUci.hdr_len
            hdr = self.ser_buff[idx - AndroidUci.hdr_len:idx]
            hdr_int = int.from_bytes(hdr, 'big')
            if hdr_int & AndroidUci.ext_pl_mask:
                payload_len = int.from_bytes(hdr[AndroidUci.ext_pl_idx:], 'little')
            else:
                payload_len = hdr[AndroidUci.pl_idx]
            if buff_len >= (idx + payload_len):
                partial_pkt_key = hdr_int & AndroidUci.mt_gid_oid_mask
                payload = self.pend_pkt_dict.pop(partial_pkt_key, bytearray())
                payload.extend(self.ser_buff[idx:idx + payload_len])
                if hdr_int & AndroidUci.pbf_mask:
                    self.pend_pkt_dict[partial_pkt_key] = payload
                else:
                    pkt_list.append(bytes(hdr + payload))
                idx += payload_len
            else:
                idx -= AndroidUci.hdr_len
                break
        self.ser_buff = self.ser_buff[idx:]
        return pkt_list
