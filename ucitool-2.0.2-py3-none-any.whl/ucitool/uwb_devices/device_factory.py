#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#


class DeviceFactory:
    def get_device(self, device_cfg):
        device_type = device_cfg.dev_type
        if device_type == 'RHODES':
            from ucitool.uwb_devices.rhodes import Rhodes
            return Rhodes()
        elif device_type == 'MQTTDEV':
            from ucitool.uwb_devices.mqtt_dev import MqttDevice
            return MqttDevice()
        elif device_type == 'CONTRONIX':  # do not move import above, because-
            from ucitool.uwb_devices.contronix import Contronix  # cntx lib may not be present in rhodes only users PC
            return Contronix()
        elif device_type == 'SIMX86':
            from ucitool.uwb_devices.heliosX86Sim import HeliosSimX86
            return HeliosSimX86()
        elif device_type == 'ANDROID_UCI':
            from ucitool.uwb_devices.android_uci import AndroidUci
            return AndroidUci()
        elif device_type == 'DUMMY':
            from ucitool.uwb_devices.dummy import Dummy
            return Dummy()
        elif device_type == 'RHODESV3':
            from ucitool.uwb_devices.rhodes_winusb import RhodesWinUsb
            return RhodesWinUsb(device_cfg.port)
        elif device_type == 'ARMADO':
            from ucitool.uwb_devices.armado import Armado
            return Armado()
        elif device_type == 'CRETE':
            from ucitool.uwb_devices.crete import Crete
            return Crete()
        from ucitool.uwb_devices.fira_vcom import FiraVcom
        return FiraVcom()