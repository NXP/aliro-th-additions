#
# Copyright (c), 2020 NXP Semiconductors
#
# All rights are reserved. Reproduction in whole or in part is
# prohibited without the written consent of the copyright owner.
#
# NXP reserves the right to make changes without notice at any time.
#
# NXP makes no warranty, expressed, implied or statutory, including but
# not limited to any implied warranty of merchantability or fitness for any
# particular purpose, or that the use will not infringe any third party patent,
# copyright or trademark. NXP must not be liable for any loss or damage
# arising from its use.
#

import logging
import queue
import sys
import threading
import time

import helios
from helios import GPIO, GPIO_MODE, GPIO_NOTIFICATION_MODE

from ucitool.base_uci.hbci import Hbci
from ucitool.uwb_devices.uwbdevice import UwbDevice

log = logging.getLogger(__name__)
UCI_HEADER_LEN = 4
UCI_2K_LENGTH_MASK = 0x80  # UCI 2K length Mask
UCI_2K_LENGTH_SIZE = 2048  # UCI 2K length size
UCI_PBF_MASK = 0x10  # UCI Packet Boundry Flag Mask


class Contronix(UwbDevice):
    def __init__(self):
        super().__init__()
        self.__name = None
        self.id = None
        self._device = None
        self._cntx_cb_q_mutex = threading.Lock()
        self._cntx_rx_data_queue = queue.Queue()
        self.cntx_hw_version = 0
        self.pend_pkt_dict = {}

    def initialize(self, dev_config):
        self.devcfg = dev_config
        log.info(sys._getframe().f_code.co_name)
        self.dev_type = dev_config.dev_type
        self._mutex = threading.Lock()
        self._gpio_mutex = threading.Lock()
        self.host_if = 'SPI_H'
        self.spi_iface = helios.SPI(1)
        self.spi_clock = 10500000
        self.host_irq_gpio = 4
        self.spi_mode = 0
        self.gpio_cb_cnt = 0
        self.id = dev_config.id
        self.interface_type = dev_config.interface_config.type
        self.com_port = dev_config.interface_config.com_port
        self.ip_addr = dev_config.interface_config.ip_addr
        self.port = dev_config.interface_config.port
        self.hbci = Hbci(self.write, self.check_gpio_and_read, self.id, self.dev_type)
        self.uci_supported = dev_config.uci_support
        self.variant = dev_config.variant

    def wait_for_first_ntf(self):
        RTC_SYNC_IDX = 0
        GPIO_PIN_HOST_NTF = 4
        I2C_INTERFACE = helios.I2C.I2C_CX
        I2C_SLV_ADDR = 0x20
        ACK_PIN_IDX = 2
        SPI_INTERFACE = helios.SPI.SPI_H
        uci_payload = bytearray()
        try:
            if self._device.get_hw_rev() == 2:
                RTC_SYNC_IDX = 1
                GPIO_PIN_HOST_NTF = 5
                ACK_PIN_IDX = 3
        except:
            pass
        while True:
            if not self.gpio_callback_wait(2):
                return False
            self.gpio_cb_cnt = 0
            self._device.gpio_set_mode_value_single(GPIO.GPIO, ACK_PIN_IDX, GPIO_MODE.OUTPUT_PUSH_PULL, 1, timeout=1)

            # Wait for payload indication from Helios
            if not self.gpio_callback_wait(2) and not \
                    self._device.gpio_read_in_single(GPIO.GPIO, GPIO_PIN_HOST_NTF)["data"][0]:
                self._device.gpio_set_mode_value_single(GPIO.GPIO, ACK_PIN_IDX, GPIO_MODE.OUTPUT_PUSH_PULL, 0,
                                                        timeout=1)
                return False
            if self.host_if == "Link_I2C":
                uci_hdr = self._device.i2c_read(I2C_INTERFACE, I2C_SLV_ADDR, UCI_HEADER_LEN, timeout=5)
            else:
                uci_hdr = self._device.spi_transmit_read_master(SPI_INTERFACE, bytearray(UCI_HEADER_LEN), timeout=5)
                uci_hdr = uci_hdr[0]
            if len(uci_hdr["data"]) == 0 and len(uci_hdr["data"]) != 4:
                self._device.gpio_set_mode_value_single(GPIO.GPIO, ACK_PIN_IDX, GPIO_MODE.OUTPUT_PUSH_PULL, 0,
                                                        timeout=1)
                return False
            if (uci_hdr["data"][3] == 0) and (
                    uci_hdr["data"][1] & UCI_2K_LENGTH_MASK != UCI_2K_LENGTH_MASK):
                self._device.gpio_set_mode_value_single(GPIO.GPIO, ACK_PIN_IDX, GPIO_MODE.OUTPUT_PUSH_PULL, 0,
                                                        timeout=1)
                break
            if uci_hdr["data"][1] & UCI_2K_LENGTH_MASK == UCI_2K_LENGTH_MASK:
                if self.host_if == "Link_I2C":
                    chunk = self._device.i2c_read(I2C_INTERFACE, I2C_SLV_ADDR, bytearray(UCI_2K_LENGTH_SIZE), timeout=5)
                else:
                    chunk = self._device.spi_transmit_read_master(SPI_INTERFACE, bytearray(UCI_2K_LENGTH_SIZE),
                                                                  timeout=5)
                    chunk = chunk[0]
            else:
                if self.host_if == "Link_I2C":
                    chunk = self._device.i2c_read(I2C_INTERFACE, I2C_SLV_ADDR, uci_hdr["data"][3], timeout=5)
                else:
                    chunk = self._device.spi_transmit_read_master(SPI_INTERFACE, bytearray(uci_hdr["data"][3]),
                                                                  timeout=5)
                    chunk = chunk[0]
            # Wait for HOSTIRQ pin to go low
            status = self._device.gpio_read_in_single(GPIO.GPIO, GPIO_PIN_HOST_NTF)
            while 1 == status['data_a'][0]:
                status = self._device.gpio_read_in_single(GPIO.GPIO, GPIO_PIN_HOST_NTF)
            # Deassert HOST ACK line to low
            self._device.gpio_set_mode_value_single(GPIO.GPIO, ACK_PIN_IDX, GPIO_MODE.OUTPUT_PUSH_PULL, 0, timeout=1)
            if chunk and len(chunk) == 0:
                return False
            if uci_hdr["data"][1] & UCI_2K_LENGTH_MASK == UCI_2K_LENGTH_MASK:
                if (UCI_2K_LENGTH_SIZE != (len(chunk["data"]))):
                    return False
            else:
                if (uci_hdr["data"][3]) != (len(chunk["data"])):
                    return False
            uci_payload.extend(chunk["data"])
            # E. If Packet Boundry Flag Mask is not set; break the loop
            if not uci_hdr["data"][0] & UCI_PBF_MASK:
                break
        return uci_hdr["data"] + uci_payload

    def spi_cb_handler(self, data, helios_obj):
        self._cntx_rx_data_queue.put(data)

    # get the key
    def get_pend_pkt_dict_key(self, hdr):
        # gid << 8  | oid
        dict_key = ((hdr[0] & 0x0F) << 8) | (hdr[1] & 0x3F)
        return dict_key

    def uci_read(self, poll=False, timeout=5):
        # uci_data = bytearray()
        read_full_ntf = False
        with self._cntx_cb_q_mutex:
            while True:
                # if not self._cntx_rx_data_queue.empty():
                # wait for 1sec for a notificaiton
                try:
                    uci_data = self._cntx_rx_data_queue.get(timeout=1)['data']
                # will raise queue.Empty exception when there is a timeout
                except:
                    uci_data = None
                    break
                else:
                    # get the UCI header
                    uci_hdr = uci_data[0:4]
                    # check we have any part of notificaiton data  received before this
                    dict_key = self.get_pend_pkt_dict_key(uci_hdr)
                    uci_pend_payload = self.pend_pkt_dict.pop(dict_key, bytearray())
                    # check if we have got the partial notification
                    if uci_hdr[0] & UCI_PBF_MASK:
                        uci_pend_payload.extend(uci_data[4:])
                        self.pend_pkt_dict[dict_key] = uci_pend_payload
                    else:
                        uci_data = uci_hdr + uci_pend_payload + uci_data[4:]
                        break
            if uci_data is None:
                return None
            else:
                return [uci_data]

    def flush_queue(self):
        while not self._cntx_rx_data_queue.empty():
            self._cntx_rx_data_queue.get()

    def set_uci_handler(self, uci_hnd):
        self.uci_handler = uci_hnd

    def uci_cmd_rsp(self, uci_cmd, timeout=5):
        return self.uci_handler.uci_cmd_rsp(uci_cmd, timeout)

    def uci_read_rsp_clear(self):
        return self.uci_handler.uci_read_rsp_clear()

    def uci_read_ntf_clear(self):
        return self.uci_handler.uci_read_ntf_clear()

    def uci_read_ntf(self, timeout=3):
        return self.uci_handler.uci_read_ntf(timeoutInSec=timeout)

    def cir_ntf_clear(self):
        return self.uci_handler.cir_ntf_clear()

    def read_cir_ntf(self):
        return self.uci_handler.read_cir_ntf()

    def uci_log_ntf(self):
        return self.uci_handler.uci_log_ntf()

    def read_dl_ntf(self):
        return self.uci_handler.read_dl_ntf()

    def read_psdu_ntf(self):
        return self.uci_handler.read_psdu_ntf()

    def uci_read_rsp(self):
        return self.uci_handler.uci_read_rsp()

    def uci_log_ntf_clear(self):
        return self.uci_handler.uci_log_ntf_clear()

    def fw_download(self, filename, print_log=False, skip_powerup=False):
        self.uci_handler.fw_download(filename, print_log, skip_powerup)
        ntf = self.wait_for_first_ntf()
        self.spi_helios_proto_set_protocol_handling(True)

        return ntf

    def enable_jtag2ahb(self, print_log=False):
        self.uci_handler.enable_jtag2ahb(print_log)

    def open(self):
        log.info(sys._getframe().f_code.co_name)
        if self.com_port:
            self._device = helios.Helios(serial_port=self.com_port)
        else:
            if self.port is not None:
                self._device = helios.Helios(tgt_addr=self.ip_addr, local_port=self.port)
            else:
                self._device = helios.Helios(tgt_addr=self.ip_addr)
        try:
            self.cntx_hw_version = self._device.get_hw_rev()
            if self.cntx_hw_version < 2:
                self.host_irq_gpio = 4
                self.spi_clock = 10500000
                self.ack_pin_id = 2
            else:
                self.host_irq_gpio = 5
                self.spi_clock = 21000000
                self.ack_pin_id = 3
        except:
            pass
        self.spi_config()
        self.gpio_config()
        self.powerup()
        self.uci_handler.set_device(self)
        self._device.spi_helios_proto_add_callback(self.spi_cb_handler)
        time.sleep(1)
        self.uci_handler.start()

    def flush_port(self):
        log.info(sys._getframe().f_code.co_name)
        log.info("Dummy function. Use Flush from XSLIP!")

    def close(self):
        log.info(sys._getframe().f_code.co_name)
        self.uci_handler.join()
        if self._device:
            self._device.close()
        self._device = None

    def poll_read(self, length, timeout=5):
        read_buf = None
        self._mutex.acquire()
        try:
            if length > 0:
                buf = self._device.spi_transmit_read_master(self.spi_iface, bytearray(length), timeout=timeout)
                read_buf = buf[0]["data"]
        finally:
            self._mutex.release()
        return read_buf

    def read(self, length, timeout=2):
        read_buf = None
        self._mutex.acquire()
        try:
            if length > 0:
                buf = self._device.spi_transmit_read_master(self.spi_iface, bytearray(length), timeout=timeout)
                read_buf = buf[0]["data"]
        finally:
            self._mutex.release()
        return read_buf

    def write(self, data, uci_pkt=False, hbci_pkt=False, hbci_qry_pkt=False, hbci_custom_pkt=False, length=4):
        self._mutex.acquire()
        try:
            ret_status = self._device.spi_transmit_read_master(self.spi_iface, data)
        finally:
            self._mutex.release()
        return ret_status

    def gpio_config(self):
        log.info(sys._getframe().f_code.co_name)
        self._device.gpio_set_mode_value_single(GPIO.GPIO, self.host_irq_gpio, GPIO_MODE.INPUT_PULL_UP,
                                                1)  # GPIO05 - Host interrupt
        if self._device.get_hw_rev() < 2:
            self._device.gpio_set_mode_value_single(GPIO.MISC, 0, GPIO_MODE.INPUT_FLOATING, 1)
        else:
            self._device.gpio_set_mode_value_single(GPIO.MISC, 1, GPIO_MODE.INPUT_FLOATING, 1)
        self._device.gpio_notification_callback_add(GPIO.GPIO, self.gpio_cb)
        self._device.gpio_notification_enable(GPIO.GPIO, self.host_irq_gpio, GPIO_NOTIFICATION_MODE.RISING_EDGE)
        self._device.gpio_set_mode_value_single(GPIO.GPIO, self.ack_pin_id, GPIO_MODE.OUTPUT_PUSH_PULL,
                                                0)  # GPIO3 - Host ACK

    def spi_config(self):
        self._device.spi_config_set(self.spi_iface, self.spi_clock, self.spi_mode, 0, 0)

    def gpio_cb(self, data, helios_obj):
        self._gpio_mutex.acquire()
        try:
            self.gpio_cb_cnt += 1
        finally:
            self._gpio_mutex.release()

    def gpio_rtc_sync_set_mode_value(self, mode, value):
        self._device.gpio_rtc_sync_set_mode_value(mode, value)

    def spi_helios_proto_set_protocol_handling(self, enable):
        self._device.spi_helios_proto_set_protocol_handling(enable)
        if not enable:
            time.sleep(0.5)
            self.flush_queue()

    def spi_helios_proto_add_callback(self, value):
        self._device.spi_helios_proto_add_callback(value)

    def reset_contronix(self, timeout=5):
        log.info(sys._getframe().f_code.co_name)
        self._device.reset()
        time.sleep(timeout)

    def is_gpio_raised(self):
        if self.gpio_cb_cnt > 0:
            return True

    def gpio_callback_wait(self, timeoutInSec=2):
        timeout = time.time() + timeoutInSec
        while time.time() < timeout:
            with self._gpio_mutex:
                if self.gpio_cb_cnt > 0:
                    if self.gpio_cb_cnt > 1:
                        log.info("More than one gpio_callback received")
                    self.gpio_cb_cnt = 0
                    return True
            time.sleep(0.1)
            # self.gpio_cb_cnt = 0
        return False

    def gpio_irq_read(self):
        data = self._device.gpio_read_in_single(GPIO.GPIO, 4)
        log.info("Host_irq status : %s", data['data_a'][0])
        return data['data_a'][0]

    def check_gpio_and_read(self, length, timeout=2):
        data = None
        if self.gpio_callback_wait(1):
            data = self.read(length, timeout)
        return data

    def powerup(self):
        self.spi_helios_proto_set_protocol_handling(False)
        if self.cntx_hw_version == 2:
            self._device.uart2_enable(0)
            self._device.gpio_ce_enable(True)
            self._device.pwr_enable_1v8soc(0)
            time.sleep(0.5)
            self._device.gpio_ce_enable(False)
            time.sleep(0.5)
            self._device.pwr_enable_1v8soc(1)
            self._device.uart2_enable(1)
            self._device.gpio_extender_set_usage_mode(0)  # usage mode 0
            self._device.gpio_extender_set_mux_usage_mode(14, 1)
            self._device.gpio_extender_set_mux_usage_mode(15, 1)
            if self.host_if != "SPI_H":
                self._device.gpio_extender_set_mux_usage_mode(0, 2)
                self._device.gpio_extender_set_mux_usage_mode(1, 2)
                self._device.gpio_extender_set_mux_usage_mode(2, 3)
                self._device.gpio_extender_set_mux_usage_mode(3, 3)
        else:
            self._device.uart2_enable(0)
            self._device.gpio_ce_enable(True)
            self._device.gpio_extender_set_power_enables(power_enables=0x0)  # Disable regulator
            self._device.gpio_extender_set_mux_usage_mode(1, 2)
            self._device.gpio_extender_set_mux_usage_mode(3, 2)
            self._device.gpio_extender_set_mux_usage_mode(9, 3)
            self._device.gpio_extender_set_mux_usage_mode(6, 2)
            self._device.gpio_extender_set_mux_usage_mode(7, 2)
            self._device.gpio_extender_set_usage_mode(3)  # usage mode 3
            self._device.gpio_set_mode_value_single(GPIO.HOST, 2, GPIO_MODE.OUTPUT_PUSH_PULL, 0)
            self._device.gpio_set_mode_value_single(GPIO.HOST, 1, GPIO_MODE.OUTPUT_PUSH_PULL, 0)
            time.sleep(0.5)
            self._device.gpio_ce_enable(False)
            self._device.gpio_extender_set_power_enables(power_enables=0x7)  # set to 0x0 to disable regulator
            time.sleep(0.5)
            self._device.uart2_enable(1)
            self._device.gpio_extender_set_usage_mode(0)  # usage mode 0

    def read_chipid(self):
        self.powerup()
        time.sleep(0.5)  # cntx takes time
        return self.hbci.get_chip_id()
